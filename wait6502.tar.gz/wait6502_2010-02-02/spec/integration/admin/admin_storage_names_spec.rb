require 'spec_helper'

describe "Admin::StorageNames" do
end
