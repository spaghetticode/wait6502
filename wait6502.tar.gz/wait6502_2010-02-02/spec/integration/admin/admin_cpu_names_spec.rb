require 'spec_helper'

describe "Admin::CpuNames" do
end
