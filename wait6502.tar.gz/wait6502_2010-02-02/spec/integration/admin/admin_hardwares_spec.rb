require 'spec_helper'

describe "Admin::Hardwares" do
end
