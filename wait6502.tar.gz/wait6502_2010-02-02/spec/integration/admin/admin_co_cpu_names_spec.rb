require 'spec_helper'

describe "Admin::CoCpuNames" do
end
