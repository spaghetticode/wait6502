require 'spec_helper'

describe "Admin::Cpus" do
end
