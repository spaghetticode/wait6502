require 'spec_helper'

describe "Admin::CpuFamilies" do
end
