require 'spec_helper'

describe "Admin::Computers" do
end
