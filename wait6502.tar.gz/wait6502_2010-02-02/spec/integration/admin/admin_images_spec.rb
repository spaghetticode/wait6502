require 'spec_helper'

describe "Admin::Images" do
end
