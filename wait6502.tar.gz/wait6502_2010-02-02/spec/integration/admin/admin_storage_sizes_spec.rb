require 'spec_helper'

describe "Admin::StorageSizes" do
end
