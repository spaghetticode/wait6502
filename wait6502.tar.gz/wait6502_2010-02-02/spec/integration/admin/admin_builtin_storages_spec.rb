require 'spec_helper'

describe "Admin::BuiltinStorages" do
end
