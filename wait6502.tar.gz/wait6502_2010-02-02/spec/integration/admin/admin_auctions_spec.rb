require 'spec_helper'

describe "Admin::Auctions" do
end
