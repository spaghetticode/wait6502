require 'spec_helper'

describe "Admin::OperativeSystems" do
end
