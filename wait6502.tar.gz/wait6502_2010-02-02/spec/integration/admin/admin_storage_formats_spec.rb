require 'spec_helper'

describe "Admin::StorageFormats" do
end
