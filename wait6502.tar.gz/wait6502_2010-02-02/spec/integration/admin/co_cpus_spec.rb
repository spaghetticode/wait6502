require 'spec_helper'

describe "Admin::CoCpus" do
end
