require 'spec_helper'

describe "Admin::BuiltinLanguages" do
end
