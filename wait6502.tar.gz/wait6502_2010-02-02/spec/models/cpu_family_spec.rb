require 'spec_helper'

describe CpuFamily do
  include NaturalKeyTable 

  before :all do
    @class = CpuFamily
  end
end
