require 'spec_helper'

describe CoCpuName do
 include NaturalKeyTable 
  
  before :all do
    @class = CoCpuName
  end
end
