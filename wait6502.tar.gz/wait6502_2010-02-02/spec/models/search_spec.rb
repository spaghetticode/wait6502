require 'spec_helper'

describe Search do
end
