require 'spec_helper'

describe CpuName do
  include NaturalKeyTable 

  before :all do
    @class = CoCpuName
  end
end

