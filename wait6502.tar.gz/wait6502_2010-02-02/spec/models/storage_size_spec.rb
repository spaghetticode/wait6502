require 'spec_helper'

describe StorageSize do
  include NaturalKeyTable 

  before :all do
    @class = StorageSize
  end
end
