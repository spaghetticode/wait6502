require 'spec_helper'

describe CpuBit do
  include NaturalKeyTable 
  
  before :all do
    @class = CpuBit
  end
end
