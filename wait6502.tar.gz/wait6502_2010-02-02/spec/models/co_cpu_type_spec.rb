require 'spec_helper'

describe CoCpuType do
  include NaturalKeyTable 
  
  before :all do
    @class = CoCpuType
  end
end
