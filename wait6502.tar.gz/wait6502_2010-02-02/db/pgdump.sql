--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auctions; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE auctions (
    id integer NOT NULL,
    hardware_id integer NOT NULL,
    ebay_site_id character varying(255) NOT NULL,
    currency_id character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    url character varying(255) NOT NULL,
    image_url character varying(255),
    item_id character varying(255) NOT NULL,
    cosmetic_conditions character varying(255) NOT NULL,
    completeness character varying(255) NOT NULL,
    final_price numeric(11,2),
    end_time timestamp without time zone NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    picture_file_name character varying(255),
    picture_content_type character varying(255),
    picture_file_size integer,
    picture_updated_at timestamp without time zone
);


ALTER TABLE public.auctions OWNER TO lhqgngvmkq;

--
-- Name: auctions_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE auctions_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auctions_id_seq OWNER TO lhqgngvmkq;

--
-- Name: auctions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE auctions_id_seq OWNED BY auctions.id;


--
-- Name: auctions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('auctions_id_seq', 799, true);


--
-- Name: builtin_languages; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE builtin_languages (
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    permalink character varying(255)
);


ALTER TABLE public.builtin_languages OWNER TO lhqgngvmkq;

--
-- Name: builtin_storages; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE builtin_storages (
    id integer NOT NULL,
    storage_name_id character varying(255) NOT NULL,
    storage_format_id character varying(255),
    storage_size_id character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.builtin_storages OWNER TO lhqgngvmkq;

--
-- Name: builtin_storages_hardware; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE builtin_storages_hardware (
    hardware_id integer,
    builtin_storage_id integer
);


ALTER TABLE public.builtin_storages_hardware OWNER TO lhqgngvmkq;

--
-- Name: builtin_storages_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE builtin_storages_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.builtin_storages_id_seq OWNER TO lhqgngvmkq;

--
-- Name: builtin_storages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE builtin_storages_id_seq OWNED BY builtin_storages.id;


--
-- Name: builtin_storages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('builtin_storages_id_seq', 12, true);


--
-- Name: co_cpu_names; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE co_cpu_names (
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.co_cpu_names OWNER TO lhqgngvmkq;

--
-- Name: co_cpu_types; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE co_cpu_types (
    name character varying(255) NOT NULL
);


ALTER TABLE public.co_cpu_types OWNER TO lhqgngvmkq;

--
-- Name: co_cpus; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE co_cpus (
    id integer NOT NULL,
    co_cpu_name_id character varying(255),
    co_cpu_type_id character varying(255),
    manufacturer_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    cpu_family_id character varying(255),
    description text
);


ALTER TABLE public.co_cpus OWNER TO lhqgngvmkq;

--
-- Name: co_cpus_hardware; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE co_cpus_hardware (
    hardware_id integer,
    co_cpu_id integer
);


ALTER TABLE public.co_cpus_hardware OWNER TO lhqgngvmkq;

--
-- Name: co_cpus_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE co_cpus_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.co_cpus_id_seq OWNER TO lhqgngvmkq;

--
-- Name: co_cpus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE co_cpus_id_seq OWNED BY co_cpus.id;


--
-- Name: co_cpus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('co_cpus_id_seq', 13, true);


--
-- Name: countries; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE countries (
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    flag_file_name character varying(255),
    flag_content_type character varying(255),
    flag_file_size integer,
    flag_updated_at timestamp without time zone
);


ALTER TABLE public.countries OWNER TO lhqgngvmkq;

--
-- Name: cpu_bits; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE cpu_bits (
    name character varying(255) NOT NULL
);


ALTER TABLE public.cpu_bits OWNER TO lhqgngvmkq;

--
-- Name: cpu_families; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE cpu_families (
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.cpu_families OWNER TO lhqgngvmkq;

--
-- Name: cpu_names; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE cpu_names (
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.cpu_names OWNER TO lhqgngvmkq;

--
-- Name: cpus; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE cpus (
    id integer NOT NULL,
    cpu_bit_id character varying(255) NOT NULL,
    cpu_family_id character varying(255),
    manufacturer_id integer NOT NULL,
    cpu_name_id character varying(255) NOT NULL,
    clock character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    description text,
    parent_cpu_id integer
);


ALTER TABLE public.cpus OWNER TO lhqgngvmkq;

--
-- Name: cpus_hardware; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE cpus_hardware (
    hardware_id integer,
    cpu_id integer
);


ALTER TABLE public.cpus_hardware OWNER TO lhqgngvmkq;

--
-- Name: cpus_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE cpus_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.cpus_id_seq OWNER TO lhqgngvmkq;

--
-- Name: cpus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE cpus_id_seq OWNED BY cpus.id;


--
-- Name: cpus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('cpus_id_seq', 23, true);


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE currencies (
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.currencies OWNER TO lhqgngvmkq;

--
-- Name: ebay_keywords; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE ebay_keywords (
    id integer NOT NULL,
    name character varying(255),
    searchable_id integer,
    searchable_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.ebay_keywords OWNER TO lhqgngvmkq;

--
-- Name: ebay_keywords_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE ebay_keywords_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ebay_keywords_id_seq OWNER TO lhqgngvmkq;

--
-- Name: ebay_keywords_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE ebay_keywords_id_seq OWNED BY ebay_keywords.id;


--
-- Name: ebay_keywords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('ebay_keywords_id_seq', 1, false);


--
-- Name: ebay_sites; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE ebay_sites (
    name character varying(255) NOT NULL,
    site_id character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    currency_id character varying(255),
    country_id character varying(255)
);


ALTER TABLE public.ebay_sites OWNER TO lhqgngvmkq;

--
-- Name: hardware; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE hardware (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255),
    notes text,
    manufacturer_id integer NOT NULL,
    production_start integer,
    production_stop integer,
    codename character varying(255),
    text_modes text,
    graphic_modes text,
    sound text,
    builtin_language_id character varying(255),
    ram character varying(255),
    vram character varying(255),
    rom character varying(255),
    hardware_category character varying(255),
    hardware_type_id character varying(255) NOT NULL,
    description text,
    trivia text
);


ALTER TABLE public.hardware OWNER TO lhqgngvmkq;

--
-- Name: hardware_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE hardware_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.hardware_id_seq OWNER TO lhqgngvmkq;

--
-- Name: hardware_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE hardware_id_seq OWNED BY hardware.id;


--
-- Name: hardware_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('hardware_id_seq', 66, true);


--
-- Name: hardware_io_ports; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE hardware_io_ports (
    hardware_id integer,
    io_port_id integer
);


ALTER TABLE public.hardware_io_ports OWNER TO lhqgngvmkq;

--
-- Name: hardware_operative_systems; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE hardware_operative_systems (
    hardware_id integer,
    operative_system_id integer
);


ALTER TABLE public.hardware_operative_systems OWNER TO lhqgngvmkq;

--
-- Name: hardware_types; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE hardware_types (
    name character varying(255)
);


ALTER TABLE public.hardware_types OWNER TO lhqgngvmkq;

--
-- Name: images; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE images (
    id integer NOT NULL,
    original_filename character varying(255),
    title character varying(255),
    caption text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    imageable_id integer NOT NULL,
    imageable_type character varying(255),
    picture_file_name character varying(255),
    picture_content_type character varying(255),
    picture_file_size integer,
    picture_updated_at timestamp without time zone
);


ALTER TABLE public.images OWNER TO lhqgngvmkq;

--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE images_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.images_id_seq OWNER TO lhqgngvmkq;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE images_id_seq OWNED BY images.id;


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('images_id_seq', 248, true);


--
-- Name: io_ports; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE io_ports (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    connector character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.io_ports OWNER TO lhqgngvmkq;

--
-- Name: io_ports_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE io_ports_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.io_ports_id_seq OWNER TO lhqgngvmkq;

--
-- Name: io_ports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE io_ports_id_seq OWNED BY io_ports.id;


--
-- Name: io_ports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('io_ports_id_seq', 51, true);


--
-- Name: manufacturers; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE manufacturers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    country_id character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    description text,
    logo_file_name character varying(255),
    logo_content_type character varying(255),
    logo_file_size integer,
    logo_update_at timestamp without time zone
);


ALTER TABLE public.manufacturers OWNER TO lhqgngvmkq;

--
-- Name: manufacturers_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE manufacturers_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.manufacturers_id_seq OWNER TO lhqgngvmkq;

--
-- Name: manufacturers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE manufacturers_id_seq OWNED BY manufacturers.id;


--
-- Name: manufacturers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('manufacturers_id_seq', 23, true);


--
-- Name: operative_systems; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE operative_systems (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.operative_systems OWNER TO lhqgngvmkq;

--
-- Name: operative_systems_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE operative_systems_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.operative_systems_id_seq OWNER TO lhqgngvmkq;

--
-- Name: operative_systems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE operative_systems_id_seq OWNED BY operative_systems.id;


--
-- Name: operative_systems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('operative_systems_id_seq', 26, true);


--
-- Name: original_prices; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE original_prices (
    id integer NOT NULL,
    currency_id character varying(255),
    country_id character varying(255),
    date date,
    amount numeric(11,2),
    purchaseable_id integer,
    purchaseable_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    tainted boolean
);


ALTER TABLE public.original_prices OWNER TO lhqgngvmkq;

--
-- Name: original_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE original_prices_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.original_prices_id_seq OWNER TO lhqgngvmkq;

--
-- Name: original_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE original_prices_id_seq OWNED BY original_prices.id;


--
-- Name: original_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('original_prices_id_seq', 34, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO lhqgngvmkq;

--
-- Name: storage_formats; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE storage_formats (
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.storage_formats OWNER TO lhqgngvmkq;

--
-- Name: storage_names; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE storage_names (
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.storage_names OWNER TO lhqgngvmkq;

--
-- Name: storage_sizes; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE storage_sizes (
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.storage_sizes OWNER TO lhqgngvmkq;

--
-- Name: users; Type: TABLE; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    crypted_password character varying(255) NOT NULL,
    password_salt character varying(255) NOT NULL,
    persistence_token character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_request_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO lhqgngvmkq;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: lhqgngvmkq
--

CREATE SEQUENCE users_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO lhqgngvmkq;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lhqgngvmkq
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lhqgngvmkq
--

SELECT pg_catalog.setval('users_id_seq', 4, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE auctions ALTER COLUMN id SET DEFAULT nextval('auctions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE builtin_storages ALTER COLUMN id SET DEFAULT nextval('builtin_storages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE co_cpus ALTER COLUMN id SET DEFAULT nextval('co_cpus_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE cpus ALTER COLUMN id SET DEFAULT nextval('cpus_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE ebay_keywords ALTER COLUMN id SET DEFAULT nextval('ebay_keywords_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE hardware ALTER COLUMN id SET DEFAULT nextval('hardware_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE images ALTER COLUMN id SET DEFAULT nextval('images_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE io_ports ALTER COLUMN id SET DEFAULT nextval('io_ports_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE manufacturers ALTER COLUMN id SET DEFAULT nextval('manufacturers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE operative_systems ALTER COLUMN id SET DEFAULT nextval('operative_systems_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE original_prices ALTER COLUMN id SET DEFAULT nextval('original_prices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lhqgngvmkq
--

ALTER TABLE users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: auctions; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY auctions (id, hardware_id, ebay_site_id, currency_id, title, url, image_url, item_id, cosmetic_conditions, completeness, final_price, end_time, created_at, updated_at, picture_file_name, picture_content_type, picture_file_size, picture_updated_at) FROM stdin;
7	3	CA	CAD	VINTAGE COMMODORE 64 COMPUTER W/ 1541 DISK DRIVE C64 PC	http://cgi.ebay.ca/VINTAGE-COMMODORE-64-COMPUTER-W-1541-DISK-DRIVE-C64-PC_W0QQitemZ360223434453QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3602234344538080_1.jpg	360223434453	good	complete with extras	33.75	2010-01-12 02:20:15	2010-01-11 21:30:08.783184	2010-01-12 21:35:01.845066	3602234344538080_1.jpg	image/jpg	1583	2010-01-11 21:30:08.66304
14	3	DE	EUR	C 64   *Commodore	http://cgi.ebay.de/C-64-Commodore_W0QQitemZ120514125047QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1205141250478080_1.jpg	120514125047	good	complete	20.49	2010-01-12 12:30:03	2010-01-11 21:32:39.054632	2010-01-12 21:35:07.944932	1205141250478080_1.jpg	image/jpg	995	2010-01-11 21:32:38.918534
15	3	DE	EUR	Commodore c 64 + viel Zubehör	http://cgi.ebay.de/Commodore-c-64-viel-Zubehoer_W0QQitemZ170428476187QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1704284761878080_1.jpg	170428476187	good	complete with extras	49.50	2010-01-12 18:40:34	2010-01-11 21:32:47.488292	2010-01-12 21:35:09.936216	1704284761878080_1.jpg	image/jpg	1172	2010-01-11 21:32:47.37785
16	3	DE	EUR	Commodore 64 + Netzteil	http://cgi.ebay.de/Commodore-64-Netzteil_W0QQitemZ110477779844QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1104777798448080_1.jpg	110477779844	good	boxed	14.50	2010-01-12 20:58:40	2010-01-11 21:33:08.381751	2010-01-12 21:35:13.554715	1104777798448080_1.jpg	image/jpg	1329	2010-01-11 21:33:08.261864
3	3	AU	AUD	vintage Commodore 64 + accessories - Games	http://cgi.ebay.com.au/vintage-Commodore-64-accessories-Games_W0QQitemZ170428709677QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704287096778080_1.jpg	170428709677	average	complete with extras	81.03	2010-01-13 03:28:29	2010-01-11 21:27:59.520758	2010-01-13 10:49:32.170746	1704287096778080_1.jpg	image/jpg	1429	2010-01-11 21:27:59.3845
21	3	IT	EUR	COMMODORE 64  1° VERSIONE CON ACCESSORI IN BOX	http://cgi.ebay.it/COMMODORE-64-1-VERSIONE-CON-ACCESSORI-IN-BOX_W0QQitemZ310192864430QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3101928644308080_1.jpg	310192864430	average	boxed	36.50	2010-01-13 17:46:42	2010-01-11 21:37:20.736159	2010-01-13 18:24:39.279642	3101928644308080_1.jpg	image/jpg	1260	2010-01-11 21:37:20.609471
1	1	DE	EUR	Commodore Amiga 1000 mit 2 MB Speichererweiterung	http://cgi.ebay.de/Commodore-Amiga-1000-mit-2-MB-Speichererweiterung_W0QQitemZ270511158178QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705111581788080_1.jpg	270511158178	good	complete	131.00	2010-01-13 19:00:51	2010-01-11 00:12:13.75202	2010-01-13 19:39:30.326882	2705111581788080_1.jpg	image/jpg	837	2010-01-11 00:12:13.635681
17	3	DE	EUR	Commodore 64 mit Foppy 1541	http://cgi.ebay.de/Commodore-64-mit-Foppy-1541_W0QQitemZ320471846906QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204718469068080_1.jpg	320471846906	average	complete with extras	52.00	2010-01-14 15:03:36	2010-01-11 21:33:16.851262	2010-01-15 15:08:49.489485	3204718469068080_1.jpg	image/jpg	1104	2010-01-11 21:33:16.699569
18	3	DE	EUR	Commodore C 64 kompl. mit Floppy 1541 u. div. Zubehör !	http://cgi.ebay.de/Commodore-C-64-kompl-mit-Floppy-1541-u-div-Zubehoer_W0QQitemZ120513808391QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1205138083918080_1.jpg	120513808391	good	complete with extras	28.50	2010-01-14 16:37:27	2010-01-11 21:33:29.453159	2010-01-15 15:08:51.177285	1205138083918080_1.jpg	image/jpg	1603	2010-01-11 21:33:29.328944
19	3	DE	EUR	Commodore C 64 mit Floppy 1541	http://cgi.ebay.de/Commodore-C-64-mit-Floppy-1541_W0QQitemZ230422102038QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2304221020388080_1.jpg	230422102038	average	complete with extras	23.60	2010-01-16 14:42:18	2010-01-11 21:34:20.018892	2010-01-16 15:18:44.213507	2304221020388080_1.jpg	image/jpg	1245	2010-01-11 21:34:19.896973
13	3	CA	CAD	Commodore 64 Package: Unit + Games + Controllers + MORE	http://cgi.ebay.ca/Commodore-64-Package-Unit-Games-Controllers-MORE_W0QQitemZ360225230174QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3602252301748080_1.jpg	360225230174	good	complete with extras	53.19	2010-01-18 11:22:27	2010-01-11 21:32:10.282508	2010-01-18 12:49:52.657495	3602252301748080_1.jpg	image/jpg	1199	2010-01-11 21:32:10.153491
5	3	AU	AUD	Commodore 64 Bulk Lot	http://cgi.ebay.com.au/Commodore-64-Bulk-Lot_W0QQitemZ220538841983QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2205388419838080_1.jpg	220538841983	average	complete with extras	120.00	2010-01-18 10:58:14	2010-01-11 21:29:02.820992	2010-01-18 12:49:54.215815	2205388419838080_1.jpg	image/jpg	1269	2010-01-11 21:29:02.70127
12	3	CA	CAD	Lot (2) vintage COMMODORE 64 computers NO reserve!	http://cgi.ebay.ca/Lot-2-vintage-COMMODORE-64-computers-NO-reserve_W0QQitemZ290389778539QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2903897785398080_1.jpg	290389778539	average	bare	50.39	2010-01-18 03:03:19	2010-01-11 21:31:44.468471	2010-01-18 12:50:01.380032	2903897785398080_1.jpg	image/jpg	1177	2010-01-11 21:31:44.349822
10	3	CA	CAD	Commodore 64 Computer In Original Box CPU C64	http://cgi.ebay.ca/Commodore-64-Computer-In-Original-Box-CPU-C64_W0QQitemZ160393919078QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1603939190788080_1.jpg	160393919078	good	boxed	31.88	2010-01-17 23:15:18	2010-01-11 21:31:05.31911	2010-01-18 12:50:10.821615	1603939190788080_1.jpg	image/jpg	1203	2010-01-11 21:31:05.199764
22	3	IT	EUR	CONSOLLE COMMODORE 64	http://cgi.ebay.it/CONSOLLE-COMMODORE-64_W0QQitemZ230421517422QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2304215174228080_1.jpg	230421517422	average	complete	10.50	2010-01-17 22:44:18	2010-01-11 21:37:51.63056	2010-01-18 12:50:13.522457	2304215174228080_1.jpg	image/jpg	1302	2010-01-11 21:37:51.523028
28	3	UK	USD	VTG COMMODORE 64 COMPUTER+BOX+1541 DISK DRIVE LOT	http://cgi.ebay.com/VTG-COMMODORE-64-COMPUTER-BOX-1541-DISK-DRIVE-LOT_W0QQitemZ140366225281QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1403662252818080_2.jpg	140366225281	good	boxed	\N	2010-02-06 22:59:23	2010-01-11 21:40:19.532224	2010-01-11 21:40:19.532224	1403662252818080_2.jpg	image/jpg	1129	2010-01-11 21:40:19.38319
6	3	CA	CAD	SLIGHTLY USED COMMODORE 64 IN BOX WORKING WOW 	http://cgi.ebay.ca/SLIGHTLY-USED-COMMODORE-64-IN-BOX-WORKING-WOW_W0QQitemZ250557025504QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2505570255048080_1.jpg	250557025504	good	boxed	72.08	2010-01-11 23:37:27	2010-01-11 21:29:43.683638	2010-01-12 21:35:00.270977	2505570255048080_1.jpg	image/jpg	1064	2010-01-11 21:29:43.560952
23	3	UK	USD	Commodore 64 Keyboard Mouse Games Disks C64 1351 C2N	http://cgi.ebay.com/Commodore-64-Keyboard-Mouse-Games-Disks-C64-1351-C2N_W0QQitemZ130356773281QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1303567732818080_1.jpg	130356773281	average	complete with extras	102.50	2010-01-12 06:23:14	2010-01-11 21:39:20.231683	2010-01-12 21:35:04.259073	1303567732818080_1.jpg	image/jpg	1004	2010-01-11 21:39:19.87204
35	4	UK	USD	Commodore Vic-20 Personal Computer w/ Vic-1541 Floppy	http://cgi.ebay.com/Commodore-Vic-20-Personal-Computer-w-Vic-1541-Floppy_W0QQitemZ310187394757QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3101873947578080_2.jpg	310187394757	good	boxed with extras	\N	2010-02-06 15:44:58	2010-01-12 21:40:52.873544	2010-01-12 21:40:52.873544	3101873947578080_2.jpg	image/jpg	1183	2010-01-12 21:40:52.752183
39	4	US	USD	Vintage VIC-20 Commodore Computer w/original box	http://cgi.ebay.com/Vintage-VIC-20-Commodore-Computer-w-original-box_W0QQitemZ320473306262QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204733062628080_1.jpg	320473306262	good	boxed	18.50	2010-01-14 04:42:20	2010-01-12 21:42:33.349332	2010-01-15 15:08:48.030782	3204733062628080_1.jpg	image/jpg	950	2010-01-12 21:42:33.246826
25	3	UK	USD	Commodore 64 with original box Very Nice	http://cgi.ebay.com/Commodore-64-with-original-box-Very-Nice_W0QQitemZ330393378079QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3303933780798080_1.jpg	330393378079	good	boxed	100.00	2010-01-15 06:41:31	2010-01-11 21:39:49.442626	2010-01-15 15:08:58.224182	3303933780798080_1.jpg	image/jpg	913	2010-01-11 21:39:49.342637
27	3	UK	USD	Commodore 64 Computer + 1541 Disk Drive	http://cgi.ebay.com/Commodore-64-Computer-1541-Disk-Drive_W0QQitemZ320472355919QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3204723559198080_1.jpg	320472355919	good	boxed	81.00	2010-01-15 20:08:12	2010-01-11 21:40:05.545711	2010-01-16 15:18:32.312144	3204723559198080_1.jpg	image/jpg	1166	2010-01-11 21:40:05.427638
32	4	IT	EUR	commodore vic 20	http://cgi.ebay.it/commodore-vic-20_W0QQitemZ150403408853QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1504034088538080_1.jpg	150403408853	poor	bare	17.50	2010-01-17 08:16:03	2010-01-12 21:39:14.542163	2010-01-17 14:38:16.199397	1504034088538080_1.jpg	image/jpg	1082	2010-01-12 21:39:14.432345
31	4	CA	CAD	vintage COMMODORE VIC-20 & DATASSETTE RECORDER 	http://cgi.ebay.ca/vintage-COMMODORE-VIC-20-DATASSETTE-RECORDER_W0QQitemZ170430343841QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704303438418080_2.jpg	170430343841	good	complete	20.56	2010-01-17 02:12:40	2010-01-12 21:36:28.540771	2010-01-17 14:38:29.311445	1704303438418080_2.jpg	image/jpg	1164	2010-01-12 21:36:28.434154
41	4	US	USD	Commodore VIC-20 w/ PAC MAN DIG DUG & Lots of EXTRAS(G)	http://cgi.ebay.com/Commodore-VIC-20-w-PAC-MAN-DIG-DUG-Lots-of-EXTRAS-G_W0QQitemZ350303243029QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3503032430298080_1.jpg	350303243029	good	boxed with extras	46.05	2010-01-17 01:00:17	2010-01-12 21:43:00.64388	2010-01-17 14:38:33.233951	3503032430298080_1.jpg	image/jpg	1297	2010-01-12 21:43:00.526565
36	4	UK	USD	Vintage Commodore Vic 20 home computer	http://cgi.ebay.com/Vintage-Commodore-Vic-20-home-computer_W0QQitemZ170431162106QQcategoryZ4193QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704311621068080_1.jpg	170431162106	good	boxed	26.00	2010-01-16 20:12:08	2010-01-12 21:41:02.822778	2010-01-17 14:38:44.414149	1704311621068080_1.jpg	image/jpg	1014	2010-01-12 21:41:02.699516
38	4	UK	USD	COMMODORE VIC-20 COMPUTER 5 GAMES MANUAL ORIGINAL BOX 	http://cgi.ebay.com/COMMODORE-VIC-20-COMPUTER-5-GAMES-MANUAL-ORIGINAL-BOX_W0QQitemZ380195946182QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3801959461828080_1.jpg	380195946182	good	boxed	46.00	2010-01-20 02:46:28	2010-01-12 21:41:50.002994	2010-01-21 03:44:41.823602	3801959461828080_1.jpg	image/jpg	919	2010-01-12 21:41:49.904824
26	3	UK	USD	Vintage Commodore 64 Computer C64 PC	http://cgi.ebay.com/Vintage-Commodore-64-Computer-C64-PC_W0QQitemZ370316454187QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3703164541878080_1.jpg	370316454187	average	bare	9.95	2010-01-13 01:26:01	2010-01-11 21:39:56.939237	2010-01-13 10:49:28.961894	3703164541878080_1.jpg	image/jpg	981	2010-01-11 21:39:56.835579
57	7	DE	EUR	** COMMODORE 128 MIT ZUBEHÖR  **	http://cgi.ebay.de/COMMODORE-128-MIT-ZUBEHOR_W0QQitemZ290387373845QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2903873738458080_1.jpg	290387373845	average	bare	\N	2010-02-01 23:02:58	2010-01-13 11:44:24.519328	2010-01-13 11:44:24.519328	2903873738458080_1.jpg	image/jpg	970	2010-01-13 11:44:24.393537
61	7	US	USD	Commodore 128 With 1571Disk Drive and System Software	http://cgi.ebay.com/Commodore-128-With-1571Disk-Drive-and-System-Software_W0QQitemZ310187440267QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3101874402678080_2.jpg	310187440267	good	boxed with extras	\N	2010-02-06 19:32:13	2010-01-13 11:51:25.946931	2010-01-13 11:51:25.946931	3101874402678080_2.jpg	image/jpg	1134	2010-01-13 11:51:25.827472
46	5	US	USD	Vintage Working Apple IIe Computer and Keyboard Cover	http://cgi.ebay.com/Vintage-Working-Apple-IIe-Computer-and-Keyboard-Cover_W0QQitemZ170428674985QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704286749858080_1.jpg	170428674985	average	bare	47.23	2010-01-15 02:00:46	2010-01-12 22:11:16.174596	2010-01-15 15:08:55.964496	1704286749858080_1.jpg	image/jpg	1122	2010-01-12 22:11:16.056146
47	5	US	USD	Apple IIe Computer with Monitor 2 floppy drives printer	http://cgi.ebay.com/Apple-IIe-Computer-with-Monitor-2-floppy-drives-printer_W0QQitemZ170429862206QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704298622068080_1.jpg	170429862206	good	complete with extras	26.00	2010-01-15 16:12:33	2010-01-12 22:11:30.248639	2010-01-16 15:18:29.113883	1704298622068080_1.jpg	image/jpg	1160	2010-01-12 22:11:30.132691
64	8	AU	AUD	Sinclair ZX Spectrum 48K	http://cgi.ebay.com.au/Sinclair-ZX-Spectrum-48K_W0QQitemZ130358223496QQcategoryZ1247QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1303582234968080_1.jpg	130358223496	poor	bare	193.00	2010-01-16 08:27:54	2010-01-13 18:13:22.883051	2010-01-16 15:18:39.768204	1303582234968080_1.jpg	image/jpg	1364	2010-01-13 18:13:22.753037
60	7	US	USD	Commodore 128 w/ Original Box (G)	http://cgi.ebay.com/Commodore-128-w-Original-Box-G_W0QQitemZ350303203939QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3503032039398080_1.jpg	350303203939	good	boxed	45.97	2010-01-16 22:17:00	2010-01-13 11:50:58.762533	2010-01-17 14:38:38.531362	3503032039398080_1.jpg	image/jpg	1006	2010-01-13 11:50:58.629314
63	7	US	USD	Commodore 128 Computer	http://cgi.ebay.com/Commodore-128-Computer_W0QQitemZ230422253021QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2304222530218080_1.jpg	230422253021	good	boxed	48.00	2010-01-16 20:19:26	2010-01-13 11:51:55.133688	2010-01-17 14:38:42.112698	2304222530218080_1.jpg	image/jpg	952	2010-01-13 11:51:55.010133
50	6	DE	EUR	Commodore C 16 mit Datasette und Handbuch	http://cgi.ebay.de/Commodore-C-16-mit-Datasette-und-Handbuch_W0QQitemZ260535377145QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605353771458080_1.jpg	260535377145	good	complete	7.16	2010-01-16 16:45:48	2010-01-13 11:10:11.767048	2010-01-17 14:38:49.169398	2605353771458080_1.jpg	image/jpg	1067	2010-01-13 11:10:11.642276
55	7	AU	AUD	Commodore 128	http://cgi.ebay.com.au/Commodore-128_W0QQitemZ150404675854QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1504046758548080_1.jpg	150404675854	average	bare	36.00	2010-01-18 23:15:26	2010-01-13 11:43:14.810777	2010-01-19 01:33:10.090853	1504046758548080_1.jpg	image/jpg	989	2010-01-13 11:43:14.69934
59	7	IT	EUR	RETROCOMPUTER COMMODORE 128  CON ACCESSORI 	http://cgi.ebay.it/RETROCOMPUTER-COMMODORE-128-CON-ACCESSORI_W0QQitemZ310193869078QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3101938690788080_1.jpg	310193869078	average	complete	56.00	2010-01-18 20:16:45	2010-01-13 11:46:28.799054	2010-01-19 01:33:13.039092	3101938690788080_1.jpg	image/jpg	1118	2010-01-13 11:46:28.671623
58	7	DE	EUR	Commodore 128 "Komplettset Top erhalten"	http://cgi.ebay.de/Commodore-128-Komplettset-Top-erhalten_W0QQitemZ280449529125QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804495291258080_1.jpg	280449529125	good	complete with extras	106.00	2010-01-20 19:00:37	2010-01-13 11:44:50.176401	2010-01-21 03:44:32.53229	2804495291258080_1.jpg	image/jpg	1165	2010-01-13 11:44:50.059407
52	6	DE	EUR	Commodore 16 Microcomputer	http://cgi.ebay.de/Commodore-16-Microcomputer_W0QQitemZ200427381877QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004273818778080_1.jpg	200427381877	good	complete	27.19	2010-01-22 09:42:10	2010-01-13 11:10:39.362739	2010-01-23 00:56:37.343581	2004273818778080_1.jpg	image/jpg	1232	2010-01-13 11:10:39.251385
75	9	US	USD	Apple IIc - A2S4100 - w/ Expansion Slot & Plug - Tested	http://cgi.ebay.com/Apple-IIc-A2S4100-w-Expansion-Slot-Plug-Tested_W0QQitemZ370230342624QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3702303426248080_7.jpg	370230342624	good	complete	\N	2010-02-10 23:31:00	2010-01-13 18:54:59.606101	2010-01-13 18:54:59.606101	3702303426248080_7.jpg	image/jpg	1161	2010-01-13 18:54:59.468371
74	9	US	USD	Apple IIc with External 5-1/4 Inch Drive & 8" Screen	http://cgi.ebay.com/Apple-IIc-with-External-5-1-4-Inch-Drive-8-Screen_W0QQitemZ220537275220QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2205372752208080_1.jpg	220537275220	good	complete with extras	53.00	2010-01-14 23:58:24	2010-01-13 18:54:29.946677	2010-01-15 15:08:53.217783	2205372752208080_1.jpg	image/jpg	1011	2010-01-13 18:54:29.81533
77	5	DE	EUR	## APPLE II e # Apple 2e # 1983 # Kult # Apple ][ ##	http://cgi.ebay.de/APPLE-II-e-Apple-2e-1983-Kult-Apple_W0QQitemZ150404361501QQcategoryZ8101QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1504043615018080_1.jpg	150404361501	good	complete with extras	82.00	2010-01-15 20:25:32	2010-01-13 19:42:43.27676	2010-01-16 15:18:36.022214	1504043615018080_1.jpg	image/jpg	1005	2010-01-13 19:42:43.148388
78	10	IT	EUR	Sinclair ZX Spectrum + confezione originale	http://cgi.ebay.it/Sinclair-ZX-Spectrum-confezione-originale_W0QQitemZ390140006763QQcategoryZ126968QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3901400067638080_1.jpg	390140006763	good	boxed	21.50	2010-01-16 08:07:42	2010-01-15 16:34:02.547452	2010-01-16 15:18:37.675928	3901400067638080_1.jpg	image/jpg	1195	2010-01-15 16:34:02.417083
66	8	DE	EUR	ZX Spectrum mit externer Tastatur für Bastler,Sammler	http://cgi.ebay.de/ZX-Spectrum-mit-externer-Tastatur-fuer-Bastler-Sammler_W0QQitemZ270511363155QQcategoryZ8099QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2705113631558080_1.jpg	270511363155	poor	bare	15.50	2010-01-16 13:50:46	2010-01-13 18:15:18.973674	2010-01-16 15:18:41.350574	2705113631558080_1.jpg	image/jpg	1213	2010-01-13 18:15:18.840797
67	8	DE	EUR	Spectrum Sinclair ZX + Zubehör defekt?	http://cgi.ebay.de/Spectrum-Sinclair-ZX-Zubehoer-defekt_W0QQitemZ360225336306QQcategoryZ8099QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3602253363068080_1.jpg	360225336306	poor	complete	52.00	2010-01-16 18:35:58	2010-01-13 18:15:32.300941	2010-01-17 14:38:46.848416	3602253363068080_1.jpg	image/jpg	1214	2010-01-13 18:15:32.178363
72	8	UK	USD	BOXED Sinclair ZX Spectrum Personal computer	http://cgi.ebay.com/BOXED-Sinclair-ZX-Spectrum-Personal-computer_W0QQitemZ280447749484QQcategoryZ11994QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2804477494848080_1.jpg	280447749484	good	boxed	40.65	2010-01-16 16:22:44	2010-01-13 18:24:05.378247	2010-01-17 14:38:51.146597	2804477494848080_1.jpg	image/jpg	1176	2010-01-13 18:24:05.248982
68	8	DE	EUR	SINCLAIR ZX SPECTRUM + 32  SPIELE	http://cgi.ebay.de/SINCLAIR-ZX-SPECTRUM-32-SPIELE_W0QQitemZ170430762307QQcategoryZ8099QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1704307623078080_1.jpg	170430762307	good	complete with extras	42.84	2010-01-17 20:59:27	2010-01-13 18:16:09.394491	2010-01-17 21:07:50.768088	1704307623078080_1.jpg	image/jpg	1407	2010-01-13 18:16:09.272153
73	9	DE	EUR	Apple IIc //c mit zweitem Disk Drive und Handbüchern!	http://cgi.ebay.de/Apple-IIc-c-mit-zweitem-Disk-Drive-und-Handbuechern_W0QQitemZ110477984346QQcategoryZ8101QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1104779843468080_1.jpg	110477984346	good	bare	112.00	2010-01-17 18:50:57	2010-01-13 18:53:48.845991	2010-01-17 21:07:59.067966	1104779843468080_1.jpg	image/jpg	928	2010-01-13 18:53:48.732017
82	3	IT	EUR	commodore 64 I° serie per pezzi di ricambio	http://cgi.ebay.it/commodore-64-I-serie-per-pezzi-di-ricambio_W0QQitemZ250559901586QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2505599015868080_1.jpg	250559901586	poor	bare	5.50	2010-01-17 18:08:28	2010-01-15 16:37:46.997727	2010-01-17 21:08:01.762441	2505599015868080_1.jpg	image/jpg	1077	2010-01-15 16:37:46.892144
70	8	ES	EUR	sinclair zx spectrum + caja + cables. 	http://cgi.ebay.es/sinclair-zx-spectrum-caja-cables_W0QQitemZ200427687501QQcategoryZ89183QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004276875018080_1.jpg	200427687501	average	boxed	38.00	2010-01-18 05:31:33	2010-01-13 18:19:17.899865	2010-01-18 12:49:55.5661	2004276875018080_1.jpg	image/jpg	1165	2010-01-13 18:19:17.772646
85	3	US	USD	COMMODORE 64/1541 computer system w/cables+games & more	http://cgi.ebay.com/COMMODORE-64-1541-computer-system-w-cables-games-more_W0QQitemZ300385838011QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003858380118080_1.jpg	300385838011	good	complete with extras	158.05	2010-01-18 02:56:41	2010-01-16 15:30:26.587878	2010-01-18 12:50:02.581405	3003858380118080_1.jpg	image/jpg	1252	2010-01-16 15:30:26.44908
71	8	FR	EUR	ZX SPECTRUM + 4 JEUX CASSETTES 	http://cgi.ebay.fr/ZX-SPECTRUM-4-JEUX-CASSETTES_W0QQitemZ350304019462QQcategoryZ4193QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3503040194628080_1.jpg	350304019462	average	bare	30.50	2010-01-18 20:49:51	2010-01-13 18:20:45.55624	2010-01-19 01:33:13.685015	3503040194628080_1.jpg	image/jpg	1187	2010-01-13 18:20:45.244565
86	3	US	USD	Commodore 64 With Disk Drive Parts Repair Vintage	http://cgi.ebay.com/Commodore-64-With-Disk-Drive-Parts-Repair-Vintage_W0QQitemZ370319091474QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3703190914748080_1.jpg	370319091474	average	complete	14.95	2010-01-18 18:28:58	2010-01-16 15:31:59.549644	2010-01-19 01:33:14.960619	3703190914748080_1.jpg	image/jpg	997	2010-01-16 15:31:59.455552
83	3	IT	EUR	COMMODORE 64 PER PEZZI DI RICAMBIO NON FUNZIONANTE	http://cgi.ebay.it/COMMODORE-64-PER-PEZZI-DI-RICAMBIO-NON-FUNZIONANTE_W0QQitemZ260534897857QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605348978578080_1.jpg	260534897857	poor	bare	3.50	2010-01-18 15:06:43	2010-01-15 16:37:57.186245	2010-01-19 01:33:19.629912	2605348978578080_1.jpg	image/jpg	1064	2010-01-15 16:37:57.085825
79	10	IT	EUR	Zx Spectrum Sinclair in box bello ma non testato	http://cgi.ebay.it/Zx-Spectrum-Sinclair-in-box-bello-ma-non-testato_W0QQitemZ270514242542QQcategoryZ126968QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705142425428080_1.jpg	270514242542	good	boxed	22.00	2010-01-19 16:16:27	2010-01-15 16:34:16.255059	2010-01-20 02:26:48.052207	2705142425428080_1.jpg	image/jpg	1326	2010-01-15 16:34:16.152022
80	10	IT	EUR	ZX Spectrum+ 16K	http://cgi.ebay.it/ZX-Spectrum-16K_W0QQitemZ280451592524QQcategoryZ126968QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2804515925248080_1.jpg	280451592524	good	complete	20.50	2010-01-21 22:33:10	2010-01-15 16:34:46.780197	2010-01-21 23:48:26.479077	2804515925248080_1.jpg	image/jpg	1262	2010-01-15 16:34:46.672235
81	10	FR	EUR	Jeux pour Ordinateur ZX SPECTRUM +   48K   de SINCLAIR	http://cgi.ebay.fr/Jeux-pour-Ordinateur-ZX-SPECTRUM-48K-de-SINCLAIR_W0QQitemZ290391591947QQcategoryZ120262QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2903915919478080_1.jpg	290391591947	good	complete	25.51	2010-01-21 21:45:26	2010-01-15 16:36:47.62652	2010-01-21 23:48:42.456855	2903915919478080_1.jpg	image/jpg	1080	2010-01-15 16:36:47.525127
90	3	DE	EUR	Commodore C 64 Sammlung, Floppy, 160 Disk.  1 Joyst.	http://cgi.ebay.de/Commodore-C-64-Sammlung-Floppy-160-Disk-1-Joyst_W0QQitemZ230421426498QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2304214264988080_2.jpg	230421426498	good	complete with extras	24.99	2010-01-17 19:30:01	2010-01-16 15:34:12.713364	2010-01-17 21:07:57.423398	2304214264988080_2.jpg	image/jpg	1086	2010-01-16 15:34:12.60977
96	1	US	USD	vintage Amiga 1000 computing engine console dog print	http://cgi.ebay.com/vintage-Amiga-1000-computing-engine-console-dog-print_W0QQitemZ120518097971QQcategoryZ4598QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1205180979718080_1.jpg	120518097971	average	complete with extras	67.66	2010-01-17 18:47:18	2010-01-16 15:39:45.261533	2010-01-17 21:08:01.105831	1205180979718080_1.jpg	image/jpg	1094	2010-01-16 15:39:45.16287
89	3	DE	EUR	Commodore 64 komplett mit Monitor	http://cgi.ebay.de/Commodore-64-komplett-mit-Monitor_W0QQitemZ230421367404QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304213674048080_1.jpg	230421367404	good	complete with extras	40.50	2010-01-17 17:21:43	2010-01-16 15:33:59.137668	2010-01-17 21:08:03.808367	2304213674048080_1.jpg	image/jpg	1090	2010-01-16 15:33:59.048429
91	1	AU	AUD	Amiga 1000 Computer with 68030 CPU	http://cgi.ebay.com.au/Amiga-1000-Computer-with-68030-CPU_W0QQitemZ150404675753QQcategoryZ4598QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1504046757538080_2.jpg	150404675753	poor	bare	740.01	2010-01-18 23:14:45	2010-01-16 15:37:40.488563	2010-01-19 01:33:11.252807	1504046757538080_2.jpg	image/jpg	806	2010-01-16 15:37:40.382691
94	1	DE	EUR	Amiga 1000 + Laufwerk	http://cgi.ebay.de/Amiga-1000-Laufwerk_W0QQitemZ250561941509QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2505619415098080_1.jpg	250561941509	good	complete with extras	72.00	2010-01-18 17:48:12	2010-01-16 15:38:33.403117	2010-01-19 01:33:15.861029	2505619415098080_1.jpg	image/jpg	1153	2010-01-16 15:38:33.305876
99	4	IT	EUR	COMMODORE VIC 20 - OTTIMO STATO	http://cgi.ebay.it/COMMODORE-VIC-20-OTTIMO-STATO_W0QQitemZ300386568434QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3003865684348080_1.jpg	300386568434	good	complete	25.50	2010-01-18 15:13:43	2010-01-16 15:42:07.455371	2010-01-19 01:33:19.288346	3003865684348080_1.jpg	image/jpg	1325	2010-01-16 15:42:07.334989
88	3	US	USD	Commodore 64 1541 Computer System With Floppy/Cables	http://cgi.ebay.com/Commodore-64-1541-Computer-System-With-Floppy-Cables_W0QQitemZ310194132774QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3101941327748080_1.jpg	310194132774	average	complete with extras	34.00	2010-01-19 22:01:54	2010-01-16 15:32:34.362442	2010-01-20 02:26:55.066911	3101941327748080_1.jpg	image/jpg	1053	2010-01-16 15:32:34.276473
105	5	US	USD	Apple IIe //e 2e Vintage Computer with Monitor + Extras	http://cgi.ebay.com/Apple-IIe-e-2e-Vintage-Computer-with-Monitor-Extras_W0QQitemZ330395714849QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3303957148498080_1.jpg	330395714849	good	complete with extras	255.00	2010-01-20 23:06:25	2010-01-17 13:45:55.751348	2010-01-21 03:44:25.540457	3303957148498080_1.jpg	image/jpg	1199	2010-01-17 13:45:55.602701
100	4	IT	EUR	COMMODORE VIC 20 FUNZIONANTE RARITà DA COLLEZIONE	http://cgi.ebay.it/COMMODORE-VIC-20-FUNZIONANTE-RARITa-DA-COLLEZIONE_W0QQitemZ320474444992QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204744449928080_1.jpg	320474444992	average	boxed	20.50	2010-01-20 19:16:32	2010-01-16 15:42:37.803707	2010-01-21 03:44:29.679924	3204744449928080_1.jpg	image/jpg	983	2010-01-16 15:42:37.685525
92	1	AU	AUD	Amiga 1000 - Complete System in great working order! 	http://cgi.ebay.com.au/Amiga-1000-Complete-System-in-great-working-order_W0QQitemZ280449898439QQcategoryZ4598QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2804498984398080_1.jpg	280449898439	good	complete with extras	122.50	2010-01-21 09:42:54	2010-01-16 15:38:01.559375	2010-01-21 11:32:48.313808	2804498984398080_1.jpg	image/jpg	1258	2010-01-16 15:38:01.422269
97	4	US	USD	Working Vintage Commodore VIC 20 Computer + EXTRAS!	http://cgi.ebay.com/Working-Vintage-Commodore-VIC-20-Computer-EXTRAS_W0QQitemZ370320702342QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3703207023428080_1.jpg	370320702342	good	boxed with extras	26.00	2010-01-21 22:35:56	2010-01-16 15:41:27.76506	2010-01-21 23:48:24.733982	3703207023428080_1.jpg	image/jpg	1450	2010-01-16 15:41:27.549159
106	5	US	USD	Apple IIe Vintage Retro Computer System A2S2064	http://cgi.ebay.com/Apple-IIe-Vintage-Retro-Computer-System-A2S2064_W0QQitemZ110481665683QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104816656838080_1.jpg	110481665683	good	bare	20.95	2010-01-22 04:42:15	2010-01-17 13:46:07.502908	2010-01-22 09:07:31.772679	1104816656838080_1.jpg	image/jpg	990	2010-01-17 13:46:07.409645
98	4	US	USD	Commodore VIC 20 Computer w/Power and TV Adaptor + BOX	http://cgi.ebay.com/Commodore-VIC-20-Computer-w-Power-and-TV-Adaptor-BOX_W0QQitemZ220540897753QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2205408977538080_1.jpg	220540897753	good	boxed	18.01	2010-01-22 04:32:45	2010-01-16 15:41:36.307201	2010-01-22 09:07:33.493292	2205408977538080_1.jpg	image/jpg	1417	2010-01-16 15:41:36.21736
102	4	DE	EUR	Commodore VC 20 mit Datacette u. Ram Card	http://cgi.ebay.de/Commodore-VC-20-mit-Datacette-u-Ram-Card_W0QQitemZ280451012461QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804510124618080_1.jpg	280451012461	average	complete with extras	30.50	2010-01-23 19:32:58	2010-01-16 15:43:32.597381	2010-01-23 20:16:52.132741	2804510124618080_1.jpg	image/jpg	1065	2010-01-16 15:43:32.508995
101	4	DE	EUR	Commodore VC 20 mit allem Zubehör und OVP	http://cgi.ebay.de/Commodore-VC-20-mit-allem-Zubehoer-und-OVP_W0QQitemZ230424206820QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304242068208080_1.jpg	230424206820	good	boxed with extras	22.50	2010-01-24 16:43:31	2010-01-16 15:43:16.256163	2010-01-24 18:40:10.866544	2304242068208080_1.jpg	image/jpg	1223	2010-01-16 15:43:16.147806
104	5	DE	EUR	2e APPLE IIe 2 Laufwerke DISC II Monitor A2M2010P /II e	http://cgi.ebay.de/2e-APPLE-IIe-2-Laufwerke-DISC-II-Monitor-A2M2010P-II-e_W0QQitemZ350305221926QQcategoryZ8101QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3503052219268080_1.jpg	350305221926	good	complete with extras	115.50	2010-01-24 18:50:57	2010-01-17 13:45:09.533657	2010-01-24 21:07:10.403377	3503052219268080_1.jpg	image/jpg	1158	2010-01-17 13:45:09.410279
95	1	DE	EUR	!!! Commodore Amiga 1000 A1000 512 kB RAM 100% OK !!!	http://cgi.ebay.de/Commodore-Amiga-1000-A1000-512-kB-RAM-100-OK_W0QQitemZ270515905206QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705159052068080_1.jpg	270515905206	average	bare	116.00	2010-01-25 20:07:08	2010-01-16 15:38:42.315121	2010-01-25 22:51:15.976227	2705159052068080_1.jpg	image/jpg	889	2010-01-16 15:38:42.194543
103	5	DE	EUR	Apple IIe + 2x Disk II + Monitor III + DMP Printer uvm.	http://cgi.ebay.de/Apple-IIe-2x-Disk-II-Monitor-III-DMP-Printer-uvm_W0QQitemZ320474975034QQcategoryZ171QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204749750348080_1.jpg	320474975034	good	complete with extras	223.00	2010-01-24 21:38:57	2010-01-17 13:44:58.056974	2010-01-25 22:55:48.135098	3204749750348080_1.jpg	image/jpg	1272	2010-01-17 13:44:57.884801
93	1	DE	EUR	Amiga 1000 mit 2MB RAM-Erweiterung + Zubehör - Sammler!	http://cgi.ebay.de/Amiga-1000-mit-2MB-RAM-Erweiterung-Zubehoer-Sammler_W0QQitemZ190365087988QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903650879888080_1.jpg	190365087988	good	complete with extras	101.00	2010-01-17 11:33:25	2010-01-16 15:38:22.205873	2010-01-17 14:38:14.327217	1903650879888080_1.jpg	image/jpg	1141	2010-01-16 15:38:22.036529
76	9	US	USD	Vintage Apple IIC II C Personal Computer	http://cgi.ebay.com/Vintage-Apple-IIC-II-C-Personal-Computer_W0QQitemZ330393933762QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3303939337628080_1.jpg	330393933762	good	complete	21.50	2010-01-17 01:26:21	2010-01-13 18:55:15.622162	2010-01-17 14:38:31.349667	3303939337628080_1.jpg	image/jpg	1117	2010-01-13 18:55:15.490102
111	13	DE	EUR	Commodore CBM Pet 2001 3001 3032	http://cgi.ebay.de/Commodore-CBM-Pet-2001-3001-3032_W0QQitemZ230421444865QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2304214448658080_1.jpg	230421444865	average	bare	74.93	2010-01-17 19:50:54	2010-01-17 14:34:48.701334	2010-01-17 21:07:54.417475	2304214448658080_1.jpg	image/jpg	1171	2010-01-17 14:34:48.604713
113	15	DE	EUR	COMMODORE CBM 610 für Bastler	http://cgi.ebay.de/COMMODORE-CBM-610-fuer-Bastler_W0QQitemZ250559873945QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2505598739458080_1.jpg	250559873945	average	bare	42.50	2010-01-17 17:12:11	2010-01-17 15:07:37.418489	2010-01-17 21:08:09.680483	2505598739458080_1.jpg	image/jpg	880	2010-01-17 15:07:37.203039
87	3	US	USD	Commodore 64 - Keyboard and Floppy Disk - VGC - NR	http://cgi.ebay.com/Commodore-64-Keyboard-and-Floppy-Disk-VGC-NR_W0QQitemZ110481667154QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1104816671548080_1.jpg	110481667154	average	complete	6.00	2010-01-18 04:53:32	2010-01-16 15:32:11.043004	2010-01-18 12:49:57.904267	1104816671548080_1.jpg	image/jpg	1256	2010-01-16 15:32:10.952562
115	17	DE	EUR	ATARI 400+810 disk drive rarität mit originalverpackung	http://cgi.ebay.de/ATARI-400-810-disk-drive-raritaet-mit-originalverpackung_W0QQitemZ260537144039QQcategoryZ8091QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2605371440398080_1.jpg	260537144039	good	boxed with extras	157.00	2010-01-18 04:45:52	2010-01-17 21:59:30.063311	2010-01-18 12:50:00.159922	2605371440398080_1.jpg	image/jpg	1300	2010-01-17 21:59:29.92869
121	18	US	USD	1984 Apple Macintosh 128K M0001 with External Drive	http://cgi.ebay.com/1984-Apple-Macintosh-128K-M0001-with-External-Drive_W0QQitemZ330395764451QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3303957644518080_1.jpg	330395764451	good	complete with extras	\N	2010-02-15 04:27:09	2010-01-18 21:50:12.275292	2010-01-18 21:50:12.275292	3303957644518080_1.jpg	image/jpg	1278	2010-01-18 21:50:12.171543
122	18	US	USD	Apple Macintosh 128K M0001 Computer For Parts	http://cgi.ebay.com/Apple-Macintosh-128K-M0001-Computer-For-Parts_W0QQitemZ390144407472QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3901444074728080_1.jpg	390144407472	poor	bare	\N	2010-02-16 06:05:57	2010-01-18 21:52:37.347948	2010-01-18 21:52:37.347948	3901444074728080_1.jpg	image/jpg	1193	2010-01-18 21:52:37.242589
114	12	DE	EUR	Antik * Klassische Computer Commodore PET 2001-16 * RAR	http://cgi.ebay.de/Antik-Klassische-Computer-Commodore-PET-2001-16-RAR_W0QQitemZ120515868332QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1205158683328080_1.jpg	120515868332	good	bare	186.00	2010-01-19 19:23:29	2010-01-17 15:16:06.455729	2010-01-20 02:26:49.146985	1205158683328080_1.jpg	image/jpg	1044	2010-01-17 15:16:05.97008
117	17	US	USD	Excellent Atari 400 Computer In Box w/Upgraded Keyboard	http://cgi.ebay.com/Excellent-Atari-400-Computer-In-Box-w-Upgraded-Keyboard_W0QQitemZ250563176917QQcategoryZ82631QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2505631769178080_1.jpg	250563176917	good	boxed	28.00	2010-01-21 01:46:56	2010-01-17 22:00:36.354198	2010-01-21 03:44:24.726514	2505631769178080_1.jpg	image/jpg	1394	2010-01-17 22:00:36.238248
127	3	US	USD	COMMODORE 64 IN ORIGINAL BOX ~ NO RESERVE	http://cgi.ebay.com/COMMODORE-64-IN-ORIGINAL-BOX-NO-RESERVE_W0QQitemZ150404995794QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1504049957948080_1.jpg	150404995794	good	boxed	21.50	2010-01-20 05:42:15	2010-01-19 11:34:51.26005	2010-01-21 03:44:39.308117	1504049957948080_1.jpg	image/jpg	1296	2010-01-19 11:34:51.150484
126	3	US	USD	COMMODORE 64 COMPUTER IN BOX ORIGINALLY PACKED	http://cgi.ebay.com/COMMODORE-64-COMPUTER-IN-BOX-ORIGINALLY-PACKED_W0QQitemZ380195943143QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3801959431438080_1.jpg	380195943143	good	boxed	27.00	2010-01-20 02:37:47	2010-01-19 11:34:36.271566	2010-01-21 03:44:44.142849	3801959431438080_1.jpg	image/jpg	857	2010-01-19 11:34:36.1578
118	17	US	USD	vintage ATARI 400 Computer with Box 	http://cgi.ebay.com/vintage-ATARI-400-Computer-with-Box_W0QQitemZ170432606942QQcategoryZ82631QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704326069428080_1.jpg	170432606942	good	bare	29.29	2010-01-22 03:14:25	2010-01-17 22:00:46.29538	2010-01-22 09:07:30.305723	1704326069428080_1.jpg	image/jpg	1517	2010-01-17 22:00:46.183497
112	14	DE	EUR	Commodore CBM 8250LP 8250 LP Floppy mit OVP	http://cgi.ebay.de/Commodore-CBM-8250LP-8250-LP-Floppy-mit-OVP_W0QQitemZ250562923384QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2505629233848080_1.jpg	250562923384	good	boxed	128.00	2010-01-23 19:10:49	2010-01-17 14:51:59.82793	2010-01-23 20:17:13.160231	2505629233848080_1.jpg	image/jpg	1181	2010-01-17 14:51:59.572904
119	8	AU	AUD	**SINCLAIR ZX SPECTRUM 48k** Classic Microcomputer 1982	http://cgi.ebay.com.au/SINCLAIR-ZX-SPECTRUM-48k-Classic-Microcomputer-1982_W0QQitemZ120518701562QQcategoryZ1247QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1205187015628080_1.jpg	120518701562	good	boxed with extras	169.70	2010-01-23 10:41:52	2010-01-17 22:35:53.662664	2010-01-23 20:17:42.652818	1205187015628080_1.jpg	image/jpg	1466	2010-01-17 22:35:53.546252
120	8	DE	EUR	ZX Spectrum mit viel Zubehör	http://cgi.ebay.de/ZX-Spectrum-mit-viel-Zubehoer_W0QQitemZ220541921255QQcategoryZ8099QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2205419212558080_1.jpg	220541921255	good	complete with extras	58.00	2010-01-24 12:45:19	2010-01-17 22:36:28.606538	2010-01-24 18:40:24.653604	2205419212558080_1.jpg	image/jpg	1093	2010-01-17 22:36:28.488161
110	13	DE	EUR	Commodore 3032 CBM 3001 Series  PET Nachfolger defekt	http://cgi.ebay.de/Commodore-3032-CBM-3001-Series-PET-Nachfolger-defekt_W0QQitemZ250564665337QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2505646653378080_1.jpg	250564665337	poor	bare	49.00	2010-01-26 23:23:42	2010-01-17 14:33:17.468942	2010-01-27 11:51:29.26293	2505646653378080_1.jpg	image/jpg	2109	2010-01-17 14:33:17.342028
124	18	UK	USD	Original Macintosh 128K (M0001)	http://cgi.ebay.com/Original-Macintosh-128K-M0001_W0QQitemZ110482737881QQcategoryZ4193QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1104827378818080_1.jpg	110482737881	average	complete	398.30	2010-01-27 19:09:12	2010-01-18 21:56:53.098112	2010-01-28 10:54:49.497359	1104827378818080_1.jpg	image/jpg	1065	2010-01-18 21:56:52.808153
116	17	DE	EUR	Atari 400  mit Speichererweiterung und Zusatzfunktionen	http://cgi.ebay.de/Atari-400-mit-Speichererweiterung-und-Zusatzfunktionen_W0QQitemZ260539211837QQcategoryZ23194QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605392118378080_1.jpg	260539211837	good	complete	41.50	2010-01-27 14:58:36	2010-01-17 21:59:39.463292	2010-01-28 10:55:54.59354	2605392118378080_1.jpg	image/jpg	994	2010-01-17 21:59:39.335478
146	4	US	USD	Commodore VIC-20 Computer	http://cgi.ebay.com/Commodore-VIC-20-Computer_W0QQitemZ370320025299QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3703200252998080_1.jpg	370320025299	poor	bare	\N	2010-02-12 20:00:08	2010-01-19 11:46:33.234926	2010-01-19 11:46:33.234926	3703200252998080_1.jpg	image/jpg	1148	2010-01-19 11:46:33.128798
128	3	US	USD	Commodore 64 with Floppy Drive	http://cgi.ebay.com/Commodore-64-with-Floppy-Drive_W0QQitemZ120518319633QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1205183196338080_1.jpg	120518319633	average	complete with extras	22.50	2010-01-20 06:47:46	2010-01-19 11:35:05.366275	2010-01-21 03:44:34.056637	1205183196338080_1.jpg	image/jpg	1067	2010-01-19 11:35:05.230617
134	3	DE	EUR	Commodore 64 Brotkasten - mit Zubehör 	http://cgi.ebay.de/Commodore-64-Brotkasten-mit-Zubehoer_W0QQitemZ170434224329QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704342243298080_1.jpg	170434224329	good	complete with extras	10.61	2010-01-21 17:22:29	2010-01-19 11:38:38.074665	2010-01-21 18:34:29.741433	1704342243298080_1.jpg	image/jpg	1233	2010-01-19 11:38:37.947053
129	3	US	USD	Vintage Commodore 64 for parts or repair  -  No Res.	http://cgi.ebay.com/Vintage-Commodore-64-for-parts-or-repair-No-Res_W0QQitemZ300387115816QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3003871158168080_1.jpg	300387115816	average	bare	21.50	2010-01-22 03:18:59	2010-01-19 11:35:36.687964	2010-01-22 09:07:28.135095	3003871158168080_1.jpg	image/jpg	970	2010-01-19 11:35:36.57328
135	3	DE	EUR	Commodore 64	http://cgi.ebay.de/Commodore-64_W0QQitemZ140375336749QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1403753367498080_1.jpg	140375336749	average	bare	13.61	2010-01-22 19:06:28	2010-01-19 11:38:56.986985	2010-01-23 00:56:36.837408	1403753367498080_1.jpg	image/jpg	1132	2010-01-19 11:38:56.869261
144	4	IT	EUR	COMMODORE VIC 20 FUNZIONANTE RARITà DA COLLEZIONE	http://cgi.ebay.it/COMMODORE-VIC-20-FUNZIONANTE-RARITa-DA-COLLEZIONE_W0QQitemZ320476251568QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204762515688080_1.jpg	320476251568	good	boxed	25.50	2010-01-22 19:17:07	2010-01-19 11:45:45.324453	2010-01-23 00:56:39.496871	3204762515688080_1.jpg	image/jpg	1086	2010-01-19 11:45:45.207733
140	3	IT	EUR	Commodore 64 I° tipo + joystick e cartuccia Omega Race	http://cgi.ebay.it/Commodore-64-I-tipo-joystick-e-cartuccia-Omega-Race_W0QQitemZ160395627481QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1603956274818080_1.jpg	160395627481	average	complete	21.50	2010-01-23 19:51:32	2010-01-19 11:40:55.502482	2010-01-23 20:16:38.617012	1603956274818080_1.jpg	image/jpg	1325	2010-01-19 11:40:55.384844
131	3	US	USD	Commodore 64 VIC-20 Computer (ASSY 326298 REV A 1982) 	http://cgi.ebay.com/Commodore-64-VIC-20-Computer-ASSY-326298-REV-A-1982_W0QQitemZ250565466647QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2505654666478080_1.jpg	250565466647	good	bare	5.50	2010-01-23 01:07:31	2010-01-19 11:36:02.703634	2010-01-23 20:17:52.003889	2505654666478080_1.jpg	image/jpg	939	2010-01-19 11:36:02.586967
137	3	DE	EUR	Commodore 64 + Floppy Laufwerk 1541 + Zubehör	http://cgi.ebay.de/Commodore-64-Floppy-Laufwerk-1541-Zubehoer_W0QQitemZ230425566221QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2304255662218080_1.jpg	230425566221	good	boxed	17.50	2010-01-24 17:32:17	2010-01-19 11:39:30.217208	2010-01-24 18:40:07.077344	2304255662218080_1.jpg	image/jpg	1021	2010-01-19 11:39:30.095118
142	3	IT	EUR	commodore 64  c64  completo 	http://cgi.ebay.it/commodore-64-c64-completo_W0QQitemZ170433658296QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704336582968080_1.jpg	170433658296	good	complete	11.50	2010-01-24 16:55:46	2010-01-19 11:41:32.64253	2010-01-24 18:40:09.991667	1704336582968080_1.jpg	image/jpg	1214	2010-01-19 11:41:32.531816
136	3	DE	EUR	Commodore 64	http://cgi.ebay.de/Commodore-64_W0QQitemZ270516655604QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2705166556048080_1.jpg	270516655604	average	bare	15.50	2010-01-24 11:12:01	2010-01-19 11:39:09.550656	2010-01-24 18:40:43.187059	2705166556048080_1.jpg	image/jpg	1199	2010-01-19 11:39:09.45539
132	3	US	USD	Vintage Commodore 64 Computer w/ Manual, Box, and Plug	http://cgi.ebay.com/Vintage-Commodore-64-Computer-w-Manual-Box-and-Plug_W0QQitemZ280452455864QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2804524558648080_1.jpg	280452455864	good	boxed	20.55	2010-01-24 00:19:31	2010-01-19 11:36:15.44418	2010-01-24 18:41:47.047469	2804524558648080_1.jpg	image/jpg	1149	2010-01-19 11:36:15.334709
138	3	DE	EUR	Commodore 64  braun  C64 + Netzteil  Commodore64	http://cgi.ebay.de/Commodore-64-braun-C64-Netzteil-Commodore64_W0QQitemZ270516377825QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2705163778258080_1.jpg	270516377825	good	bare	6.05	2010-01-24 19:00:06	2010-01-19 11:39:43.72874	2010-01-24 21:07:01.611495	2705163778258080_1.jpg	image/jpg	1213	2010-01-19 11:39:43.615553
139	3	DE	EUR	Commodore C64 C 64 + Riesiges Set mit Spielen u.Zubehör	http://cgi.ebay.de/Commodore-C64-C-64-Riesiges-Set-mit-Spielen-u-Zubehoer_W0QQitemZ290392631094QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2903926310948080_1.jpg	290392631094	good	complete with extras	45.95	2010-01-24 19:08:35	2010-01-19 11:39:54.883483	2010-01-24 21:07:02.209525	2903926310948080_1.jpg	image/jpg	1413	2010-01-19 11:39:54.774704
149	4	US	USD	Commodore Vic-20	http://cgi.ebay.com/Commodore-Vic-20_W0QQitemZ150406680875QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1504066808758080_1.jpg	150406680875	good	boxed	15.50	2010-01-25 20:20:33	2010-01-19 11:47:32.234392	2010-01-25 22:51:12.130317	1504066808758080_1.jpg	image/jpg	1071	2010-01-19 11:47:32.127358
143	3	IT	EUR	COMMODORE 64 1° SERIE FONDO DI DEPOSITO MAGAZZINO! RARO	http://cgi.ebay.it/COMMODORE-64-1-SERIE-FONDO-DI-DEPOSITO-MAGAZZINO-RARO_W0QQitemZ190366339537QQcategoryZ4598QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1903663395378080_1.jpg	190366339537	good	boxed	225.00	2010-01-28 19:24:10	2010-01-19 11:41:46.601755	2010-01-28 20:58:43.97244	1903663395378080_1.jpg	image/jpg	1126	2010-01-19 11:41:46.476032
125	3	US	USD	BOXED Commodore 64	http://cgi.ebay.com/BOXED-Commodore-64_W0QQitemZ150404807044QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1504048070448080_1.jpg	150404807044	good	boxed	35.00	2010-01-19 13:56:23	2010-01-19 11:34:09.261349	2010-01-19 14:11:27.818935	1504048070448080_1.jpg	image/jpg	1256	2010-01-19 11:34:09.140112
145	4	US	USD	Vintage Commodore Vic 20 Computer Original Box - unused	http://cgi.ebay.com/Vintage-Commodore-Vic-20-Computer-Original-Box-unused_W0QQitemZ270514472404QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2705144724048080_1.jpg	270514472404	good	boxed	65.00	2010-01-20 01:22:11	2010-01-19 11:46:16.195538	2010-01-20 02:26:57.66654	2705144724048080_1.jpg	image/jpg	998	2010-01-19 11:46:16.025288
166	19	US	USD	Vintage Macintosh 512K Computer Works?	http://cgi.ebay.com/Vintage-Macintosh-512K-Computer-Works_W0QQitemZ400097776821QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/4000977768218080_1.jpg	400097776821	poor	bare	\N	2010-02-15 06:26:31	2010-01-20 22:52:42.296846	2010-01-20 22:52:42.296846	4000977768218080_1.jpg	image/jpg	1065	2010-01-20 22:52:42.189283
156	7	US	USD	Commodore 128 with power supply etc in good condition	http://cgi.ebay.com/Commodore-128-with-power-supply-etc-in-good-condition_W0QQitemZ180456562978QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1804565629788080_1.jpg	180456562978	good	complete	51.00	2010-01-21 18:45:10	2010-01-19 14:03:31.800401	2010-01-21 23:49:03.678959	1804565629788080_1.jpg	image/jpg	1076	2010-01-19 14:03:31.677393
162	6	US	USD	Commodore 16 with box 	http://cgi.ebay.com/Commodore-16-with-box_W0QQitemZ230424638900QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304246389008080_1.jpg	230424638900	good	boxed	32.00	2010-01-22 15:53:31	2010-01-19 14:07:27.605974	2010-01-23 00:56:41.151724	2304246389008080_1.jpg	image/jpg	954	2010-01-19 14:07:27.490701
164	2	DE	EUR	Commodore Pet 2001 mit bunter Tastatur	http://cgi.ebay.de/Commodore-Pet-2001-mit-bunter-Tastatur_W0QQitemZ190365958487QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1903659584878080_1.jpg	190365958487	good	bare	228.00	2010-01-24 17:56:55	2010-01-19 14:13:45.873969	2010-01-24 18:40:04.919845	1903659584878080_1.jpg	image/jpg	1413	2010-01-19 14:13:45.755103
150	4	DE	EUR	Commodore VC 20 mit Originalverpackung VC-20 VC20 CBM	http://cgi.ebay.de/Commodore-VC-20-mit-Originalverpackung-VC-20-VC20-CBM_W0QQitemZ280453678831QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2804536788318080_1.jpg	280453678831	good	bare	12.70	2010-01-24 07:57:12	2010-01-19 11:49:27.411351	2010-01-24 21:07:04.479233	2804536788318080_1.jpg	image/jpg	1498	2010-01-19 11:49:27.298295
168	19	US	USD	Apple Macintosh 512K MODEL NO. M0001W 	http://cgi.ebay.com/Apple-Macintosh-512K-MODEL-NO-M0001W_W0QQitemZ350307635381QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3503076353818080_1.jpg	350307635381	average	bare	45.00	2010-01-25 20:21:39	2010-01-20 22:56:29.66148	2010-01-25 22:51:04.155927	3503076353818080_1.jpg	image/jpg	994	2010-01-20 22:56:29.569584
160	6	DE	EUR	Commodore C 16 mit Speicherweiterung  60k ,viel Zubehör	http://cgi.ebay.de/Commodore-C-16-mit-Speicherweiterung-60k-viel-Zubehoer_W0QQitemZ230424562293QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2304245622938080_1.jpg	230424562293	good	complete with extras	33.60	2010-01-25 19:30:36	2010-01-19 14:06:48.421595	2010-01-25 22:51:36.360581	2304245622938080_1.jpg	image/jpg	1447	2010-01-19 14:06:48.302306
157	7	US	USD	Commodore 128 Computer, Excellent & Complete!	http://cgi.ebay.com/Commodore-128-Computer-Excellent-Complete_W0QQitemZ280453090650QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2804530906508080_1.jpg	280453090650	good	boxed	102.50	2010-01-24 23:59:51	2010-01-19 14:03:53.340115	2010-01-25 22:56:23.443275	2804530906508080_1.jpg	image/jpg	1057	2010-01-19 14:03:53.206559
159	6	DE	EUR	Commodore 16 mit Datasette Netzgerät Handbücher neu 	http://cgi.ebay.de/Commodore-16-mit-Datasette-Netzgeraet-Handbuecher-neu_W0QQitemZ310194525154QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3101945251548080_1.jpg	310194525154	good	complete with extras	41.50	2010-01-24 18:49:38	2010-01-19 14:06:39.162097	2010-01-25 23:05:55.303088	3101945251548080_1.jpg	image/jpg	1293	2010-01-19 14:06:39.051746
161	6	US	USD	Commodore 16 MINT CONDITION in box!	http://cgi.ebay.com/Commodore-16-MINT-CONDITION-in-box_W0QQitemZ260539613054QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2605396130548080_1.jpg	260539613054	good	boxed	15.65	2010-01-27 23:46:45	2010-01-19 14:07:15.392007	2010-01-28 10:52:39.588665	2605396130548080_1.jpg	image/jpg	1269	2010-01-19 14:07:15.276848
163	13	DE	EUR	Commodore CBM 3032 (PET Nachfolger)	http://cgi.ebay.de/Commodore-CBM-3032-PET-Nachfolger_W0QQitemZ130359935522QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1303599355228080_1.jpg	130359935522	good	bare	46.60	2010-01-27 22:45:25	2010-01-19 14:10:43.117727	2010-01-28 10:52:40.608255	1303599355228080_1.jpg	image/jpg	1330	2010-01-19 14:10:42.973097
151	4	DE	EUR	Commodore VC20 in original Verpackung - Kurztest ok	http://cgi.ebay.de/Commodore-VC20-in-original-Verpackung-Kurztest-ok_W0QQitemZ250565381627QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2505653816278080_1.jpg	250565381627	good	boxed	40.00	2010-01-27 22:00:52	2010-01-19 11:49:38.056285	2010-01-28 10:53:00.920959	2505653816278080_1.jpg	image/jpg	1741	2010-01-19 11:49:37.95228
169	19	US	USD	Early 1984 Apple Macintosh 512K M0001 W w/ Ext. Drive 	http://cgi.ebay.com/Early-1984-Apple-Macintosh-512K-M0001-W-w-Ext-Drive_W0QQitemZ170435205809QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704352058098080_1.jpg	170435205809	average	complete with extras	36.00	2010-01-27 20:55:41	2010-01-20 22:57:46.915538	2010-01-28 10:53:05.986995	1704352058098080_1.jpg	image/jpg	971	2010-01-20 22:57:46.816156
172	19	US	USD	Apple M0001W Macintosh 512K  All-in-one - PARTS - 04400	http://cgi.ebay.com/Apple-M0001W-Macintosh-512K-All-in-one-PARTS-04400_W0QQitemZ200257341880QQcategoryZ178QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2002573418808080_18.jpg	200257341880	poor	bare	\N	2010-02-17 03:07:30	2010-01-20 23:02:02.415561	2010-01-20 23:02:02.415561	2002573418808080_18.jpg	image/jpg	883	2010-01-20 23:02:02.279863
182	7	UK	USD	Commodore C128/64 Personal Computer Keyboard w/FastLoad	http://cgi.ebay.com/Commodore-C128-64-Personal-Computer-Keyboard-w-FastLoad_W0QQitemZ200430332009QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004303320098080_1.jpg	200430332009	good	complete with extras	\N	2010-02-19 03:12:56	2010-01-20 23:11:24.498167	2010-01-20 23:11:24.498167	2004303320098080_1.jpg	image/jpg	903	2010-01-20 23:11:24.404199
185	3	UK	USD	COMMODORE 64 COMPUTER 1541 DISK DRIVE	http://cgi.ebay.com/COMMODORE-64-COMPUTER-1541-DISK-DRIVE_W0QQitemZ120520772026QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1205207720268080_1.jpg	120520772026	average	complete with extras	\N	2010-02-19 22:56:17	2010-01-20 23:12:18.901932	2010-01-20 23:12:18.901932	1205207720268080_1.jpg	image/jpg	1187	2010-01-20 23:12:18.801041
175	3	UK	USD	Vintage Commodore 64 & 1541 Floppy Drive, Works Great!	http://cgi.ebay.com/Vintage-Commodore-64-1541-Floppy-Drive-Works-Great_W0QQitemZ350305383486QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3503053834868080_1.jpg	350305383486	average	complete with extras	89.00	2010-01-22 02:42:29	2010-01-20 23:08:01.075367	2010-01-22 09:07:51.160955	3503053834868080_1.jpg	image/jpg	1483	2010-01-20 23:08:00.93128
176	3	UK	USD	Commodore 64 	http://cgi.ebay.com/Commodore-64_W0QQitemZ160395708406QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1603957084068080_1.jpg	160395708406	poor	complete with extras	26.00	2010-01-22 02:55:32	2010-01-20 23:08:40.393606	2010-01-22 09:07:52.764438	1603957084068080_1.jpg	image/jpg	1012	2010-01-20 23:08:40.293762
177	3	UK	USD	Commodore 64 	http://cgi.ebay.com/Commodore-64_W0QQitemZ160395709185QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1603957091858080_1.jpg	160395709185	poor	complete with extras	20.50	2010-01-22 02:59:09	2010-01-20 23:08:55.004418	2010-01-22 09:07:55.147097	1603957091858080_1.jpg	image/jpg	969	2010-01-20 23:08:54.912932
178	3	UK	USD	Commodore 64 with 1541 Floppy Drive	http://cgi.ebay.com/Commodore-64-with-1541-Floppy-Drive_W0QQitemZ260538832799QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2605388327998080_1.jpg	260538832799	average	complete with extras	45.00	2010-01-23 19:28:17	2010-01-20 23:09:55.818054	2010-01-23 20:16:56.433114	2605388327998080_1.jpg	image/jpg	1174	2010-01-20 23:09:55.720727
179	3	UK	USD	COMMODORE 64 AND EXTRAS	http://cgi.ebay.com/COMMODORE-64-AND-EXTRAS_W0QQitemZ130359542568QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1303595425688080_1.jpg	130359542568	good	boxed with extras	50.00	2010-01-23 22:21:51	2010-01-20 23:10:24.671637	2010-01-23 22:34:13.593761	1303595425688080_1.jpg	image/jpg	1298	2010-01-20 23:10:24.578689
170	19	US	USD	Vintage Macintosh 512K Computer 1984	http://cgi.ebay.com/Vintage-Macintosh-512K-Computer-1984_W0QQitemZ290392254085QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2903922540858080_1.jpg	290392254085	poor	complete	81.00	2010-01-23 22:18:34	2010-01-20 22:59:54.76914	2010-01-23 22:34:15.724969	2903922540858080_1.jpg	image/jpg	1343	2010-01-20 22:59:54.670822
180	3	UK	USD	Commodore 64 w/ Box & Accessorys C64 C=64 System WORKS!	http://cgi.ebay.com/Commodore-64-w-Box-Accessorys-C64-C-64-System-WORKS_W0QQitemZ230425288780QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304252887808080_1.jpg	230425288780	good	boxed with extras	50.00	2010-01-24 04:56:16	2010-01-20 23:10:35.69558	2010-01-24 18:41:25.224921	2304252887808080_1.jpg	image/jpg	1174	2010-01-20 23:10:35.557702
171	19	US	USD	1984 Macintosh M0001 W 512K Mac System- Serviced NICE!	http://cgi.ebay.com/1984-Macintosh-M0001-W-512K-Mac-System-Serviced-NICE_W0QQitemZ350306065830QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3503060658308080_1.jpg	350306065830	average	complete	355.00	2010-01-24 01:09:09	2010-01-20 23:00:49.808681	2010-01-24 18:41:33.321895	3503060658308080_1.jpg	image/jpg	1107	2010-01-20 23:00:49.729013
191	7	UK	USD	Commodore 128 complete working computer set up with box	http://cgi.ebay.com/Commodore-128-complete-working-computer-set-up-with-box_W0QQitemZ120517704608QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1205177046088080_1.jpg	120517704608	good	boxed with extras	100.00	2010-01-24 00:23:47	2010-01-20 23:18:52.959812	2010-01-24 18:41:46.025846	1205177046088080_1.jpg	image/jpg	1146	2010-01-20 23:18:52.840261
181	3	UK	USD	Commodore 64 Computer w/ Box and Power Supply!!!	http://cgi.ebay.com/Commodore-64-Computer-w-Box-and-Power-Supply_W0QQitemZ180457895626QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1804578956268080_1.jpg	180457895626	good	boxed	20.49	2010-01-24 20:36:38	2010-01-20 23:10:54.090647	2010-01-24 21:07:24.526597	1804578956268080_1.jpg	image/jpg	1588	2010-01-20 23:10:54.003556
183	3	UK	USD	commodore 64/1541 computer system w/all cables.Boxed+++	http://cgi.ebay.com/commodore-64-1541-computer-system-w-all-cables-Boxed_W0QQitemZ300388130147QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003881301478080_1.jpg	300388130147	good	boxed with extras	178.49	2010-01-25 02:53:26	2010-01-20 23:11:40.799898	2010-01-25 22:54:27.225334	3003881301478080_1.jpg	image/jpg	1105	2010-01-20 23:11:40.693942
186	3	UK	USD	Commodore 64 /1541 Disc / Power Unit Joy Stick & Cords	http://cgi.ebay.com/Commodore-64-1541-Disc-Power-Unit-Joy-Stick-Cords_W0QQitemZ170434839507QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1704348395078080_1.jpg	170434839507	average	complete with extras	70.00	2010-01-24 23:41:57	2010-01-20 23:12:30.043599	2010-01-25 22:56:18.264875	1704348395078080_1.jpg	image/jpg	1087	2010-01-20 23:12:29.952224
184	3	UK	USD	Commodore 64 computer w/ floppy, tape drive,printer +	http://cgi.ebay.com/Commodore-64-computer-w-floppy-tape-drive-printer_W0QQitemZ130360446355QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1303604463558080_1.jpg	130360446355	average	complete with extras	41.00	2010-01-25 01:40:33	2010-01-20 23:12:11.402138	2010-01-25 23:05:29.294586	1303604463558080_1.jpg	image/jpg	1060	2010-01-20 23:12:11.308305
189	7	CA	CAD	vintage COMMODORE 128 Computer with Power Supply  	http://cgi.ebay.ca/vintage-COMMODORE-128-Computer-with-Power-Supply_W0QQitemZ170434703369QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704347033698080_1.jpg	170434703369	average	complete	48.89	2010-01-27 02:00:33	2010-01-20 23:16:00.373053	2010-01-27 11:51:13.369215	1704347033698080_1.jpg	image/jpg	1339	2010-01-20 23:16:00.270511
187	6	AU	AUD	VINTAGE COMMODORE 16 COMPUTER CIRCA 1984	http://cgi.ebay.com.au/VINTAGE-COMMODORE-16-COMPUTER-CIRCA-1984_W0QQitemZ390144839957QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3901448399578080_1.jpg	390144839957	good	boxed	61.00	2010-01-28 06:43:12	2010-01-20 23:13:08.86081	2010-01-28 10:52:13.531426	3901448399578080_1.jpg	image/jpg	1265	2010-01-20 23:13:08.760385
192	4	UK	USD	Commodore VIC-20 Personal Computer w/ plug & manual	http://cgi.ebay.com/Commodore-VIC-20-Personal-Computer-w-plug-manual_W0QQitemZ390095159096QQcategoryZ4193QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3900951590968080_5.jpg	390095159096	average	complete	\N	2010-02-14 11:27:18	2010-01-20 23:20:23.304716	2010-01-20 23:20:23.304716	3900951590968080_5.jpg	image/jpg	875	2010-01-20 23:20:23.204501
203	20	US	USD	Commodore 1541 Floppy Drive W/cord  in good condition	http://cgi.ebay.com/Commodore-1541-Floppy-Drive-W-cord-in-good-condition_W0QQitemZ180456563035QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1804565630358080_1.jpg	180456563035	good	bare	10.27	2010-01-21 18:45:18	2010-01-21 04:29:23.834818	2010-01-21 23:49:01.716689	1804565630358080_1.jpg	image/jpg	1104	2010-01-21 04:29:23.723156
205	20	US	USD	USED COMMODORE 1541 EXTERNAL DISK DRIVE	http://cgi.ebay.com/USED-COMMODORE-1541-EXTERNAL-DISK-DRIVE_W0QQitemZ370320985348QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3703209853488080_1.jpg	370320985348	average	bare	0.99	2010-01-22 17:00:01	2010-01-21 04:29:56.333416	2010-01-23 00:57:01.200647	3703209853488080_1.jpg	image/jpg	895	2010-01-21 04:29:56.213711
202	5	DE	EUR	APPLE IIe für Sammler - sehr schöner Zustand! Vintage	http://cgi.ebay.de/APPLE-IIe-fuer-Sammler-sehr-schoener-Zustand-Vintage_W0QQitemZ300388194486QQcategoryZ171QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3003881944868080_1.jpg	300388194486	good	bare	113.00	2010-01-23 10:05:00	2010-01-21 03:49:25.719059	2010-01-23 20:17:44.94159	3003881944868080_1.jpg	image/jpg	878	2010-01-21 03:49:25.61436
199	1	DE	EUR	Commodore Amiga 1000 div.Zubehör - Monitor- Tastatur	http://cgi.ebay.de/Commodore-Amiga-1000-div-Zubehoer-Monitor-Tastatur_W0QQitemZ320476213812QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204762138128080_1.jpg	320476213812	good	complete with extras	86.55	2010-01-24 18:33:48	2010-01-21 03:47:01.634154	2010-01-24 18:37:38.058983	3204762138128080_1.jpg	image/jpg	1430	2010-01-21 03:47:01.524622
206	21	US	USD	Commodore 1541-II Disk Drive in Original Box (G)	http://cgi.ebay.com/Commodore-1541-II-Disk-Drive-in-Original-Box-G_W0QQitemZ350306055425QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3503060554258080_1.jpg	350306055425	good	boxed	19.97	2010-01-24 00:29:50	2010-01-21 04:30:07.034251	2010-01-24 18:41:43.962044	3503060554258080_1.jpg	image/jpg	913	2010-01-21 04:30:06.916146
200	1	DE	EUR	Commodore Amiga 1000	http://cgi.ebay.de/Commodore-Amiga-1000_W0QQitemZ130359656374QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1303596563748080_1.jpg	130359656374	good	complete with extras	121.00	2010-01-24 19:10:06	2010-01-21 03:47:11.786558	2010-01-24 21:07:45.432194	1303596563748080_1.jpg	image/jpg	1281	2010-01-21 03:47:11.692062
197	4	UK	USD	COMMODORE VIC 20 VINTAGE COMPUTER WITH 2 GAMES	http://cgi.ebay.com/COMMODORE-VIC-20-VINTAGE-COMPUTER-WITH-2-GAMES_W0QQitemZ130360118976QQcategoryZ162075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1303601189768080_1.jpg	130360118976	good	boxed	29.00	2010-01-25 18:48:53	2010-01-20 23:23:08.313571	2010-01-25 22:53:23.461906	1303601189768080_1.jpg	image/jpg	1680	2010-01-20 23:23:08.196205
209	20	US	USD	Commodore 1541 Single Drive Floppy Disk	http://cgi.ebay.com/Commodore-1541-Single-Drive-Floppy-Disk_W0QQitemZ390145014076QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3901450140768080_1.jpg	390145014076	good	bare	15.99	2010-01-25 17:49:40	2010-01-21 04:30:46.430148	2010-01-25 22:53:39.636241	3901450140768080_1.jpg	image/jpg	773	2010-01-21 04:30:46.300177
212	20	US	USD	Commodore 1541 Floppy Disk Drive	http://cgi.ebay.com/Commodore-1541-Floppy-Disk-Drive_W0QQitemZ250566421862QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2505664218628080_1.jpg	250566421862	good	complete	8.50	2010-01-26 20:26:24	2010-01-21 04:31:15.015171	2010-01-27 11:52:35.056282	2505664218628080_1.jpg	image/jpg	1076	2010-01-21 04:31:14.888827
210	21	US	USD	Commodore VIC-1541 Disk Drive for Commodore 64/128	http://cgi.ebay.com/Commodore-VIC-1541-Disk-Drive-for-Commodore-64-128_W0QQitemZ300389062932QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3003890629328080_1.jpg	300389062932	good	complete	27.75	2010-01-25 23:29:43	2010-01-21 04:30:55.913066	2010-01-27 11:52:47.625414	3003890629328080_1.jpg	image/jpg	1294	2010-01-21 04:30:55.795793
213	20	US	USD	Commmodore 1541 Disk Drive	http://cgi.ebay.com/Commmodore-1541-Disk-Drive_W0QQitemZ220544013733QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2205440137338080_1.jpg	220544013733	good	bare	9.99	2010-01-28 03:29:53	2010-01-21 04:31:36.487133	2010-01-28 10:52:18.762533	2205440137338080_1.jpg	image/jpg	1113	2010-01-21 04:31:36.365704
201	8	DE	EUR	Sinclair ZX Spectrum 48k	http://cgi.ebay.de/Sinclair-ZX-Spectrum-48k_W0QQitemZ180459077893QQcategoryZ8099QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1804590778938080_1.jpg	180459077893	average	bare	16.72	2010-01-27 16:01:28	2010-01-21 03:48:03.744566	2010-01-28 10:55:52.811781	1804590778938080_1.jpg	image/jpg	1312	2010-01-21 03:48:03.639635
217	21	IT	EUR	Commodore Drive Floppy 1541 II	http://cgi.ebay.it/Commodore-Drive-Floppy-1541-II_W0QQitemZ280454464194QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2804544641948080_1.jpg	280454464194	average	bare	15.50	2010-01-31 00:19:44	2010-01-21 04:32:29.555946	2010-01-31 02:10:12.386365	2804544641948080_1.jpg	image/jpg	768	2010-01-21 04:32:29.428177
218	21	DE	EUR	commodore 1541-II Disk Drive mit JiffyDOS für C64 *TOP*	http://cgi.ebay.de/commodore-1541-II-Disk-Drive-mit-JiffyDOS-fuer-C64-TOP_W0QQitemZ330394330448QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3303943304488080_1.jpg	330394330448	good	complete	34.99	2010-01-21 05:32:27	2010-01-21 04:32:54.368968	2010-01-21 11:32:48.771784	3303943304488080_1.jpg	image/jpg	750	2010-01-21 04:32:54.235903
223	20	DE	EUR	Commodore Diskettenlaufwerk 1541 mit integr. Netzteil	http://cgi.ebay.de/Commodore-Diskettenlaufwerk-1541-mit-integr-Netzteil_W0QQitemZ140375343697QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1403753436978080_1.jpg	140375343697	poor	bare	2.70	2010-01-22 19:17:09	2010-01-21 04:34:08.663633	2010-01-23 00:56:25.038168	1403753436978080_1.jpg	image/jpg	919	2010-01-21 04:34:08.547955
221	20	DE	EUR	Commodore 1541 Diskettenlaufwerk Floppy Disk Drive	http://cgi.ebay.de/Commodore-1541-Diskettenlaufwerk-Floppy-Disk-Drive_W0QQitemZ320475246630QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204752466308080_1.jpg	320475246630	good	bare	13.19	2010-01-22 17:32:49	2010-01-21 04:33:46.002605	2010-01-23 00:57:06.213872	3204752466308080_1.jpg	image/jpg	1141	2010-01-21 04:33:45.8706
227	20	DE	EUR	Commodore 1541 für C64 mit extras reset schalter LED	http://cgi.ebay.de/Commodore-1541-fuer-C64-mit-extras-reset-schalter-LED_W0QQitemZ160394803019QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1603948030198080_1.jpg	160394803019	good	bare	7.16	2010-01-23 19:28:18	2010-01-21 04:34:44.555873	2010-01-23 20:16:54.431985	1603948030198080_1.jpg	image/jpg	1030	2010-01-21 04:34:44.411184
226	20	DE	EUR	Commodore 1541 für C64 mit extras reset turbo schutz 	http://cgi.ebay.de/Commodore-1541-fuer-C64-mit-extras-reset-turbo-schutz_W0QQitemZ160394802043QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1603948020438080_1.jpg	160394802043	good	bare	3.50	2010-01-23 19:24:48	2010-01-21 04:34:34.569018	2010-01-23 20:16:59.452731	1603948020438080_1.jpg	image/jpg	1048	2010-01-21 04:34:34.449433
225	20	DE	EUR	Commodore 1541 für C64 	http://cgi.ebay.de/Commodore-1541-fuer-C64_W0QQitemZ160394800274QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1603948002748080_1.jpg	160394800274	good	bare	2.50	2010-01-23 19:18:45	2010-01-21 04:34:20.327712	2010-01-23 20:17:09.551947	1603948002748080_1.jpg	image/jpg	1012	2010-01-21 04:34:20.174364
224	21	DE	EUR	Commodore 1541-II in original Verpackung	http://cgi.ebay.de/Commodore-1541-II-in-original-Verpackung_W0QQitemZ270516221043QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2705162210438080_1.jpg	270516221043	good	boxed	10.70	2010-01-23 14:06:20	2010-01-21 04:34:17.382444	2010-01-23 20:17:22.869852	2705162210438080_1.jpg	image/jpg	1069	2010-01-21 04:34:17.262421
214	20	IT	EUR	DRIVE COMMODORE 1541 + CAVI + DISCO TEST ORIGINALE '80	http://cgi.ebay.it/DRIVE-COMMODORE-1541-CAVI-DISCO-TEST-ORIGINALE-80_W0QQitemZ150406288211QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1504062882118080_1.jpg	150406288211	good	complete	24.99	2010-01-24 20:18:11	2010-01-21 04:31:55.796896	2010-01-24 21:07:47.377367	1504062882118080_1.jpg	image/jpg	895	2010-01-21 04:31:55.655237
231	20	DE	EUR	Commodore 1541 Floppy 5,25" Diskettenlaufwerk	http://cgi.ebay.de/Commodore-1541-Floppy-5-25-Diskettenlaufwerk_W0QQitemZ300386648056QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3003866480568080_1.jpg	300386648056	good	bare	7.19	2010-01-24 18:45:09	2010-01-21 04:35:21.885218	2010-01-24 21:07:55.332446	3003866480568080_1.jpg	image/jpg	1343	2010-01-21 04:35:21.757159
233	20	DE	EUR	Commodore 1541  FLOPPY : Getestet	http://cgi.ebay.de/Commodore-1541-FLOPPY-Getestet_W0QQitemZ170435164858QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704351648588080_1.jpg	170435164858	good	boxed	5.51	2010-01-25 19:25:08	2010-01-21 04:35:40.741958	2010-01-25 22:51:41.401497	1704351648588080_1.jpg	image/jpg	1092	2010-01-21 04:35:40.58876
232	20	DE	EUR	Commodore Single Drive Floppy Disk Mod.1541 C 64	http://cgi.ebay.de/Commodore-Single-Drive-Floppy-Disk-Mod-1541-C-64_W0QQitemZ250566895427QQcategoryZ3543QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2505668954278080_1.jpg	250566895427	good	bare	12.52	2010-01-25 18:54:40	2010-01-21 04:35:31.671303	2010-01-25 22:53:18.343489	2505668954278080_1.jpg	image/jpg	1071	2010-01-21 04:35:31.551964
235	20	DE	EUR	Commodore Floppy 1541 ge testet! + 100 Disks + Manual !	http://cgi.ebay.de/Commodore-Floppy-1541-ge-testet-100-Disks-Manual_W0QQitemZ300388002277QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3003880022778080_1.jpg	300388002277	good	complete with extras	35.50	2010-01-27 20:28:21	2010-01-21 04:36:04.543718	2010-01-28 10:54:37.533495	3003880022778080_1.jpg	image/jpg	915	2010-01-21 04:36:04.425384
236	21	DE	EUR	**  FLOPPY 1541-2  **  FÜR COMMODORE 64 & C128	http://cgi.ebay.de/FLOPPY-1541-2-FUR-COMMODORE-64-C128_W0QQitemZ290393121813QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2903931218138080_1.jpg	290393121813	good	complete	\N	2010-02-17 22:12:28	2010-01-21 04:36:13.130727	2010-01-21 04:36:13.130727	2903931218138080_1.jpg	image/jpg	1010	2010-01-21 04:36:12.997013
238	22	US	USD	1581 Disk Drive w/JiffyDOS - Commodore 64 128 128D SX64	http://cgi.ebay.com/1581-Disk-Drive-w-JiffyDOS-Commodore-64-128-128D-SX64_W0QQitemZ400098226502QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/4000982265028080_1.jpg	400098226502	good	complete	\N	2010-02-17 18:34:54	2010-01-21 04:39:59.819994	2010-01-21 04:39:59.819994	4000982265028080_1.jpg	image/jpg	1037	2010-01-21 04:39:59.697644
237	21	DE	EUR	Commodore Floppy Disk 1541 II OVP	http://cgi.ebay.de/Commodore-Floppy-Disk-1541-II-OVP_W0QQitemZ200430166406QQcategoryZ3543QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2004301664068080_1.jpg	200430166406	average	boxed	1.50	2010-01-29 18:40:20	2010-01-21 04:36:36.343895	2010-01-31 02:11:12.634743	2004301664068080_1.jpg	image/jpg	906	2010-01-21 04:36:36.22061
247	23	DE	EUR	Amiga 500 großes Kompl. Paket	http://cgi.ebay.de/Amiga-500-grosses-Kompl-Paket_W0QQitemZ180457949221QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1804579492218080_1.jpg	180457949221	good	complete with extras	30.60	2010-01-22 21:56:29	2010-01-21 04:42:36.691491	2010-01-23 00:56:22.801059	1804579492218080_1.jpg	image/jpg	1192	2010-01-21 04:42:36.565941
246	23	DE	EUR	2x Amiga 500 1x mit 1MB Ram mit Abeckung und Handbücher	http://cgi.ebay.de/2x-Amiga-500-1x-mit-1MB-Ram-mit-Abeckung-und-Handbuecher_W0QQitemZ110481872795QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104818727958080_1.jpg	110481872795	good	complete	9.71	2010-01-22 19:56:46	2010-01-21 04:42:25.644231	2010-01-23 00:56:27.972427	1104818727958080_1.jpg	image/jpg	974	2010-01-21 04:42:25.535777
244	23	DE	EUR	AMIGA 500	http://cgi.ebay.de/AMIGA-500_W0QQitemZ150405713750QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1504057137508080_1.jpg	150405713750	average	bare	3.00	2010-01-22 19:15:29	2010-01-21 04:42:01.85015	2010-01-23 00:56:36.39264	1504057137508080_1.jpg	image/jpg	936	2010-01-21 04:42:01.709601
242	23	DE	EUR	Commodore Amiga 500 Paket incl Disk, Floppy, Joystick..	http://cgi.ebay.de/Commodore-Amiga-500-Paket-incl-Disk-Floppy-Joystick_W0QQitemZ320476056456QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204760564568080_1.jpg	320476056456	good	complete with extras	28.16	2010-01-22 14:48:31	2010-01-21 04:41:37.990094	2010-01-23 00:56:38.655892	3204760564568080_1.jpg	image/jpg	1120	2010-01-21 04:41:37.872376
243	23	DE	EUR	Lot COMMODORE AMIGA A 500 3 St.	http://cgi.ebay.de/Lot-COMMODORE-AMIGA-A-500-3-St_W0QQitemZ280452781476QQcategoryZ8154QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2804527814768080_1.jpg	280452781476	good	bare	15.99	2010-01-22 16:24:44	2010-01-21 04:41:51.302419	2010-01-23 00:56:43.307447	2804527814768080_1.jpg	image/jpg	936	2010-01-21 04:41:51.187472
245	23	DE	EUR	AMIGA 500 mit Speichererweiterung	http://cgi.ebay.de/AMIGA-500-mit-Speichererweiterung_W0QQitemZ160395287175QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1603952871758080_1.jpg	160395287175	average	complete with extras	40.50	2010-01-22 17:15:39	2010-01-21 04:42:13.950168	2010-01-23 00:57:03.796014	1603952871758080_1.jpg	image/jpg	958	2010-01-21 04:42:13.845636
251	23	DE	EUR	Amiga 500	http://cgi.ebay.de/Amiga-500_W0QQitemZ290393056495QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2903930564958080_1.jpg	290393056495	good	boxed	10.82	2010-01-23 19:21:42	2010-01-21 04:43:17.400466	2010-01-23 20:17:07.627017	2903930564958080_1.jpg	image/jpg	992	2010-01-21 04:43:17.25346
250	23	DE	EUR	Amiga 500 2000 C64 	http://cgi.ebay.de/Amiga-500-2000-C64_W0QQitemZ170433211588QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704332115888080_1.jpg	170433211588	average	complete	15.50	2010-01-23 18:12:48	2010-01-21 04:43:07.547931	2010-01-23 20:17:15.834079	1704332115888080_1.jpg	image/jpg	1046	2010-01-21 04:43:07.430671
249	23	DE	EUR	Amiga 500 plus inklusive Zubehör Spiele Joystick	http://cgi.ebay.de/Amiga-500-plus-inklusive-Zubehoer-Spiele-Joystick_W0QQitemZ170433130553QQcategoryZ151997QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704331305538080_1.jpg	170433130553	good	complete with extras	45.50	2010-01-23 16:43:06	2010-01-21 04:42:56.475875	2010-01-23 20:17:18.25516	1704331305538080_1.jpg	image/jpg	1390	2010-01-21 04:42:56.357234
255	23	DE	EUR	Commodore Amiga 500	http://cgi.ebay.de/Commodore-Amiga-500_W0QQitemZ110482697834QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1104826978348080_1.jpg	110482697834	good	bare	2.00	2010-01-24 18:18:50	2010-01-21 04:44:08.667884	2010-01-24 18:39:48.566618	1104826978348080_1.jpg	image/jpg	1168	2010-01-21 04:44:08.522911
256	23	DE	EUR	AMIGA 500 + Monitor 1084S + Spiele + Joystick + Kabel	http://cgi.ebay.de/AMIGA-500-Monitor-1084S-Spiele-Joystick-Kabel_W0QQitemZ330396246425QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3303962464258080_1.jpg	330396246425	good	complete with extras	56.05	2010-01-24 18:00:43	2010-01-21 04:44:18.231966	2010-01-24 18:39:52.627762	3303962464258080_1.jpg	image/jpg	1142	2010-01-21 04:44:18.086121
254	23	DE	EUR	Amiga 500+	http://cgi.ebay.de/Amiga-500_W0QQitemZ320476185683QQcategoryZ8153QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3204761856838080_1.jpg	320476185683	average	bare	5.50	2010-01-24 17:59:41	2010-01-21 04:43:59.345864	2010-01-24 18:39:56.061293	3204761856838080_1.jpg	image/jpg	974	2010-01-21 04:43:59.224845
253	23	DE	EUR	Amiga 500 Kickstart 1.3 1MB +Netzteil Top 100% ok 	http://cgi.ebay.de/Amiga-500-Kickstart-1-3-1MB-Netzteil-Top-100-ok_W0QQitemZ150406272843QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1504062728438080_1.jpg	150406272843	good	complete	23.50	2010-01-24 17:47:11	2010-01-21 04:43:49.695022	2010-01-24 18:40:05.898514	1504062728438080_1.jpg	image/jpg	936	2010-01-21 04:43:49.565844
252	23	DE	EUR	Amiga 500 mit Zubehör (Maus, Netzteil, Handbücher)	http://cgi.ebay.de/Amiga-500-mit-Zubehoer-Maus-Netzteil-Handbuecher_W0QQitemZ290392479436QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2903924794368080_1.jpg	290392479436	good	complete	15.13	2010-01-24 14:44:18	2010-01-21 04:43:37.063878	2010-01-24 18:40:22.435683	2903924794368080_1.jpg	image/jpg	1174	2010-01-21 04:43:36.941024
257	23	DE	EUR	AMIGA 500 mit Zubehör, Competition pro schwarz-rot-1 MB	http://cgi.ebay.de/AMIGA-500-mit-Zubehoer-Competition-pro-schwarz-rot-1-MB_W0QQitemZ400098032131QQcategoryZ8154QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/4000980321318080_1.jpg	400098032131	average	complete with extras	19.50	2010-01-24 18:52:53	2010-01-21 04:44:53.53444	2010-01-24 21:08:00.961035	4000980321318080_1.jpg	image/jpg	1065	2010-01-21 04:44:53.413304
239	22	US	USD	Commodore 1581 Disk Drive TESTED/Working good condition	http://cgi.ebay.com/Commodore-1581-Disk-Drive-TESTED-Working-good-condition_W0QQitemZ190366738832QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903667388328080_1.jpg	190366738832	good	bare	90.00	2010-01-25 01:25:38	2010-01-21 04:40:08.629345	2010-01-25 23:05:33.964722	1903667388328080_1.jpg	image/jpg	1007	2010-01-21 04:40:08.509673
272	23	US	USD	Commodore Amiga 500 & Commodore 1082 Monitor!! NICE!	http://cgi.ebay.com/Commodore-Amiga-500-Commodore-1082-Monitor-NICE_W0QQitemZ280450563771QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2804505637718080_1.jpg	280450563771	good	complete with extras	\N	2010-02-11 19:21:42	2010-01-21 04:49:43.48605	2010-01-21 04:49:43.48605	2804505637718080_1.jpg	image/jpg	788	2010-01-21 04:49:43.359422
241	23	AU	AUD	* Amiga 500 - one for collectors + fans - BOXED + VGC *	http://cgi.ebay.com.au/Amiga-500-one-for-collectors-fans-BOXED-VGC_W0QQitemZ110479512995QQcategoryZ4598QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104795129958080_1.jpg	110479512995	good	boxed	202.50	2010-01-21 10:22:00	2010-01-21 04:41:07.400054	2010-01-21 11:32:47.633269	1104795129958080_1.jpg	image/jpg	1167	2010-01-21 04:41:07.275187
269	23	US	USD	Amiga 500 in original box Powers on	http://cgi.ebay.com/Amiga-500-in-original-box-Powers-on_W0QQitemZ250563695564QQcategoryZ4598QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2505636955648080_1.jpg	250563695564	good	boxed	40.00	2010-01-21 22:13:31	2010-01-21 04:49:11.373039	2010-01-21 23:48:40.309135	2505636955648080_1.jpg	image/jpg	1037	2010-01-21 04:49:11.258395
276	31	US	USD	Apple Vintage Duodisk External Dual Floppy Disk Drive	http://cgi.ebay.com/Apple-Vintage-Duodisk-External-Dual-Floppy-Disk-Drive_W0QQitemZ110481665697QQcategoryZ168057QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1104816656978080_1.jpg	110481665697	good	bare	23.60	2010-01-22 04:42:22	2010-01-21 16:16:06.628637	2010-01-22 09:08:24.671483	1104816656978080_1.jpg	image/jpg	768	2010-01-21 16:16:06.507762
273	26	DE	EUR	Commodore 1570 Diskettenlaufwerk Disk Drive (ähnl 1571)	http://cgi.ebay.de/Commodore-1570-Diskettenlaufwerk-Disk-Drive-aehnl-1571_W0QQitemZ320475249056QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204752490568080_1.jpg	320475249056	good	bare	39.50	2010-01-22 17:39:34	2010-01-21 16:12:16.878109	2010-01-23 00:57:10.149426	3204752490568080_1.jpg	image/jpg	1117	2010-01-21 16:12:16.760654
266	23	IT	EUR	COMMODORE AMIGA model 500 funzionante	http://cgi.ebay.it/COMMODORE-AMIGA-model-500-funzionante_W0QQitemZ280451013553QQcategoryZ4598QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804510135538080_1.jpg	280451013553	good	complete	51.00	2010-01-23 19:35:11	2010-01-21 04:47:55.965005	2010-01-23 20:16:40.641455	2804510135538080_1.jpg	image/jpg	1121	2010-01-21 04:47:55.852188
270	23	US	USD	Vintage Commodore Amiga 500 Computer A500 New in Box	http://cgi.ebay.com/Vintage-Commodore-Amiga-500-Computer-A500-New-in-Box_W0QQitemZ140375009972QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1403750099728080_1.jpg	140375009972	good	boxed	177.50	2010-01-23 22:31:20	2010-01-21 04:49:19.72493	2010-01-23 22:34:18.78832	1403750099728080_1.jpg	image/jpg	1457	2010-01-21 04:49:19.60833
263	23	ES	EUR	Commodore Amiga 500 + 512 RAM	http://cgi.ebay.es/Commodore-Amiga-500-512-RAM_W0QQitemZ220540533162QQcategoryZ89183QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2205405331628080_1.jpg	220540533162	good	complete	34.00	2010-01-24 15:36:25	2010-01-21 04:46:56.206284	2010-01-24 18:40:13.450228	2205405331628080_1.jpg	image/jpg	1165	2010-01-21 04:46:56.082123
274	26	DE	EUR	Commodore 1570 DISK Drive	http://cgi.ebay.de/Commodore-1570-DISK-Drive_W0QQitemZ230424258977QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2304242589778080_1.jpg	230424258977	good	complete	28.51	2010-01-24 18:39:14	2010-01-21 16:12:26.24346	2010-01-24 18:41:07.350793	2304242589778080_1.jpg	image/jpg	1014	2010-01-21 16:12:26.130566
258	23	DE	EUR	AMIGA 500 mit Zubehör  Competition pro schwarz-rot	http://cgi.ebay.de/AMIGA-500-mit-Zubehoer-Competition-pro-schwarz-rot_W0QQitemZ400098030968QQcategoryZ8154QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/4000980309688080_1.jpg	400098030968	average	complete	19.50	2010-01-24 18:47:15	2010-01-21 04:45:09.023814	2010-01-24 21:07:58.641609	4000980309688080_1.jpg	image/jpg	1142	2010-01-21 04:45:08.902127
259	23	DE	EUR	Amiga 500	http://cgi.ebay.de/Amiga-500_W0QQitemZ190366610117QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1903666101178080_1.jpg	190366610117	good	complete with extras	45.03	2010-01-24 19:35:35	2010-01-21 04:45:18.323298	2010-01-24 21:07:59.243999	1903666101178080_1.jpg	image/jpg	1050	2010-01-21 04:45:18.210565
260	23	DE	EUR	Commodore Amiga 500 guter Zustand 	http://cgi.ebay.de/Commodore-Amiga-500-guter-Zustand_W0QQitemZ190366028103QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1903660281038080_1.jpg	190366028103	good	boxed	20.52	2010-01-24 20:01:02	2010-01-21 04:45:29.995703	2010-01-24 21:08:01.23888	1903660281038080_1.jpg	image/jpg	1006	2010-01-21 04:45:29.887947
261	23	DE	EUR	Amiga 500 funktionsfähig, ohne Zubehör	http://cgi.ebay.de/Amiga-500-funktionsfaehig-ohne-Zubehoer_W0QQitemZ230425725444QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304257254448080_1.jpg	230425725444	good	bare	2.01	2010-01-24 20:46:02	2010-01-21 04:45:41.907431	2010-01-24 21:08:01.606571	2304257254448080_1.jpg	image/jpg	784	2010-01-21 04:45:41.783733
262	23	DE	EUR	Commodore Amiga 500 mit viel Zubehör bei HH	http://cgi.ebay.de/Commodore-Amiga-500-mit-viel-Zubehoer-bei-HH_W0QQitemZ220540706239QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2205407062398080_1.jpg	220540706239	good	boxed with extras	56.00	2010-01-24 20:13:48	2010-01-21 04:45:59.973172	2010-01-24 21:08:04.197455	2205407062398080_1.jpg	image/jpg	1049	2010-01-21 04:45:59.857472
264	23	FR	EUR	AMIGA 500 !! Testé et Fonctionnel !! en boite	http://cgi.ebay.fr/AMIGA-500-Teste-et-Fonctionnel-en-boite_W0QQitemZ110481714150QQcategoryZ113187QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1104817141508080_1.jpg	110481714150	good	boxed	29.50	2010-01-25 10:04:27	2010-01-21 04:47:22.882296	2010-01-25 22:53:48.3603	1104817141508080_1.jpg	image/jpg	1154	2010-01-21 04:47:22.499249
271	23	US	USD	Commodore Amiga A500 500 Bundle Lot-Disk Drive-Software	http://cgi.ebay.com/Commodore-Amiga-A500-500-Bundle-Lot-Disk-Drive-Software_W0QQitemZ220542492533QQcategoryZ4598QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2205424925338080_1.jpg	220542492533	good	boxed	66.00	2010-01-25 02:50:22	2010-01-21 04:49:33.840075	2010-01-25 22:54:39.691529	2205424925338080_1.jpg	image/jpg	1343	2010-01-21 04:49:33.707018
275	28	US	USD	2 Vintage Apple Disk II's & Disk II Interface Card	http://cgi.ebay.com/2-Vintage-Apple-Disk-IIs-Disk-II-Interface-Card_W0QQitemZ370322132448QQcategoryZ168057QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3703221324488080_1.jpg	370322132448	good	complete	11.25	2010-01-25 02:04:44	2010-01-21 16:15:13.516014	2010-01-25 22:54:48.67016	3703221324488080_1.jpg	image/jpg	1283	2010-01-21 16:15:13.404835
278	31	US	USD	APPLE II 5.25" FLOPPY DISK DRIVE DUODISK model A9M0108	http://cgi.ebay.com/APPLE-II-5-25-FLOPPY-DISK-DRIVE-DUODISK-model-A9M0108_W0QQitemZ170433931634QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704339316348080_1.jpg	170433931634	average	bare	37.04	2010-01-24 23:19:53	2010-01-21 16:16:44.089243	2010-01-25 22:56:12.602217	1704339316348080_1.jpg	image/jpg	627	2010-01-21 16:16:43.974635
283	25	DE	EUR	Commodore 1541 ** ansehen lohnt sich! ** [232]	http://cgi.ebay.de/Commodore-1541-ansehen-lohnt-sich-232_W0QQitemZ350300521527QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3503005215278080_1.jpg	350300521527	good	bare	\N	2010-02-02 11:10:47	2010-01-21 16:19:48.311148	2010-01-21 16:19:48.311148	3503005215278080_1.jpg	image/jpg	880	2010-01-21 16:19:48.177181
285	24	US	USD	Commodore 128D Personal Computer	http://cgi.ebay.com/Commodore-128D-Personal-Computer_W0QQitemZ380186213817QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3801862138178080_2.jpg	380186213817	average	bare	\N	2010-02-06 18:11:19	2010-01-21 16:28:02.651603	2010-01-21 16:28:02.651603	3801862138178080_2.jpg	image/jpg	815	2010-01-21 16:28:02.54286
287	7	CA	CAD	VINTAGE Commodore 128 Computer System Box	http://cgi.ebay.ca/VINTAGE-Commodore-128-Computer-System-Box_W0QQitemZ230390878583QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2303908785838080_5.jpg	230390878583	average	boxed	\N	2010-02-18 21:07:36	2010-01-21 16:32:06.121812	2010-01-21 16:32:06.121812	2303908785838080_5.jpg	image/jpg	1078	2010-01-21 16:32:05.975061
298	32	DE	EUR	Commodore SX-64 C64 Laptop mit Farbbildschirm SX64	http://cgi.ebay.de/Commodore-SX-64-C64-Laptop-mit-Farbbildschirm-SX64_W0QQitemZ170408676684QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704086766848080_39.jpg	170408676684	good	complete	\N	2010-02-16 13:32:38	2010-01-21 17:45:44.552684	2010-01-21 17:45:44.552684	1704086766848080_39.jpg	image/jpg	1352	2010-01-21 17:45:44.432164
294	32	US	USD	VINTAGE COMMODORE SX-64 PROFESSIONAL COMPUTER 1980'S	http://cgi.ebay.com/VINTAGE-COMMODORE-SX-64-PROFESSIONAL-COMPUTER-1980S_W0QQitemZ190366722095QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1903667220958080_1.jpg	190366722095	good	complete	127.50	2010-01-22 23:57:06	2010-01-21 17:42:08.058634	2010-01-23 00:56:21.767366	1903667220958080_1.jpg	image/jpg	1496	2010-01-21 17:42:07.937941
281	25	DE	EUR	Commodore 1541 C Diskettenlaufwerk Floppy Disk Drive	http://cgi.ebay.de/Commodore-1541-C-Diskettenlaufwerk-Floppy-Disk-Drive_W0QQitemZ320475247974QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204752479748080_1.jpg	320475247974	good	bare	17.19	2010-01-22 17:36:35	2010-01-21 16:19:06.884789	2010-01-23 00:57:08.771804	3204752479748080_1.jpg	image/jpg	1047	2010-01-21 16:19:06.764361
288	24	DE	EUR	Commodore 128 D + Software + Zubehör	http://cgi.ebay.de/Commodore-128-D-Software-Zubehoer_W0QQitemZ150407429714QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1504074297148080_1.jpg	150407429714	good	complete with extras	35.49	2010-01-24 13:37:56	2010-01-21 16:34:09.971578	2010-01-24 18:40:25.595625	1504074297148080_1.jpg	image/jpg	1069	2010-01-21 16:34:09.849502
297	32	DE	EUR	COMMODORE SX-64-Portable + Bücher + Spiele-Disketten 	http://cgi.ebay.de/COMMODORE-SX-64-Portable-Buecher-Spiele-Disketten_W0QQitemZ150406363049QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1504063630498080_1.jpg	150406363049	good	complete with extras	162.00	2010-01-24 20:20:02	2010-01-21 17:45:12.870152	2010-01-24 21:08:16.180281	1504063630498080_1.jpg	image/jpg	1719	2010-01-21 17:45:12.756228
291	24	FR	EUR	Commodore 128 DR Boitier Metal Sans Clavier	http://cgi.ebay.fr/Commodore-128-DR-Boitier-Metal-Sans-Clavier_W0QQitemZ120519860861QQcategoryZ113190QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1205198608618080_1.jpg	120519860861	average	bare	25.50	2010-01-25 19:53:57	2010-01-21 16:35:47.310558	2010-01-25 22:51:28.920027	1205198608618080_1.jpg	image/jpg	828	2010-01-21 16:35:47.198365
286	24	US	USD	Commodore 128d computer and keyboard	http://cgi.ebay.com/Commodore-128d-computer-and-keyboard_W0QQitemZ350307527271QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3503075272718080_1.jpg	350307527271	average	complete	46.00	2010-01-25 16:45:18	2010-01-21 16:28:48.875481	2010-01-25 22:53:43.148474	3503075272718080_1.jpg	image/jpg	882	2010-01-21 16:28:48.763382
295	32	US	USD	Commodore SX-64 Portable Computer	http://cgi.ebay.com/Commodore-SX-64-Portable-Computer_W0QQitemZ280453018123QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2804530181238080_1.jpg	280453018123	average	complete	120.00	2010-01-24 21:33:18	2010-01-21 17:42:42.40982	2010-01-25 22:55:46.873087	2804530181238080_1.jpg	image/jpg	1134	2010-01-21 17:42:42.28804
299	32	DE	EUR	Commodore SX 64	http://cgi.ebay.de/Commodore-SX-64_W0QQitemZ320475908205QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3204759082058080_1.jpg	320475908205	average	complete	200.00	2010-01-27 10:00:55	2010-01-21 17:46:04.03972	2010-01-27 11:50:48.251822	3204759082058080_1.jpg	image/jpg	1061	2010-01-21 17:46:03.904147
279	31	US	USD	APPLE II 5.25" FLOPPY DISK DRIVE DUODISK model A9M0108 	http://cgi.ebay.com/APPLE-II-5-25-FLOPPY-DISK-DRIVE-DUODISK-model-A9M0108_W0QQitemZ280453929360QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2804539293608080_1.jpg	280453929360	good	complete	39.99	2010-01-26 20:04:02	2010-01-21 16:16:55.916142	2010-01-27 11:52:39.782806	2804539293608080_1.jpg	image/jpg	831	2010-01-21 16:16:55.795559
296	32	US	USD	Vintage Commodore SX-64 Executive Computer with Extras	http://cgi.ebay.com/Vintage-Commodore-SX-64-Executive-Computer-with-Extras_W0QQitemZ320477861126QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204778611268080_1.jpg	320477861126	good	complete with extras	142.50	2010-01-28 09:55:53	2010-01-21 17:43:15.928553	2010-01-28 10:52:11.33734	3204778611268080_1.jpg	image/jpg	1087	2010-01-21 17:43:15.798439
289	24	DE	EUR	Commodore 128 D, Metallgehäuse, Tastatur, Handbücher 	http://cgi.ebay.de/Commodore-128-D-Metallgehaeuse-Tastatur-Handbuecher_W0QQitemZ250566905382QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2505669053828080_1.jpg	250566905382	good	complete	26.05	2010-01-27 19:09:37	2010-01-21 16:34:45.60283	2010-01-28 10:54:47.587876	2505669053828080_1.jpg	image/jpg	1025	2010-01-21 16:34:45.487142
290	24	DE	EUR	Commodore PC 128 D	http://cgi.ebay.de/Commodore-PC-128-D_W0QQitemZ260541420972QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2605414209728080_1.jpg	260541420972	poor	complete with extras	24.07	2010-01-28 16:22:19	2010-01-21 16:34:59.330821	2010-01-28 20:59:44.319192	2605414209728080_1.jpg	image/jpg	974	2010-01-21 16:34:59.179207
190	7	UK	USD	USED - Commodore 128 	http://cgi.ebay.com/USED-Commodore-128_W0QQitemZ190365160853QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1903651608538080_1.jpg	190365160853	average	complete	35.00	2010-01-21 17:19:30	2010-01-20 23:18:01.187887	2010-01-21 18:34:28.105881	1903651608538080_1.jpg	image/jpg	1144	2010-01-20 23:18:01.096799
152	7	DE	EUR	Commodore 128 incl. 1571 Geos 2.0 und Zubehör 	http://cgi.ebay.de/Commodore-128-incl-1571-Geos-2-0-und-Zubehoer_W0QQitemZ260539893873QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605398938738080_1.jpg	260539893873	good	complete with extras	37.40	2010-01-21 18:30:20	2010-01-19 14:01:22.473369	2010-01-21 18:34:31.996227	2605398938738080_1.jpg	image/jpg	1035	2010-01-19 14:01:22.343595
302	32	IT	EUR	COMMODORE SX 64 EXECUTIVE COMPLETO E FUNZIONANTE	http://cgi.ebay.it/COMMODORE-SX-64-EXECUTIVE-COMPLETO-E-FUNZIONANTE_W0QQitemZ260541270433QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605412704338080_1.jpg	260541270433	good	complete	191.00	2010-01-31 11:05:56	2010-01-21 17:47:50.932162	2010-01-31 12:46:24.812391	2605412704338080_1.jpg	image/jpg	1016	2010-01-21 17:47:50.654638
268	23	US	USD	Commodore Amiga 500 512k RAM not-working	http://cgi.ebay.com/Commodore-Amiga-500-512k-RAM-not-working_W0QQitemZ280451589834QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2804515898348080_1.jpg	280451589834	average	bare	9.99	2010-01-21 22:25:40	2010-01-21 04:49:01.593603	2010-01-21 23:48:28.327469	2804515898348080_1.jpg	image/jpg	1158	2010-01-21 04:49:01.465396
293	32	US	USD	WORKING Vintage Commodore PORTABLE SX-64 Computer! RARE	http://cgi.ebay.com/WORKING-Vintage-Commodore-PORTABLE-SX-64-Computer-RARE_W0QQitemZ260538037759QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2605380377598080_1.jpg	260538037759	good	complete with extras	122.50	2010-01-21 22:24:42	2010-01-21 17:41:46.615591	2010-01-21 23:48:29.577366	2605380377598080_1.jpg	image/jpg	1545	2010-01-21 17:41:46.495159
193	4	UK	USD	Commadore Vic 20 with Cassette Player	http://cgi.ebay.com/Commadore-Vic-20-with-Cassette-Player_W0QQitemZ280451585349QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804515853498080_1.jpg	280451585349	average	boxed with extras	29.95	2010-01-21 22:13:34	2010-01-20 23:20:56.916047	2010-01-21 23:48:32.053888	2804515853498080_1.jpg	image/jpg	1214	2010-01-20 23:20:56.818432
265	23	IT	EUR	Amiga 500  A500  usato da testare con alimentatore	http://cgi.ebay.it/Amiga-500-A500-usato-da-testare-con-alimentatore_W0QQitemZ260538008192QQcategoryZ4598QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2605380081928080_1.jpg	260538008192	average	complete	10.40	2010-01-21 21:18:26	2010-01-21 04:47:46.57712	2010-01-21 23:48:47.177004	2605380081928080_1.jpg	image/jpg	1158	2010-01-21 04:47:46.301998
305	29	US	USD	Commodore 64c Computer System With Original Boxes, More	http://cgi.ebay.com/Commodore-64c-Computer-System-With-Original-Boxes-More_W0QQitemZ320476213096QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204762130968080_1.jpg	320476213096	good	complete with extras	42.58	2010-01-24 18:32:58	2010-01-21 20:38:26.794325	2010-01-24 18:37:40.124579	3204762130968080_1.jpg	image/jpg	1318	2010-01-21 20:38:26.547633
300	32	IT	EUR	COMMODORE 64 SX executive 	http://cgi.ebay.it/COMMODORE-64-SX-executive_W0QQitemZ330396364230QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3303963642308080_1.jpg	330396364230	average	complete	102.99	2010-01-24 20:28:47	2010-01-21 17:46:46.548369	2010-01-24 21:08:18.351743	3303963642308080_1.jpg	image/jpg	1143	2010-01-21 17:46:46.41397
303	29	DE	EUR	Commodore C-64 c  Homecomputer + Netzteil  C64 C64C II	http://cgi.ebay.de/Commodore-C-64-c-Homecomputer-Netzteil-C64-C64C-II_W0QQitemZ190365186913QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1903651869138080_1.jpg	190365186913	poor	complete	14.83	2010-01-24 18:43:56	2010-01-21 20:36:19.101942	2010-01-24 21:08:24.753677	1903651869138080_1.jpg	image/jpg	963	2010-01-21 20:36:18.819767
310	29	IT	EUR	COMMODORE 64C+REGISTRATORE+TANTI GIOCHI CASSETTE	http://cgi.ebay.it/COMMODORE-64C-REGISTRATORE-TANTI-GIOCHI-CASSETTE_W0QQitemZ250566690880QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2505666908808080_1.jpg	250566690880	poor	complete with extras	14.90	2010-01-25 11:09:16	2010-01-21 20:41:22.428465	2010-01-25 22:53:47.636217	2505666908808080_1.jpg	image/jpg	1057	2010-01-21 20:41:22.302605
313	20	US	USD	Commodore 1541 5.25 floppy disk drive. tested good!!	http://cgi.ebay.com/Commodore-1541-5-25-floppy-disk-drive-tested-good_W0QQitemZ300388130354QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3003881303548080_1.jpg	300388130354	good	complete	38.00	2010-01-25 02:54:31	2010-01-22 23:44:07.844405	2010-01-25 22:54:22.63212	3003881303548080_1.jpg	image/jpg	939	2010-01-22 23:44:07.728487
314	20	US	USD	Commodore 1541 Floppy Drive	http://cgi.ebay.com/Commodore-1541-Floppy-Drive_W0QQitemZ350306501910QQcategoryZ31566QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3503065019108080_1.jpg	350306501910	poor	bare	7.00	2010-01-25 01:45:42	2010-01-22 23:44:29.009081	2010-01-25 22:54:54.005472	3503065019108080_1.jpg	image/jpg	924	2010-01-22 23:44:28.892286
306	29	US	USD	Commodore 64C rev E short board NM w/extras	http://cgi.ebay.com/Commodore-64C-rev-E-short-board-NM-w-extras_W0QQitemZ280453031973QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804530319738080_1.jpg	280453031973	average	boxed	41.00	2010-01-24 21:56:38	2010-01-21 20:38:48.593445	2010-01-25 22:56:00.936322	2804530319738080_1.jpg	image/jpg	1207	2010-01-21 20:38:48.342912
304	29	US	USD	Commodore 64 64C computer in box, tested & working	http://cgi.ebay.com/Commodore-64-64C-computer-in-box-tested-working_W0QQitemZ110482935784QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1104829357848080_1.jpg	110482935784	good	boxed	17.21	2010-01-25 00:31:05	2010-01-21 20:38:03.775506	2010-01-25 23:05:40.788651	1104829357848080_1.jpg	image/jpg	1424	2010-01-21 20:38:03.465668
307	29	US	USD	Commodore 64C computer, complete in box, working 	http://cgi.ebay.com/Commodore-64C-computer-complete-in-box-working_W0QQitemZ290393508586QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2903935085868080_1.jpg	290393508586	good	boxed	34.99	2010-01-27 02:27:13	2010-01-21 20:39:22.559352	2010-01-27 11:51:06.836252	2903935085868080_1.jpg	image/jpg	1108	2010-01-21 20:39:22.287403
301	32	IT	EUR	COMMODORE SX  64	http://cgi.ebay.it/COMMODORE-SX-64_W0QQitemZ110483671875QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104836718758080_1.jpg	110483671875	average	complete	101.00	2010-01-26 16:34:46	2010-01-21 17:47:09.145937	2010-01-27 11:53:12.950857	1104836718758080_1.jpg	image/jpg	1032	2010-01-21 17:47:09.034569
312	34	IT	EUR	APPLE III - APPLE /// - RETROCOMPUTER 1980	http://cgi.ebay.it/APPLE-III-APPLE-RETROCOMPUTER-1980_W0QQitemZ310195217264QQcategoryZ80286QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3101952172648080_1.jpg	310195217264	average	complete	231.00	2010-01-27 20:50:13	2010-01-22 23:32:28.656178	2010-01-28 10:53:08.451414	3101952172648080_1.jpg	image/jpg	1095	2010-01-22 23:32:28.504421
311	34	US	USD	Vintage Apple III 3 Computer System + Disk Drive- WORKS	http://cgi.ebay.com/Vintage-Apple-III-3-Computer-System-Disk-Drive-WORKS_W0QQitemZ270517685562QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705176855628080_1.jpg	270517685562	average	complete with extras	810.00	2010-01-29 03:37:17	2010-01-22 23:29:47.041224	2010-01-29 12:34:01.79594	2705176855628080_1.jpg	image/jpg	1117	2010-01-22 23:29:46.937733
316	20	US	USD	* Commodore 1541 External Disk Drive * Good Condition *	http://cgi.ebay.com/Commodore-1541-External-Disk-Drive-Good-Condition_W0QQitemZ220494807444QQcategoryZ158817QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2204948074448080_4.jpg	220494807444	average	complete	\N	2010-02-11 00:31:43	2010-01-22 23:45:46.297519	2010-01-22 23:45:46.297519	2204948074448080_4.jpg	image/jpg	1103	2010-01-22 23:45:46.190133
322	20	US	USD	Commodore 1541 external disk drive	http://cgi.ebay.com/Commodore-1541-external-disk-drive_W0QQitemZ350277901024QQcategoryZ4193QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3502779010248080_3.jpg	350277901024	average	complete	\N	2010-02-09 18:05:38	2010-01-22 23:52:34.270485	2010-01-22 23:52:34.270485	3502779010248080_3.jpg	image/jpg	795	2010-01-22 23:52:34.121625
323	20	US	USD	VINTAGE COMMODORE 1541 FLOPPY DISK Drive	http://cgi.ebay.com/VINTAGE-COMMODORE-1541-FLOPPY-DISK-Drive_W0QQitemZ320396719124QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3203967191248080_7.jpg	320396719124	poor	bare	\N	2010-02-06 02:11:50	2010-01-22 23:52:51.878085	2010-01-22 23:52:51.878085	3203967191248080_7.jpg	image/jpg	1087	2010-01-22 23:52:51.766714
326	25	IT	EUR	Commodore Floppy Disk 1541 Funzionante	http://cgi.ebay.it/Commodore-Floppy-Disk-1541-Funzionante_W0QQitemZ150407507569QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1504075075698080_1.jpg	150407507569	poor	complete	\N	2010-01-31 18:32:37	2010-01-22 23:54:46.563939	2010-01-22 23:54:46.563939	1504075075698080_1.jpg	image/jpg	922	2010-01-22 23:54:46.385904
337	21	DE	EUR	=== Floppy 1541 II + Netzteil und Serialkabel ===	http://cgi.ebay.de/Floppy-1541-II-Netzteil-und-Serialkabel_W0QQitemZ110484387914QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1104843879148080_1.jpg	110484387914	good	complete	\N	2010-02-20 10:22:47	2010-01-22 23:58:47.576852	2010-01-22 23:58:47.576852	1104843879148080_1.jpg	image/jpg	969	2010-01-22 23:58:47.469665
332	29	DE	EUR	Commodore C64 + Floppy 1541-II + Spiele	http://cgi.ebay.de/Commodore-C64-Floppy-1541-II-Spiele_W0QQitemZ220542178912QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2205421789128080_1.jpg	220542178912	good	complete with extras	16.27	2010-01-24 18:39:56	2010-01-22 23:57:00.418248	2010-01-24 18:41:05.360811	2205421789128080_1.jpg	image/jpg	1068	2010-01-22 23:57:00.297941
331	21	DE	EUR	*** COMMODORE FLOPPY 1541 II IN OVP ***	http://cgi.ebay.de/COMMODORE-FLOPPY-1541-II-IN-OVP_W0QQitemZ320478045080QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204780450808080_1.jpg	320478045080	good	complete	17.50	2010-01-24 18:34:39	2010-01-22 23:56:50.964814	2010-01-24 18:41:09.166113	3204780450808080_1.jpg	image/jpg	1202	2010-01-22 23:56:49.950665
328	29	DE	EUR	Commodore C64 Sammlung 1541 Disk-Drive SAMMLER SET !!!	http://cgi.ebay.de/Commodore-C64-Sammlung-1541-Disk-Drive-SAMMLER-SET_W0QQitemZ330396076131QQcategoryZ1487QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3303960761318080_1.jpg	330396076131	good	complete with extras	45.50	2010-01-24 10:53:34	2010-01-22 23:55:56.05734	2010-01-24 21:08:31.542399	3303960761318080_1.jpg	image/jpg	1367	2010-01-22 23:55:55.959914
333	20	DE	EUR	*** COMMODORE FLOPPY 1541 ALT BRAUN ***	http://cgi.ebay.de/COMMODORE-FLOPPY-1541-ALT-BRAUN_W0QQitemZ320478053291QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3204780532918080_1.jpg	320478053291	good	complete	10.50	2010-01-24 18:48:32	2010-01-22 23:57:21.917659	2010-01-24 21:08:32.470876	3204780532918080_1.jpg	image/jpg	1266	2010-01-22 23:57:21.820651
315	3	US	USD	Commodore 64 computer with VIC-1541 disk drive; mint	http://cgi.ebay.com/Commodore-64-computer-with-VIC-1541-disk-drive-mint_W0QQitemZ280454410641QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804544106418080_1.jpg	280454410641	mint	boxed with extras	91.00	2010-01-25 21:45:39	2010-01-22 23:45:24.067367	2010-01-25 22:50:50.02392	2804544106418080_1.jpg	image/jpg	1390	2010-01-22 23:45:23.194065
334	29	DE	EUR	Commodore C64 II + Commodore 1541 Floppy + Joystick	http://cgi.ebay.de/Commodore-C64-II-Commodore-1541-Floppy-Joystick_W0QQitemZ190365994751QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1903659947518080_1.jpg	190365994751	average	complete with extras	15.50	2010-01-24 19:01:37	2010-01-22 23:57:31.787403	2010-01-25 23:05:58.286403	1903659947518080_1.jpg	image/jpg	731	2010-01-22 23:57:31.668893
335	29	DE	EUR	Commodore C64 Floppy 1541 II 	http://cgi.ebay.de/Commodore-C64-Floppy-1541-II_W0QQitemZ170433758104QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704337581048080_1.jpg	170433758104	good	complete with extras	36.50	2010-01-24 19:04:41	2010-01-22 23:57:47.429648	2010-01-25 23:05:58.806448	1704337581048080_1.jpg	image/jpg	1119	2010-01-22 23:57:47.2718
324	25	IT	EUR	COMMODORE DISK DRIVE  VIC - 1541	http://cgi.ebay.it/COMMODORE-DISK-DRIVE-VIC-1541_W0QQitemZ310195578835QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3101955788358080_1.jpg	310195578835	good	complete	29.90	2010-01-26 16:31:46	2010-01-22 23:53:48.271118	2010-01-27 11:53:10.940538	3101955788358080_1.jpg	image/jpg	1009	2010-01-22 23:53:48.148381
325	20	IT	EUR	Commodore driver 1541	http://cgi.ebay.it/Commodore-driver-1541_W0QQitemZ170435446177QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704354461778080_1.jpg	170435446177	average	bare	15.00	2010-01-28 12:02:17	2010-01-22 23:54:12.85083	2010-01-28 21:01:08.626239	1704354461778080_1.jpg	image/jpg	897	2010-01-22 23:54:12.710168
320	3	US	USD	Commodore 64 Computer with Vic 1541 Disk Drive	http://cgi.ebay.com/Commodore-64-Computer-with-Vic-1541-Disk-Drive_W0QQitemZ110484747559QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104847475598080_1.jpg	110484747559	poor	complete with extras	15.51	2010-01-29 03:22:33	2010-01-22 23:49:35.199479	2010-01-29 12:34:21.603527	1104847475598080_1.jpg	image/jpg	1195	2010-01-22 23:49:35.058899
359	6	DE	EUR	minicomputer commodore 16 	http://cgi.ebay.de/minicomputer-commodore-16_W0QQitemZ150407201243QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1504072012438080_1.jpg	150407201243	average	boxed with extras	17.72	2010-01-30 17:15:37	2010-01-23 00:09:17.320303	2010-01-31 02:10:38.717395	1504072012438080_1.jpg	image/jpg	1187	2010-01-23 00:09:17.176339
343	20	DE	EUR	=== Commodore Floppy 1541 ===	http://cgi.ebay.de/Commodore-Floppy-1541_W0QQitemZ110484380375QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104843803758080_1.jpg	110484380375	average	complete	\N	2010-02-20 09:49:17	2010-01-23 00:00:37.860554	2010-01-23 00:00:37.860554	1104843803758080_1.jpg	image/jpg	960	2010-01-23 00:00:37.768715
344	21	DE	EUR	Commodore 1541-II * kein Gilb - ansehen! ** [215]	http://cgi.ebay.de/Commodore-1541-II-kein-Gilb-ansehen-215_W0QQitemZ350300518454QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3503005184548080_1.jpg	350300518454	good	complete	\N	2010-02-02 10:59:38	2010-01-23 00:00:55.495716	2010-01-23 00:00:55.495716	3503005184548080_1.jpg	image/jpg	994	2010-01-23 00:00:55.37644
345	21	DE	EUR	Commodore 1541-II * TOP - wie neu!! ** [231]	http://cgi.ebay.de/Commodore-1541-II-TOP-wie-neu-231_W0QQitemZ350300521548QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3503005215488080_1.jpg	350300521548	good	complete	\N	2010-02-02 11:10:49	2010-01-23 00:01:11.970425	2010-01-23 00:01:11.970425	3503005215488080_1.jpg	image/jpg	893	2010-01-23 00:01:11.820285
346	25	DE	EUR	Commodore 1541 C-Version *** Top!! *** [J044]	http://cgi.ebay.de/Commodore-1541-C-Version-Top-J044_W0QQitemZ350300518482QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3503005184828080_1.jpg	350300518482	good	complete	\N	2010-02-02 10:59:39	2010-01-23 00:01:30.293237	2010-01-23 00:01:30.293237	3503005184828080_1.jpg	image/jpg	878	2010-01-23 00:01:30.151363
342	29	DE	EUR	Commodore C64 mit 1541-II Floppy Disc Drive	http://cgi.ebay.de/Commodore-C64-mit-1541-II-Floppy-Disc-Drive_W0QQitemZ330398066143QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3303980661438080_1.jpg	330398066143	average	complete with extras	45.50	2010-01-29 20:45:26	2010-01-23 00:00:19.888753	2010-01-31 02:11:00.794964	3303980661438080_1.jpg	image/jpg	1319	2010-01-23 00:00:19.752143
354	6	IT	EUR	commodore 16 computer home vintage retro no 64 128	http://cgi.ebay.it/commodore-16-computer-home-vintage-retro-no-64-128_W0QQitemZ260541420588QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2605414205888080_1.jpg	260541420588	poor	bare	\N	2010-01-31 16:21:25	2010-01-23 00:06:27.524769	2010-01-23 00:06:27.524769	2605414205888080_1.jpg	image/jpg	1147	2010-01-23 00:06:27.396593
358	6	DE	EUR	Commodore 16 in OVP (C16)	http://cgi.ebay.de/Commodore-16-in-OVP-C16_W0QQitemZ260541040459QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2605410404598080_1.jpg	260541040459	average	complete	16.72	2010-01-27 20:32:02	2010-01-23 00:08:43.254436	2010-01-28 10:54:34.409804	2605410404598080_1.jpg	image/jpg	1087	2010-01-23 00:08:42.758158
340	29	DE	EUR	Commodore C64 + Floppy 1541 + OVP´s + 100 Disks + Joyst	http://cgi.ebay.de/Commodore-C64-Floppy-1541-OVP-s-100-Disks-Joyst_W0QQitemZ300387985619QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003879856198080_1.jpg	300387985619	good	boxed with extras	79.99	2010-01-27 20:01:51	2010-01-22 23:59:41.053047	2010-01-28 10:54:45.439093	3003879856198080_1.jpg	image/jpg	961	2010-01-22 23:59:40.947035
339	29	DE	EUR	Commodore C64, Floppy 1541, 2* Joystick Quick Shot II	http://cgi.ebay.de/Commodore-C64-Floppy-1541-2-Joystick-Quick-Shot-II_W0QQitemZ270516708699QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2705167086998080_1.jpg	270516708699	average	complete with extras	26.51	2010-01-27 13:05:25	2010-01-22 23:59:14.005385	2010-01-28 10:55:58.57023	2705167086998080_1.jpg	image/jpg	1236	2010-01-22 23:59:13.896674
353	11	US	USD	Commodore CBM Model 8032 Computer Vintage Classic 	http://cgi.ebay.com/Commodore-CBM-Model-8032-Computer-Vintage-Classic_W0QQitemZ190367261927QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1903672619278080_1.jpg	190367261927	poor	bare	88.00	2010-01-28 21:53:39	2010-01-23 00:04:29.679966	2010-01-29 12:34:22.936875	1903672619278080_1.jpg	image/jpg	1211	2010-01-23 00:04:29.475142
341	3	DE	EUR	Commodore C64 + Floppy 1541 + 2 Joystick + Spiele	http://cgi.ebay.de/Commodore-C64-Floppy-1541-2-Joystick-Spiele_W0QQitemZ170436069334QQcategoryZ3545QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704360693348080_1.jpg	170436069334	good	boxed with extras	52.00	2010-01-29 19:53:47	2010-01-23 00:00:04.477491	2010-01-31 02:11:06.526856	1704360693348080_1.jpg	image/jpg	1254	2010-01-23 00:00:04.340536
356	6	IT	EUR	commodore 16	http://cgi.ebay.it/commodore-16_W0QQitemZ140376558432QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1403765584328080_1.jpg	140376558432	average	boxed	20.00	2010-01-31 22:41:39	2010-01-23 00:07:06.063108	2010-02-01 11:52:21.393171	1403765584328080_1.jpg	image/jpg	1162	2010-01-23 00:07:05.932531
355	6	IT	EUR	Commodore 16 in BOX + datasette. joystick e giochi C16	http://cgi.ebay.it/Commodore-16-in-BOX-datasette-joystick-e-giochi-C16_W0QQitemZ250567553857QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2505675538578080_1.jpg	250567553857	good	boxed with extras	44.99	2010-01-31 20:04:57	2010-01-23 00:06:34.995858	2010-02-01 11:53:54.053987	2505675538578080_1.jpg	image/jpg	960	2010-01-23 00:06:34.852538
351	29	DE	EUR	Commodore C64-II & 1541-II & 5.25 Disketten C64 1541	http://cgi.ebay.de/Commodore-C64-II-1541-II-5-25-Disketten-C64-1541_W0QQitemZ190366781780QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903667817808080_1.jpg	190366781780	good	complete with extras	45.50	2010-01-31 19:05:39	2010-01-23 00:02:57.612184	2010-02-01 11:54:06.034563	1903667817808080_1.jpg	image/jpg	1771	2010-01-23 00:02:57.483742
350	3	DE	EUR	Commodore 64, Datasette 1531,  Floppy Laufwerk 1541,SUN	http://cgi.ebay.de/Commodore-64-Datasette-1531-Floppy-Laufwerk-1541-SUN_W0QQitemZ170434162600QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704341626008080_1.jpg	170434162600	average	complete with extras	42.50	2010-01-31 19:00:14	2010-01-23 00:02:39.058565	2010-02-01 11:54:14.277201	1704341626008080_1.jpg	image/jpg	980	2010-01-23 00:02:38.860638
349	21	DE	EUR	Commodore Floppy 1541-II für den C 64 incl. Netzteil 	http://cgi.ebay.de/Commodore-Floppy-1541-II-fuer-den-C-64-incl-Netzteil_W0QQitemZ330397625500QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3303976255008080_1.jpg	330397625500	good	boxed	29.90	2010-01-31 13:31:36	2010-01-23 00:02:23.883204	2010-02-01 11:56:02.323577	3303976255008080_1.jpg	image/jpg	1233	2010-01-23 00:02:23.758332
154	7	DE	EUR	Commodore 128 m. Disk Drive, Datassette und Disketten 	http://cgi.ebay.de/Commodore-128-m-Disk-Drive-Datassette-und-Disketten_W0QQitemZ160395575703QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1603955757038080_1.jpg	160395575703	good	complete with extras	24.49	2010-01-23 16:16:51	2010-01-19 14:01:50.269461	2010-01-23 20:17:20.631936	1603955757038080_1.jpg	image/jpg	1018	2010-01-19 14:01:50.137137
365	36	FR	EUR	Amiga 1200 A1200 Rom 3.1 disque dur 6.49Go Atari Texas	http://cgi.ebay.fr/Amiga-1200-A1200-Rom-3-1-disque-dur-6-49Go-Atari-Texas_W0QQitemZ270520027170QQcategoryZ113187QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705200271708080_1.jpg	270520027170	good	bare	90.00	2010-01-30 19:05:03	2010-01-23 20:15:45.960929	2010-01-31 02:10:33.640175	2705200271708080_1.jpg	image/jpg	725	2010-01-23 20:15:45.816873
368	38	US	USD	Apple Mac M0487 Keyboard II	http://cgi.ebay.com/Apple-Mac-M0487-Keyboard-II_W0QQitemZ200409050845QQcategoryZ33963QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004090508458080_3.jpg	200409050845	good	bare	\N	2010-02-20 09:07:06	2010-01-23 22:29:44.749738	2010-01-23 22:29:44.749738	2004090508458080_3.jpg	image/jpg	809	2010-01-23 22:29:44.594525
375	39	DE	EUR	SINCLAIR ZX 81  HOMECOMPUTER MIT TASTATUR OHNE ZUBEHÖR	http://cgi.ebay.de/SINCLAIR-ZX-81-HOMECOMPUTER-MIT-TASTATUR-OHNE-ZUBEHOR_W0QQitemZ230426519616QQcategoryZ8099QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304265196168080_1.jpg	230426519616	average	bare	21.50	2010-01-29 18:08:22	2010-01-23 22:33:57.455061	2010-01-31 02:11:14.87085	2304265196168080_1.jpg	image/jpg	1185	2010-01-23 22:33:57.322826
379	1	IT	EUR	Commodore Amiga 1000 in box	http://cgi.ebay.it/Commodore-Amiga-1000-in-box_W0QQitemZ300389574833QQcategoryZ4598QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3003895748338080_1.jpg	300389574833	good	boxed with extras	391.00	2010-02-01 14:01:12	2010-01-23 22:45:45.270279	2010-02-02 00:17:06.491738	3003895748338080_1.jpg	image/jpg	1251	2010-01-23 22:45:45.156908
366	39	DE	EUR	Sinclair ZX81 + ZX 16K RAM + ZX-PIO-Trainer und Zubehör	http://cgi.ebay.de/Sinclair-ZX81-ZX-16K-RAM-ZX-PIO-Trainer-und-Zubehoer_W0QQitemZ170433542177QQcategoryZ8099QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704335421778080_1.jpg	170433542177	good	complete with extras	88.30	2010-01-24 13:38:29	2010-01-23 22:28:46.518589	2010-01-24 18:40:21.595114	1704335421778080_1.jpg	image/jpg	1310	2010-01-23 22:28:46.383512
372	39	US	USD	Original 1982 USA Sinclair ZX81 and 16K RAM Pack	http://cgi.ebay.com/Original-1982-USA-Sinclair-ZX81-and-16K-RAM-Pack_W0QQitemZ160395988037QQcategoryZ162075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1603959880378080_1.jpg	160395988037	good	complete with extras	36.00	2010-01-24 19:07:56	2010-01-23 22:31:10.118107	2010-01-24 21:08:45.399326	1603959880378080_1.jpg	image/jpg	1094	2010-01-23 22:31:09.97985
373	39	US	USD	Collectors:  Eartly '80s Sinclair ZX81 1K Kit Complete	http://cgi.ebay.com/Collectors-Eartly-80s-Sinclair-ZX81-1K-Kit-Complete_W0QQitemZ160395997045QQcategoryZ162075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1603959970458080_1.jpg	160395997045	good	boxed	103.84	2010-01-24 19:21:18	2010-01-23 22:32:07.342195	2010-01-24 21:08:45.988964	1603959970458080_1.jpg	image/jpg	1003	2010-01-23 22:32:07.216992
377	1	DE	EUR	Commodore Amiga 1000 incl. Speichererweiterung	http://cgi.ebay.de/Commodore-Amiga-1000-incl-Speichererweiterung_W0QQitemZ290393023091QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2903930230918080_1.jpg	290393023091	poor	bare	71.00	2010-01-25 20:05:22	2010-01-23 22:42:54.316258	2010-01-25 22:51:19.210189	2903930230918080_1.jpg	image/jpg	1127	2010-01-23 22:42:54.186416
361	36	DE	EUR	Amiga 1200 HD, Funktionsfähig mit Zubehör	http://cgi.ebay.de/Amiga-1200-HD-Funktionsfaehig-mit-Zubehoer_W0QQitemZ120518474739QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1205184747398080_1.jpg	120518474739	good	complete	68.83	2010-01-25 17:58:28	2010-01-23 20:13:02.500068	2010-01-25 22:53:36.323554	1205184747398080_1.jpg	image/jpg	1077	2010-01-23 20:13:02.364004
362	36	DE	EUR	Amiga 1200	http://cgi.ebay.de/Amiga-1200_W0QQitemZ330397788933QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3303977889338080_1.jpg	330397788933	good	complete with extras	60.00	2010-01-26 22:02:17	2010-01-23 20:13:14.459529	2010-01-27 11:52:31.760465	3303977889338080_1.jpg	image/jpg	880	2010-01-23 20:13:14.327034
364	36	DE	EUR	Amiga 1200 HD "Amiga Magic" 170 MB +RTC +8 MB Fast RAM	http://cgi.ebay.de/Amiga-1200-HD-Amiga-Magic-170-MB-RTC-8-MB-Fast-RAM_W0QQitemZ270517087624QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2705170876248080_1.jpg	270517087624	good	complete	132.00	2010-01-27 21:43:26	2010-01-23 20:13:39.325888	2010-01-28 10:53:01.188757	2705170876248080_1.jpg	image/jpg	1026	2010-01-23 20:13:39.183407
363	36	DE	EUR	Amiga 1200, CD-Laufwerk und Bildschirm + Zubehör	http://cgi.ebay.de/Amiga-1200-CD-Laufwerk-und-Bildschirm-Zubehoer_W0QQitemZ390145844375QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3901458443758080_1.jpg	390145844375	good	complete with extras	204.99	2010-01-27 16:46:14	2010-01-23 20:13:24.216624	2010-01-28 10:55:07.259764	3901458443758080_1.jpg	image/jpg	1281	2010-01-23 20:13:24.068359
360	32	DE	EUR	Commodore SX-64 / SX 64 - C64 als portable Version	http://cgi.ebay.de/Commodore-SX-64-SX-64-C64-als-portable-Version_W0QQitemZ180457596940QQcategoryZ135886QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1804575969408080_1.jpg	180457596940	good	complete	123.22	2010-01-27 13:19:50	2010-01-23 00:10:08.602623	2010-01-28 10:55:56.523551	1804575969408080_1.jpg	image/jpg	1167	2010-01-23 00:10:07.088573
389	36	DE	EUR	=== Commodore Amiga 1200 mit Zubehör ===	http://cgi.ebay.de/Commodore-Amiga-1200-mit-Zubehoer_W0QQitemZ110481330043QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104813300438080_1.jpg	110481330043	good	complete with extras	\N	2010-02-13 14:53:43	2010-01-23 22:52:49.444906	2010-01-23 22:52:49.444906	1104813300438080_1.jpg	image/jpg	1116	2010-01-23 22:52:49.334781
390	36	DE	EUR	=== Original Commodore Amiga 1200 A1200 ===	http://cgi.ebay.de/Original-Commodore-Amiga-1200-A1200_W0QQitemZ110481707515QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104817075158080_1.jpg	110481707515	good	bare	\N	2010-02-14 09:32:54	2010-01-23 22:53:04.407762	2010-01-23 22:53:04.407762	1104817075158080_1.jpg	image/jpg	932	2010-01-23 22:53:04.303899
392	23	AU	AUD	Amiga 500 Bundle 1	http://cgi.ebay.com.au/Amiga-500-Bundle-1_W0QQitemZ150408068445QQcategoryZ4598QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1504080684458080_1.jpg	150408068445	average	complete with extras	\N	2010-02-02 20:56:48	2010-01-23 22:55:38.159821	2010-01-23 22:55:38.159821	1504080684458080_1.jpg	image/jpg	997	2010-01-23 22:55:38.048274
393	23	AU	AUD	Amiga 500 Bundle 3	http://cgi.ebay.com.au/Amiga-500-Bundle-3_W0QQitemZ150408070066QQcategoryZ4598QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1504080700668080_1.jpg	150408070066	average	complete with extras	\N	2010-02-02 21:03:29	2010-01-23 22:55:50.715532	2010-01-23 22:55:50.715532	1504080700668080_1.jpg	image/jpg	922	2010-01-23 22:55:50.605985
385	36	DE	EUR	Amiga 1200 mit Zubehör und 250 Disketten	http://cgi.ebay.de/Amiga-1200-mit-Zubehoer-und-250-Disketten_W0QQitemZ320476207935QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3204762079358080_1.jpg	320476207935	average	complete with extras	48.00	2010-01-24 18:27:00	2010-01-23 22:49:36.935493	2010-01-24 18:39:38.287191	3204762079358080_1.jpg	image/jpg	1387	2010-01-23 22:49:36.822357
396	23	DE	EUR	Amiga 500 komplett mit Zubehör	http://cgi.ebay.de/Amiga-500-komplett-mit-Zubehoer_W0QQitemZ230424204751QQcategoryZ8154QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2304242047518080_1.jpg	230424204751	poor	complete with extras	31.00	2010-01-24 18:00:09	2010-01-23 22:57:14.610566	2010-01-24 18:39:54.175578	2304242047518080_1.jpg	image/jpg	1248	2010-01-23 22:57:14.506333
395	23	DE	EUR	 AMIGA 500, funktionstüchtig.   	http://cgi.ebay.de/AMIGA-500-funktionstuechtig_W0QQitemZ200429010673QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004290106738080_1.jpg	200429010673	average	complete	19.00	2010-01-24 15:00:45	2010-01-23 22:56:54.314809	2010-01-24 18:40:18.903122	2004290106738080_1.jpg	image/jpg	1174	2010-01-23 22:56:54.200375
386	36	DE	EUR	Commodore Amiga 1200 Komplettpaket CD Turbo HD Software	http://cgi.ebay.de/Commodore-Amiga-1200-Komplettpaket-CD-Turbo-HD-Software_W0QQitemZ110482762780QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1104827627808080_1.jpg	110482762780	average	complete with extras	150.79	2010-01-24 19:40:33	2010-01-23 22:50:16.010473	2010-01-24 21:08:51.040353	1104827627808080_1.jpg	image/jpg	1419	2010-01-23 22:50:15.898003
398	23	DE	EUR	1 x commodore amiga 500 floppy platt	http://cgi.ebay.de/1-x-commodore-amiga-500-floppy-platt_W0QQitemZ160395867125QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1603958671258080_1.jpg	160395867125	poor	complete	4.00	2010-01-24 19:00:01	2010-01-23 22:58:23.752087	2010-01-24 21:08:53.138624	1603958671258080_1.jpg	image/jpg	986	2010-01-23 22:58:23.640388
399	23	DE	EUR	Amiga 500+, Topzustand, Collectors Edition, kein Gilb	http://cgi.ebay.de/Amiga-500-Topzustand-Collectors-Edition-kein-Gilb_W0QQitemZ140374095747QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1403740957478080_1.jpg	140374095747	average	complete	44.50	2010-01-24 19:00:42	2010-01-23 22:58:40.140701	2010-01-24 21:08:53.751585	1403740957478080_1.jpg	image/jpg	1029	2010-01-23 22:58:40.051141
400	23	DE	EUR	Amiga 500	http://cgi.ebay.de/Amiga-500_W0QQitemZ260535532655QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2605355326558080_1.jpg	260535532655	good	complete	20.50	2010-01-24 19:30:20	2010-01-23 22:59:00.69888	2010-01-24 21:08:54.769903	2605355326558080_1.jpg	image/jpg	1017	2010-01-23 22:59:00.589134
381	36	AU	AUD	 A1200 Commodore Amiga 1200	http://cgi.ebay.com.au/A1200-Commodore-Amiga-1200_W0QQitemZ140375813463QQcategoryZ4598QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1403758134638080_1.jpg	140375813463	good	complete with extras	233.50	2010-01-26 08:20:47	2010-01-23 22:47:54.243514	2010-01-27 11:53:04.845123	1403758134638080_1.jpg	image/jpg	1139	2010-01-23 22:47:54.134746
388	36	DE	EUR	Amiga 1200 mit ca.800 Disketten und viel zubehör	http://cgi.ebay.de/Amiga-1200-mit-ca-800-Disketten-und-viel-zubehoer_W0QQitemZ170433773404QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704337734048080_1.jpg	170433773404	average	complete with extras	201.00	2010-01-27 19:22:35	2010-01-23 22:51:16.367452	2010-01-28 10:54:46.505461	1704337734048080_1.jpg	image/jpg	1102	2010-01-23 22:51:16.255713
419	23	DE	EUR	Amiga 500	http://cgi.ebay.de/Amiga-500_W0QQitemZ220545417490QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2205454174908080_1.jpg	220545417490	average	complete	41.73	2010-01-30 21:01:41	2010-01-23 23:05:01.866669	2010-01-31 02:10:23.366579	2205454174908080_1.jpg	image/jpg	1077	2010-01-23 23:05:01.759802
418	23	DE	EUR	AMIGA 500 INCL. ORIGINALVERPACKUNG - ANSEHEN	http://cgi.ebay.de/AMIGA-500-INCL-ORIGINALVERPACKUNG-ANSEHEN_W0QQitemZ150408019502QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1504080195028080_1.jpg	150408019502	average	boxed	26.50	2010-01-30 17:58:37	2010-01-23 23:04:54.216074	2010-01-31 02:10:34.254665	1504080195028080_1.jpg	image/jpg	1015	2010-01-23 23:04:54.10287
416	23	DE	EUR	Amiga 500 4 Platinen !!ANSEHEN !!	http://cgi.ebay.de/Amiga-500-4-Platinen-ANSEHEN_W0QQitemZ230427916900QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304279169008080_1.jpg	230427916900	poor	complete with extras	11.74	2010-01-29 20:21:15	2010-01-23 23:04:14.852406	2010-01-31 02:11:03.555963	2304279169008080_1.jpg	image/jpg	1151	2010-01-23 23:04:14.741759
414	23	DE	EUR	AMIGA 500 mit Netzteil	http://cgi.ebay.de/AMIGA-500-mit-Netzteil_W0QQitemZ130361035273QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1303610352738080_1.jpg	130361035273	average	complete	10.50	2010-01-29 16:04:09	2010-01-23 23:03:44.078713	2010-01-31 02:11:26.695241	1303610352738080_1.jpg	image/jpg	821	2010-01-23 23:03:43.972974
417	23	DE	EUR	** AMIGA 500    + 1MB SPEICHERERWEITERUNG  **	http://cgi.ebay.de/AMIGA-500-1MB-SPEICHERERWEITERUNG_W0QQitemZ290393124677QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2903931246778080_1.jpg	290393124677	good	boxed	\N	2010-02-17 22:23:20	2010-01-23 23:04:39.146063	2010-01-23 23:04:39.146063	2903931246778080_1.jpg	image/jpg	1031	2010-01-23 23:04:39.041065
420	23	DE	EUR	COMMODORE AMIGA 500    + 1MB SPEICHERERWEITERUNG WEISS	http://cgi.ebay.de/COMMODORE-AMIGA-500-1MB-SPEICHERERWEITERUNG-WEISS_W0QQitemZ290394397347QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2903943973478080_1.jpg	290394397347	good	complete	\N	2010-02-21 12:37:04	2010-01-23 23:05:07.694869	2010-01-23 23:05:07.694869	2903943973478080_1.jpg	image/jpg	1130	2010-01-23 23:05:07.590236
422	23	DE	EUR	=== Amiga 500 mit Zubehör ===	http://cgi.ebay.de/Amiga-500-mit-Zubehoer_W0QQitemZ110484461964QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1104844619648080_1.jpg	110484461964	average	complete with extras	\N	2010-02-20 15:12:45	2010-01-23 23:05:32.21836	2010-01-23 23:05:32.21836	1104844619648080_1.jpg	image/jpg	1050	2010-01-23 23:05:32.112728
423	23	DE	EUR	=== Amiga 500 mit Zubehör ===	http://cgi.ebay.de/Amiga-500-mit-Zubehoer_W0QQitemZ110484378241QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1104843782418080_1.jpg	110484378241	good	complete with extras	\N	2010-02-20 09:39:20	2010-01-23 23:05:46.085807	2010-01-23 23:05:46.085807	1104843782418080_1.jpg	image/jpg	1110	2010-01-23 23:05:45.971093
404	23	DE	EUR	Commodore Amiga 500 Videospielkonsole	http://cgi.ebay.de/Commodore-Amiga-500-Videospielkonsole_W0QQitemZ220542745851QQcategoryZ3545QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2205427458518080_1.jpg	220542745851	average	boxed with extras	20.50	2010-01-25 17:18:52	2010-01-23 23:00:29.424047	2010-01-25 22:53:42.358245	2205427458518080_1.jpg	image/jpg	1375	2010-01-23 23:00:29.313606
403	23	DE	EUR	Amiga 500	http://cgi.ebay.de/Amiga-500_W0QQitemZ220540774610QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2205407746108080_1.jpg	220540774610	average	complete	17.10	2010-01-24 21:52:51	2010-01-23 23:00:04.73074	2010-01-25 22:55:58.187529	2205407746108080_1.jpg	image/jpg	891	2010-01-23 23:00:04.614969
411	23	DE	EUR	Amiga 500 + Monitor + Software + Joysticks + Drucker	http://cgi.ebay.de/Amiga-500-Monitor-Software-Joysticks-Drucker_W0QQitemZ280454605359QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2804546053598080_1.jpg	280454605359	good	complete with extras	30.50	2010-01-28 10:19:10	2010-01-23 23:03:09.5046	2010-01-28 10:52:09.8408	2804546053598080_1.jpg	image/jpg	1154	2010-01-23 23:03:09.388175
410	23	DE	EUR	Amiga 500 + Externes Laufwerk + Spiele	http://cgi.ebay.de/Amiga-500-Externes-Laufwerk-Spiele_W0QQitemZ220542268511QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2205422685118080_1.jpg	220542268511	poor	complete	30.51	2010-01-27 20:10:06	2010-01-23 23:02:33.459126	2010-01-28 10:54:40.792591	2205422685118080_1.jpg	image/jpg	980	2010-01-23 23:02:33.354156
409	23	DE	EUR	Amiga 500	http://cgi.ebay.de/Amiga-500_W0QQitemZ270516947695QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2705169476958080_1.jpg	270516947695	average	complete with extras	18.81	2010-01-27 18:51:43	2010-01-23 23:02:09.355603	2010-01-28 10:54:54.950093	2705169476958080_1.jpg	image/jpg	970	2010-01-23 23:02:09.249892
406	23	DE	EUR	Amiga 500 Deluxe	http://cgi.ebay.de/Amiga-500-Deluxe_W0QQitemZ220541990511QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2205419905118080_1.jpg	220541990511	good	boxed	35.50	2010-01-27 14:28:11	2010-01-23 23:01:15.336057	2010-01-28 10:55:56.000263	2205419905118080_1.jpg	image/jpg	1248	2010-01-23 23:01:15.224789
412	23	DE	EUR	Commodore \\ Amiga \\ Amiga 500 \\ 	http://cgi.ebay.de/Commodore-Amiga-Amiga-500_W0QQitemZ270519943307QQcategoryZ8154QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2705199433078080_1.jpg	270519943307	good	complete with extras	4.00	2010-01-28 16:08:03	2010-01-23 23:03:24.021695	2010-01-28 21:01:19.090145	2705199433078080_1.jpg	image/jpg	1144	2010-01-23 23:03:23.912185
413	23	DE	EUR	Amiga 500 m. Zubehör (ca. 690 Disketten)	http://cgi.ebay.de/Amiga-500-m-Zubehoer-ca-690-Disketten_W0QQitemZ190367205420QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903672054208080_1.jpg	190367205420	average	complete with extras	30.50	2010-01-28 19:15:42	2010-01-23 23:03:30.289068	2010-01-28 21:01:21.271242	1903672054208080_1.jpg	image/jpg	992	2010-01-23 23:03:30.186019
415	23	DE	EUR	Commodore Amiga 500 Videospielkonsole	http://cgi.ebay.de/Commodore-Amiga-500-Videospielkonsole_W0QQitemZ190367478964QQcategoryZ3545QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903674789648080_1.jpg	190367478964	average	boxed	10.50	2010-01-29 17:44:00	2010-01-23 23:03:56.407094	2010-01-31 02:11:29.897836	1903674789648080_1.jpg	image/jpg	849	2010-01-23 23:03:56.305326
421	23	DE	EUR	Commodore AMIGA 500 mit OVP und viel Zubehör (TOP)	http://cgi.ebay.de/Commodore-AMIGA-500-mit-OVP-und-viel-Zubehoer-TOP_W0QQitemZ110484385982QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1104843859828080_1.jpg	110484385982	good	complete with extras	111.50	2010-01-31 10:13:02	2010-01-23 23:05:24.019663	2010-01-31 12:46:30.432779	1104843859828080_1.jpg	image/jpg	1321	2010-01-23 23:05:23.911941
425	23	DE	EUR	Commodore Amiga 500	http://cgi.ebay.de/Commodore-Amiga-500_W0QQitemZ110484510207QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104845102078080_1.jpg	110484510207	good	complete with extras	\N	2010-01-31 17:15:43	2010-01-23 23:06:10.460552	2010-01-23 23:06:10.460552	1104845102078080_1.jpg	image/jpg	940	2010-01-23 23:06:10.349446
427	23	DE	EUR	Commodore Amiga-500 Kick 1.2 mit C= Taste !! 1. Serie!	http://cgi.ebay.de/Commodore-Amiga-500-Kick-1-2-mit-C-Taste-1-Serie_W0QQitemZ380199671483QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3801996714838080_1.jpg	380199671483	good	complete	\N	2010-01-31 17:21:20	2010-01-23 23:07:05.134749	2010-01-23 23:07:05.134749	3801996714838080_1.jpg	image/jpg	811	2010-01-23 23:07:05.040923
430	23	DE	EUR	Commodore Amiga-500 Rev. 8A mit 2MB Chipram Agnus !	http://cgi.ebay.de/Commodore-Amiga-500-Rev-8A-mit-2MB-Chipram-Agnus_W0QQitemZ380199671635QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3801996716358080_1.jpg	380199671635	good	complete	\N	2010-01-31 17:21:55	2010-01-23 23:07:45.002647	2010-01-23 23:07:45.002647	3801996716358080_1.jpg	image/jpg	788	2010-01-23 23:07:44.848491
431	23	DE	EUR	Commodore Amiga-500 mit vielen Spielen !!	http://cgi.ebay.de/Commodore-Amiga-500-mit-vielen-Spielen_W0QQitemZ380199671540QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3801996715408080_1.jpg	380199671540	good	complete with extras	\N	2010-01-31 17:21:36	2010-01-23 23:07:56.215914	2010-01-23 23:07:56.215914	3801996715408080_1.jpg	image/jpg	1217	2010-01-23 23:07:56.109821
432	23	DE	EUR	Commodore Amiga-500 Homecomputer	http://cgi.ebay.de/Commodore-Amiga-500-Homecomputer_W0QQitemZ380199671292QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3801996712928080_1.jpg	380199671292	average	complete	\N	2010-01-31 17:20:51	2010-01-23 23:08:13.142606	2010-01-23 23:08:13.142606	3801996712928080_1.jpg	image/jpg	827	2010-01-23 23:08:13.030418
433	23	DE	EUR	Commodore Amiga-500  UR-Version in OVP, von 1987 !!	http://cgi.ebay.de/Commodore-Amiga-500-UR-Version-in-OVP-von-1987_W0QQitemZ380199670924QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3801996709248080_1.jpg	380199670924	average	boxed	\N	2010-01-31 17:20:21	2010-01-23 23:08:22.76816	2010-01-23 23:08:22.76816	3801996709248080_1.jpg	image/jpg	1017	2010-01-23 23:08:22.645373
434	23	DE	EUR	Commodore Amiga-500 in OVP in TOP Zustand !!	http://cgi.ebay.de/Commodore-Amiga-500-in-OVP-in-TOP-Zustand_W0QQitemZ380199671414QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3801996714148080_1.jpg	380199671414	good	boxed	\N	2010-01-31 17:21:06	2010-01-23 23:08:34.731016	2010-01-23 23:08:34.731016	3801996714148080_1.jpg	image/jpg	1208	2010-01-23 23:08:34.626439
438	23	FR	EUR	Amiga  500 A500 A1200 + Ext. ram à 1Mo Atari TRS Texas	http://cgi.ebay.fr/Amiga-500-A500-A1200-Ext-ram-a-1Mo-Atari-TRS-Texas_W0QQitemZ270520021621QQcategoryZ113187QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2705200216218080_1.jpg	270520021621	average	complete	76.00	2010-01-30 18:54:28	2010-01-23 23:10:48.392063	2010-01-31 02:10:33.93411	2705200216218080_1.jpg	image/jpg	775	2010-01-23 23:10:48.282201
437	23	FR	EUR	AMIGA 500 Extension mémoire + Nbreux JEUX	http://cgi.ebay.fr/AMIGA-500-Extension-memoire-Nbreux-JEUX_W0QQitemZ400099219854QQcategoryZ113187QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/4000992198548080_1.jpg	400099219854	average	complete with extras	25.50	2010-01-30 17:28:33	2010-01-23 23:10:35.43079	2010-01-31 02:10:36.382271	4000992198548080_1.jpg	image/jpg	1061	2010-01-23 23:10:35.315105
426	23	DE	EUR	Amiga 500	http://cgi.ebay.de/Amiga-500_W0QQitemZ320478065340QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204780653408080_1.jpg	320478065340	good	complete with extras	91.00	2010-01-31 19:10:17	2010-01-23 23:06:43.254005	2010-02-01 11:53:58.290556	3204780653408080_1.jpg	image/jpg	1080	2010-01-23 23:06:43.159642
444	23	UK	USD	COMMODORE AMIGA 500 COMPUTER SYSTEM A500 MONITOR EXTRAS	http://cgi.ebay.com/COMMODORE-AMIGA-500-COMPUTER-SYSTEM-A500-MONITOR-EXTRAS_W0QQitemZ260540649203QQcategoryZ4598QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2605406492038080_1.jpg	260540649203	good	complete with extras	76.00	2010-01-27 02:22:13	2010-01-23 23:13:41.409888	2010-01-27 11:51:11.009425	2605406492038080_1.jpg	image/jpg	1208	2010-01-23 23:13:41.301908
440	23	IT	EUR	Commodore AMIGA 500 1MB	http://cgi.ebay.it/Commodore-AMIGA-500-1MB_W0QQitemZ270519185642QQcategoryZ4598QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705191856428080_1.jpg	270519185642	average	boxed with extras	39.00	2010-01-26 21:33:32	2010-01-23 23:11:33.424871	2010-01-27 11:52:33.307729	2705191856428080_1.jpg	image/jpg	1215	2010-01-23 23:11:33.324686
441	23	IT	EUR	RETROCOMPUTER  COMMODORE AMIGA 500 PLUS	http://cgi.ebay.it/RETROCOMPUTER-COMMODORE-AMIGA-500-PLUS_W0QQitemZ310195978097QQcategoryZ4598QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3101959780978080_1.jpg	310195978097	good	complete	24.50	2010-01-28 16:43:41	2010-01-23 23:11:55.957148	2010-01-29 12:34:51.759938	3101959780978080_1.jpg	image/jpg	994	2010-01-23 23:11:55.849284
424	23	DE	EUR	AMIGA 500,Speichererw,Maus,ExtFloppy,MK III !!!	http://cgi.ebay.de/AMIGA-500-Speichererw-Maus-ExtFloppy-MK-III_W0QQitemZ180459527483QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1804595274838080_1.jpg	180459527483	average	complete with extras	40.50	2010-01-31 16:52:05	2010-01-23 23:05:59.132586	2010-02-01 11:55:45.58575	1804595274838080_1.jpg	image/jpg	993	2010-01-23 23:05:59.027585
443	23	IT	EUR	Commodore Amiga 500	http://cgi.ebay.it/Commodore-Amiga-500_W0QQitemZ320478534182QQcategoryZ4598QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204785341828080_1.jpg	320478534182	good	complete	35.00	2010-02-01 20:27:59	2010-01-23 23:12:50.99908	2010-02-02 00:18:13.041283	3204785341828080_1.jpg	image/jpg	1264	2010-01-23 23:12:50.889315
446	9	UK	USD	Apple IIC Computer Parts or Repair	http://cgi.ebay.com/Apple-IIC-Computer-Parts-or-Repair_W0QQitemZ370305390034QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3703053900348080_2.jpg	370305390034	poor	bare	\N	2010-02-09 18:14:08	2010-01-23 23:19:04.035152	2010-01-23 23:19:04.035152	3703053900348080_2.jpg	image/jpg	1016	2010-01-23 23:19:03.933257
448	9	UK	USD	Apple IIc in Original Retail Box + Apple DOS Disk!	http://cgi.ebay.com/Apple-IIc-in-Original-Retail-Box-Apple-DOS-Disk_W0QQitemZ150404895296QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1504048952968080_1.jpg	150404895296	good	boxed	\N	2010-02-11 20:13:33	2010-01-23 23:20:20.550032	2010-01-23 23:20:20.550032	1504048952968080_1.jpg	image/jpg	1312	2010-01-23 23:20:20.443775
457	9	FR	EUR	► Collector !!! APPLE IIC avec sacoche d'origine 1984 ◄	http://cgi.ebay.fr/Collector-APPLE-IIC-avec-sacoche-dorigine-1984_W0QQitemZ230427895467QQcategoryZ51046QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2304278954678080_1.jpg	230427895467	good	complete with extras	63.00	2010-01-29 19:40:03	2010-01-23 23:24:59.573572	2010-01-31 02:11:09.909257	2304278954678080_1.jpg	image/jpg	1077	2010-01-23 23:24:59.455954
452	9	UK	USD	Vintage Apple IIC Compact Computer - Collectable	http://cgi.ebay.com/Vintage-Apple-IIC-Compact-Computer-Collectable_W0QQitemZ350306973738QQcategoryZ51046QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3503069737388080_1.jpg	350306973738	average	complete	\N	2010-02-18 07:26:22	2010-01-23 23:22:07.455317	2010-01-23 23:22:07.455317	3503069737388080_1.jpg	image/jpg	724	2010-01-23 23:22:07.348579
453	9	UK	USD	Apple IIc Computer and Monitor	http://cgi.ebay.com/Apple-IIc-Computer-and-Monitor_W0QQitemZ200431099787QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2004310997878080_1.jpg	200431099787	poor	complete with extras	29.00	2010-02-01 03:09:39	2010-01-23 23:22:30.216	2010-02-01 11:52:03.651096	2004310997878080_1.jpg	image/jpg	1013	2010-01-23 23:22:30.124809
462	5	UK	USD	Apple IIe //e 2e Vintage Computer with Monitor + Extras	http://cgi.ebay.com/Apple-IIe-e-2e-Vintage-Computer-with-Monitor-Extras_W0QQitemZ250568325719QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2505683257198080_1.jpg	250568325719	good	complete with extras	\N	2010-02-22 08:14:16	2010-01-23 23:37:28.631273	2010-01-23 23:37:28.631273	2505683257198080_1.jpg	image/jpg	1372	2010-01-23 23:37:28.539175
464	5	UK	USD	Unusual Original Apple IIe - Wonderful Condition-Runs!	http://cgi.ebay.com/Unusual-Original-Apple-IIe-Wonderful-Condition-Runs_W0QQitemZ200428718507QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2004287185078080_1.jpg	200428718507	good	complete	\N	2010-02-15 02:54:55	2010-01-23 23:38:30.027331	2010-01-23 23:38:30.027331	2004287185078080_1.jpg	image/jpg	1261	2010-01-23 23:38:29.933407
465	5	UK	USD	Apple IIe A2S2064 Computer Parts or Repair	http://cgi.ebay.com/Apple-IIe-A2S2064-Computer-Parts-or-Repair_W0QQitemZ370305380415QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3703053804158080_2.jpg	370305380415	poor	bare	\N	2010-02-09 17:52:48	2010-01-23 23:38:41.495231	2010-01-23 23:38:41.495231	3703053804158080_2.jpg	image/jpg	980	2010-01-23 23:38:41.390771
463	5	UK	USD	APPLE IIe model A2S2064 in working condition	http://cgi.ebay.com/APPLE-IIe-model-A2S2064-in-working-condition_W0QQitemZ170433826616QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704338266168080_1.jpg	170433826616	average	complete	54.00	2010-01-24 20:27:43	2010-01-23 23:37:54.354019	2010-01-24 21:09:06.769106	1704338266168080_1.jpg	image/jpg	1007	2010-01-23 23:37:54.241899
456	9	FR	EUR	SUPERBE APPLE IIC  TESTE OK !!	http://cgi.ebay.fr/SUPERBE-APPLE-IIC-TESTE-OK_W0QQitemZ110481709676QQcategoryZ51046QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1104817096768080_1.jpg	110481709676	good	complete with extras	51.00	2010-01-25 09:42:20	2010-01-23 23:24:30.950965	2010-01-25 22:53:48.96434	1104817096768080_1.jpg	image/jpg	1116	2010-01-23 23:24:30.838772
459	5	UK	USD	Pristine Apple IIe in Original Box w/Drive	http://cgi.ebay.com/Pristine-Apple-IIe-in-Original-Box-w-Drive_W0QQitemZ160396431976QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1603964319768080_1.jpg	160396431976	good	boxed with extras	442.51	2010-01-25 03:00:18	2010-01-23 23:26:27.213322	2010-01-25 22:54:22.837799	1603964319768080_1.jpg	image/jpg	1409	2010-01-23 23:26:27.106247
447	9	UK	USD	vintage APPLE IIC DESKTOP COMPUTER+MONITOR orig boxes	http://cgi.ebay.com/vintage-APPLE-IIC-DESKTOP-COMPUTER-MONITOR-orig-boxes_W0QQitemZ200430330881QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004303308818080_1.jpg	200430330881	good	boxed with extras	106.50	2010-01-27 03:08:14	2010-01-23 23:19:39.210741	2010-01-27 11:51:01.915745	2004303308818080_1.jpg	image/jpg	1207	2010-01-23 23:19:39.103735
451	9	UK	USD	Apple IIc plus computer boxed, mint, unused condition	http://cgi.ebay.com/Apple-IIc-plus-computer-boxed-mint-unused-condition_W0QQitemZ190367045757QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1903670457578080_1.jpg	190367045757	mint	boxed with extras	1425.00	2010-01-27 01:30:43	2010-01-23 23:21:55.299829	2010-01-27 11:51:15.73654	1903670457578080_1.jpg	image/jpg	1168	2010-01-23 23:21:55.188072
461	5	UK	USD	Apple IIe Vintage Retro Computer Clean 2E Must SEE	http://cgi.ebay.com/Apple-IIe-Vintage-Retro-Computer-Clean-2E-Must-SEE_W0QQitemZ270518078417QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2705180784178080_1.jpg	270518078417	average	complete	31.00	2010-01-26 19:40:49	2010-01-23 23:36:56.461152	2010-01-27 11:53:20.203987	2705180784178080_1.jpg	image/jpg	812	2010-01-23 23:36:56.35056
466	31	UK	USD	Apple IIe DuoDisk 5.25" Dual Floppy Disk Drive A9M0108	http://cgi.ebay.com/Apple-IIe-DuoDisk-5-25-Dual-Floppy-Disk-Drive-A9M0108_W0QQitemZ330398077789QQcategoryZ31566QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3303980777898080_1.jpg	330398077789	poor	complete	10.50	2010-01-27 21:30:22	2010-01-23 23:38:58.559494	2010-01-28 10:53:01.452284	3303980777898080_1.jpg	image/jpg	722	2010-01-23 23:38:58.450094
449	9	UK	USD	Apple IIc computer complete system	http://cgi.ebay.com/Apple-IIc-computer-complete-system_W0QQitemZ320478009801QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3204780098018080_1.jpg	320478009801	good	complete with extras	75.00	2010-01-28 17:16:53	2010-01-23 23:20:40.014925	2010-01-28 21:01:31.076642	3204780098018080_1.jpg	image/jpg	1164	2010-01-23 23:20:39.904782
482	18	US	USD	APPLE MACINTOSH 1984 128K M0001 WORKING SYSTEM	http://cgi.ebay.com/APPLE-MACINTOSH-1984-128K-M0001-WORKING-SYSTEM_W0QQitemZ140377069640QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1403770696408080_1.jpg	140377069640	good	bare	202.50	2010-01-30 21:25:07	2010-01-24 18:44:15.703283	2010-01-31 02:10:22.089144	1403770696408080_1.jpg	image/jpg	1062	2010-01-24 18:44:15.61158
472	28	UK	USD	Boxed Apple Disk II Drive for the Apple II II+ and IIe	http://cgi.ebay.com/Boxed-Apple-Disk-II-Drive-for-the-Apple-II-II-and-IIe_W0QQitemZ310196083301QQcategoryZ168057QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3101960833018080_1.jpg	310196083301	good	boxed	31.00	2010-02-01 02:18:15	2010-01-23 23:40:49.283095	2010-02-01 11:52:08.097232	3101960833018080_1.jpg	image/jpg	912	2010-01-23 23:40:49.178322
474	31	CA	CAD	Apple A9M0108 IIe DuoDisk 5.25 Dual Floppy Disk Drive	http://cgi.ebay.ca/Apple-A9M0108-IIe-DuoDisk-5-25-Dual-Floppy-Disk-Drive_W0QQitemZ200425221829QQcategoryZ16145QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004252218298080_1.jpg	200425221829	average	complete	\N	2010-02-05 04:04:55	2010-01-23 23:43:17.178897	2010-01-23 23:43:17.178897	2004252218298080_1.jpg	image/jpg	915	2010-01-23 23:43:17.065255
476	5	ES	EUR	★★★ TRES RARE ORDINATEUR APPLE IIe EN TRES BON ETAT ★★★	http://cgi.ebay.es/TRES-RARE-ORDINATEUR-APPLE-IIe-EN-TRES-BON-ETAT_W0QQitemZ130360038234QQcategoryZ51046QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1303600382348080_1.jpg	130360038234	average	complete	\N	2010-02-17 10:55:04	2010-01-23 23:45:03.963763	2010-01-23 23:45:03.963763	1303600382348080_1.jpg	image/jpg	1016	2010-01-23 23:45:03.860511
477	31	ES	EUR	@RARE LECTEUR DUO DISQUETTES 5-1/4  POUR APPLE IIe @	http://cgi.ebay.es/RARE-LECTEUR-DUO-DISQUETTES-5-1-4-POUR-APPLE-IIe_W0QQitemZ130360038477QQcategoryZ51046QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1303600384778080_1.jpg	130360038477	average	complete	\N	2010-02-17 10:57:24	2010-01-23 23:45:27.638086	2010-01-23 23:45:27.638086	1303600384778080_1.jpg	image/jpg	1185	2010-01-23 23:45:27.529947
478	28	ES	EUR	APPLE IIe Floppylaufwerk + Karte / Disk Drive + Board	http://cgi.ebay.es/APPLE-IIe-Floppylaufwerk-Karte-Disk-Drive-Board_W0QQitemZ300389292460QQcategoryZ171QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3003892924608080_1.jpg	300389292460	average	complete with extras	\N	2010-01-31 18:20:16	2010-01-23 23:46:16.980708	2010-01-23 23:46:16.980708	3003892924608080_1.jpg	image/jpg	910	2010-01-23 23:46:16.874317
397	23	DE	EUR	Commodore AMIGA 500	http://cgi.ebay.de/Commodore-AMIGA-500_W0QQitemZ150406294811QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1504062948118080_1.jpg	150406294811	good	complete	13.00	2010-01-24 18:28:10	2010-01-23 22:57:43.900216	2010-01-24 18:39:36.730164	1504062948118080_1.jpg	image/jpg	1134	2010-01-23 22:57:43.794963
374	39	DE	EUR	sinclair ZX 81 Computer	http://cgi.ebay.de/sinclair-ZX-81-Computer_W0QQitemZ270516911139QQcategoryZ8099QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2705169111398080_1.jpg	270516911139	good	complete	30.00	2010-01-24 18:10:31	2010-01-23 22:33:36.569283	2010-01-24 18:39:48.984849	2705169111398080_1.jpg	image/jpg	1046	2010-01-23 22:33:36.4392
330	3	DE	EUR	C64 + Speeddos+1541+ Monitor 1901 und jede Menge mehr!	http://cgi.ebay.de/C64-Speeddos-1541-Monitor-1901-und-jede-Menge-mehr_W0QQitemZ140375314511QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1403753145118080_1.jpg	140375314511	poor	complete with extras	27.50	2010-01-24 18:31:23	2010-01-22 23:56:23.251618	2010-01-24 18:41:11.23589	1403753145118080_1.jpg	image/jpg	1128	2010-01-22 23:56:23.098967
475	5	DE	EUR	APPLE IIe enhanced - sehr schöner Zustand. Vintage	http://cgi.ebay.de/APPLE-IIe-enhanced-sehr-schoener-Zustand-Vintage_W0QQitemZ300388320379QQcategoryZ171QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003883203798080_2.jpg	300388320379	average	complete	77.00	2010-01-31 18:00:20	2010-01-23 23:44:16.870829	2010-02-01 11:55:15.620229	3003883203798080_2.jpg	image/jpg	1128	2010-01-23 23:44:16.760266
483	17	CA	CAD	Atari 400 Computer w/ Power Supply & Manual - Tested!	http://cgi.ebay.ca/Atari-400-Computer-w-Power-Supply-Manual-Tested_W0QQitemZ370246212781QQcategoryZ82631QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3702462127818080_6.jpg	370246212781	average	complete with extras	\N	2010-02-12 15:13:29	2010-01-24 21:11:37.664089	2010-01-24 21:11:37.664089	3702462127818080_6.jpg	image/jpg	1311	2010-01-24 21:11:37.5414
484	17	UK	USD	Atari 400 Computer System	http://cgi.ebay.com/Atari-400-Computer-System_W0QQitemZ170392903607QQcategoryZ82631QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1703929036078080_4.jpg	170392903607	good	boxed with extras	\N	2010-02-07 14:09:05	2010-01-24 21:12:51.193355	2010-01-24 21:12:51.193355	1703929036078080_4.jpg	image/jpg	1081	2010-01-24 21:12:51.076609
480	40	US	USD	PDP8L	http://cgi.ebay.com/PDP8L_W0QQitemZ190367280748QQcategoryZ4193QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903672807488080_1.jpg	190367280748	average	bare	1225.56	2010-01-26 23:09:37	2010-01-24 01:26:30.841639	2010-01-27 11:51:31.848947	1903672807488080_1.jpg	image/jpg	1174	2010-01-24 01:26:30.738059
468	5	UK	USD	Vintage Apple IIe Computer Double 5-1/4 Floppy Drives	http://cgi.ebay.com/Vintage-Apple-IIe-Computer-Double-5-1-4-Floppy-Drives_W0QQitemZ260540593463QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2605405934638080_1.jpg	260540593463	poor	complete with extras	26.07	2010-01-26 23:06:32	2010-01-23 23:39:34.63792	2010-01-27 11:51:46.120549	2605405934638080_1.jpg	image/jpg	1124	2010-01-23 23:39:34.527791
479	40	US	USD	DEC PDP-8m Computer	http://cgi.ebay.com/DEC-PDP-8m-Computer_W0QQitemZ290393450156QQcategoryZ162075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2903934501568080_1.jpg	290393450156	good	bare	1262.00	2010-01-26 22:04:55	2010-01-24 01:25:33.223877	2010-01-27 11:52:18.091756	2903934501568080_1.jpg	image/jpg	1310	2010-01-24 01:25:33.115042
469	5	UK	USD	Vintage APPLE IIe Computer system, LOADED all original	http://cgi.ebay.com/Vintage-APPLE-IIe-Computer-system-LOADED-all-original_W0QQitemZ260542475484QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2605424754848080_1.jpg	260542475484	good	complete with extras	150.99	2010-01-28 19:44:29	2010-01-23 23:40:00.499616	2010-01-28 21:01:37.712517	2605424754848080_1.jpg	image/jpg	1152	2010-01-23 23:40:00.408936
486	17	UK	USD	atari 400 brand new still in box with papers	http://cgi.ebay.com/atari-400-brand-new-still-in-box-with-papers_W0QQitemZ320478940875QQcategoryZ82631QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3204789408758080_1.jpg	320478940875	mint	boxed	62.00	2010-01-30 20:23:47	2010-01-24 21:14:10.751416	2010-01-31 02:10:33.118237	3204789408758080_1.jpg	image/jpg	1029	2010-01-24 21:14:10.637765
436	23	FR	EUR	AMIGA 500 (boite) + moniteur 1084 + 100 jeux en boite	http://cgi.ebay.fr/AMIGA-500-boite-moniteur-1084-100-jeux-en-boite_W0QQitemZ270519625226QQcategoryZ113187QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705196252268080_1.jpg	270519625226	average	complete with extras	269.88	2010-01-25 20:23:04	2010-01-23 23:10:21.973171	2010-01-25 22:50:54.074842	2705196252268080_1.jpg	image/jpg	2089	2010-01-23 23:10:21.876328
405	23	DE	EUR	Amiga 500 mit Zubehör, 2 MB, Turbokarte 68020,  TOP	http://cgi.ebay.de/Amiga-500-mit-Zubehoer-2-MB-Turbokarte-68020-TOP_W0QQitemZ280453420717QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804534207178080_1.jpg	280453420717	good	complete with extras	74.57	2010-01-25 18:29:53	2010-01-23 23:00:46.238806	2010-01-25 22:53:35.121551	2804534207178080_1.jpg	image/jpg	899	2010-01-23 23:00:46.128073
493	23	DE	EUR	Amiga 500 mit Festplatte 2 MB Chip Ram und 8 MB Fastram	http://cgi.ebay.de/Amiga-500-mit-Festplatte-2-MB-Chip-Ram-und-8-MB-Fastram_W0QQitemZ120522233423QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1205222334238080_1.jpg	120522233423	good	complete with extras	67.00	2010-01-29 16:39:10	2010-01-25 23:13:12.193038	2010-01-31 02:11:28.393312	1205222334238080_1.jpg	image/jpg	1050	2010-01-25 23:13:12.06479
494	23	DE	EUR	Commodore Amiga 500 in OVP in TOP-Zustand	http://cgi.ebay.de/Commodore-Amiga-500-in-OVP-in-TOP-Zustand_W0QQitemZ120522109791QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1205221097918080_1.jpg	120522109791	good	boxed	\N	2010-01-31 18:43:42	2010-01-25 23:13:27.178696	2010-01-25 23:13:27.178696	1205221097918080_1.jpg	image/jpg	900	2010-01-25 23:13:26.978666
496	36	DE	EUR	AMIGA 1200	http://cgi.ebay.de/AMIGA-1200_W0QQitemZ260542876745QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605428767458080_1.jpg	260542876745	good	complete	\N	2010-02-03 16:55:05	2010-01-25 23:14:23.652699	2010-01-25 23:14:23.652699	2605428767458080_1.jpg	image/jpg	1181	2010-01-25 23:14:23.364233
352	20	US	USD	Commodore 1541 Disk Drive, original box, working 	http://cgi.ebay.com/Commodore-1541-Disk-Drive-original-box-working_W0QQitemZ290393512815QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2903935128158080_1.jpg	290393512815	good	boxed	19.99	2010-01-27 02:47:29	2010-01-23 00:03:42.521741	2010-01-27 11:51:03.623292	2903935128158080_1.jpg	image/jpg	1020	2010-01-23 00:03:42.42982
338	29	DE	EUR	commodore , c64 , floppy 1541-II , weiß, brotkasten	http://cgi.ebay.de/commodore-c64-floppy-1541-II-weiss-brotkasten_W0QQitemZ230426584684QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304265846848080_1.jpg	230426584684	average	complete with extras	12.94	2010-01-26 20:15:15	2010-01-22 23:59:12.522249	2010-01-27 11:52:38.024694	2304265846848080_1.jpg	image/jpg	1057	2010-01-22 23:59:12.422538
500	18	US	USD	vintage APPLE M0001 Computer 3.5" Drive KEYBOARD Mouse 	http://cgi.ebay.com/vintage-APPLE-M0001-Computer-3-5-Drive-KEYBOARD-Mouse_W0QQitemZ170436898423QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1704368984238080_1.jpg	170436898423	average	complete	104.92	2010-02-01 02:00:48	2010-01-27 12:37:59.833148	2010-02-01 11:52:16.679267	1704368984238080_1.jpg	image/jpg	1203	2010-01-27 12:37:59.593057
498	48	US	USD	Apple Mac 3.5 Floppy Drive A9M0106 External	http://cgi.ebay.com/Apple-Mac-3-5-Floppy-Drive-A9M0106-External_W0QQitemZ220539190715QQcategoryZ31566QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2205391907158080_1.jpg	220539190715	good	bare	\N	2010-02-11 00:48:26	2010-01-27 12:36:36.298145	2010-01-27 12:36:36.298145	2205391907158080_1.jpg	image/jpg	961	2010-01-27 12:36:36.178093
499	48	US	USD	Apple 3.5 drive used 	http://cgi.ebay.com/Apple-3-5-drive-used_W0QQitemZ290396028160QQcategoryZ168057QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2903960281608080_1.jpg	290396028160	good	bare	\N	2010-02-03 04:15:11	2010-01-27 12:37:03.495192	2010-01-27 12:37:03.495192	2903960281608080_1.jpg	image/jpg	1103	2010-01-27 12:37:03.365717
491	27	NL	EUR	Commodore SFD 1001 - IEEE488 Floppy - CBM kompatibel	http://cgi.ebay.nl/Commodore-SFD-1001-IEEE488-Floppy-CBM-kompatibel_W0QQitemZ170436977192QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704369771928080_1.jpg	170436977192	average	complete	51.00	2010-01-31 20:58:15	2010-01-24 21:27:36.316884	2010-02-01 11:52:30.69435	1704369771928080_1.jpg	image/jpg	1212	2010-01-24 21:27:36.211586
492	2	DE	EUR	Commodore PET 2001 Series	http://cgi.ebay.de/Commodore-PET-2001-Series_W0QQitemZ200432054831QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2004320548318080_1.jpg	200432054831	good	bare	302.00	2010-01-31 20:39:59	2010-01-25 23:12:25.525068	2010-02-01 11:52:31.824742	2004320548318080_1.jpg	image/jpg	1842	2010-01-25 23:12:25.410267
489	42	DE	EUR	Commodore 8296 - CBM Büromaschine - mit Tastatur 	http://cgi.ebay.de/Commodore-8296-CBM-Bueromaschine-mit-Tastatur_W0QQitemZ170436964565QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704369645658080_1.jpg	170436964565	good	boxed	79.00	2010-01-31 20:33:26	2010-01-24 21:21:24.403634	2010-02-01 11:52:39.387384	1704369645658080_1.jpg	image/jpg	1485	2010-01-24 21:21:24.225995
490	44	DE	EUR	Commodore CBM 8050 - Doppellaufwerk	http://cgi.ebay.de/Commodore-CBM-8050-Doppellaufwerk_W0QQitemZ170436962677QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704369626778080_1.jpg	170436962677	average	complete	42.49	2010-01-31 20:30:15	2010-01-24 21:24:05.270543	2010-02-01 11:52:41.702245	1704369626778080_1.jpg	image/jpg	1192	2010-01-24 21:24:05.039735
487	41	DE	EUR	CBM 710 Commodore Büromaschine - komplett	http://cgi.ebay.de/CBM-710-Commodore-Bueromaschine-komplett_W0QQitemZ170436959453QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704369594538080_1.jpg	170436959453	mint	complete	167.00	2010-01-31 20:23:42	2010-01-24 21:19:18.77151	2010-02-01 11:52:46.261092	1704369594538080_1.jpg	image/jpg	1346	2010-01-24 21:19:18.651023
495	23	DE	EUR	AMIGA 500 Commodore Maus mit Extra	http://cgi.ebay.de/AMIGA-500-Commodore-Maus-mit-Extra_W0QQitemZ280456168921QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804561689218080_1.jpg	280456168921	good	complete	9.83	2010-01-31 20:09:55	2010-01-25 23:13:44.58583	2010-02-01 11:52:55.15721	2804561689218080_1.jpg	image/jpg	737	2010-01-25 23:13:44.49684
488	41	DE	EUR	COMMODORE CBM 710 "NEW" incl. Motherboard + Tastatur	http://cgi.ebay.de/COMMODORE-CBM-710-NEW-incl-Motherboard-Tastatur_W0QQitemZ170435028877QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704350288778080_2.jpg	170435028877	mint	complete with extras	101.00	2010-01-31 17:38:30	2010-01-24 21:19:30.183456	2010-02-01 11:55:19.864148	1704350288778080_2.jpg	image/jpg	1560	2010-01-24 21:19:30.055849
503	51	US	USD	Apple External 5.25" Floppy Drive Model A9M0107	http://cgi.ebay.com/Apple-External-5-25-Floppy-Drive-Model-A9M0107_W0QQitemZ390110441184QQcategoryZ31566QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3901104411848080_4.jpg	390110441184	mint	bare	\N	2010-02-23 02:16:26	2010-01-27 12:43:21.579511	2010-01-27 12:43:21.579511	3901104411848080_4.jpg	image/jpg	861	2010-01-27 12:43:21.457853
506	51	US	USD	Apple A9M0107 II IIe IIc IIgs 5.25 External Floppy	http://cgi.ebay.com/Apple-A9M0107-II-IIe-IIc-IIgs-5-25-External-Floppy_W0QQitemZ350254867706QQcategoryZ31566QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3502548677068080_7.jpg	350254867706	good	bare	\N	2010-02-17 03:36:15	2010-01-27 12:44:21.529348	2010-01-27 12:44:21.529348	3502548677068080_7.jpg	image/jpg	778	2010-01-27 12:44:21.414913
508	51	US	USD	Vintage  Apple II 5.25 Floppy Disk Drive A9M0107 	http://cgi.ebay.com/Vintage-Apple-II-5-25-Floppy-Disk-Drive-A9M0107_W0QQitemZ200255245080QQcategoryZ51046QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2002552450808080_17.jpg	200255245080	good	bare	\N	2010-02-09 00:09:51	2010-01-27 12:44:55.378411	2010-01-27 12:44:55.378411	2002552450808080_17.jpg	image/jpg	1078	2010-01-27 12:44:55.277954
509	51	US	USD	Apple II 5.25 Floppy Disk Drive A9M0107 Vintage 	http://cgi.ebay.com/Apple-II-5-25-Floppy-Disk-Drive-A9M0107-Vintage_W0QQitemZ200255243057QQcategoryZ51046QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2002552430578080_17.jpg	200255243057	good	bare	\N	2010-02-09 00:01:29	2010-01-27 12:45:04.148222	2010-01-27 12:45:04.148222	2002552430578080_17.jpg	image/jpg	1263	2010-01-27 12:45:04.041736
510	49	US	USD	SALE! Apple II 5.25 Disk Drive with MINT Interface Card	http://cgi.ebay.com/SALE-Apple-II-5-25-Disk-Drive-with-MINT-Interface-Card_W0QQitemZ140374427779QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1403744277798080_1.jpg	140374427779	good	complete with extras	\N	2010-02-13 19:52:37	2010-01-27 12:46:24.181881	2010-01-27 12:46:24.181881	1403744277798080_1.jpg	image/jpg	841	2010-01-27 12:46:24.076656
515	9	DE	EUR	Apple IIc mit Monitor	http://cgi.ebay.de/Apple-IIc-mit-Monitor_W0QQitemZ250569055561QQcategoryZ171QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2505690555618080_1.jpg	250569055561	good	complete with extras	\N	2010-01-31 18:15:57	2010-01-27 12:49:01.363355	2010-01-27 12:49:01.363355	2505690555618080_1.jpg	image/jpg	1229	2010-01-27 12:49:01.255494
516	31	DE	EUR	Apple DUODISK	http://cgi.ebay.de/Apple-DUODISK_W0QQitemZ170437754148QQcategoryZ8101QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704377541488080_1.jpg	170437754148	good	bare	\N	2010-02-05 16:19:09	2010-01-27 12:51:08.278054	2010-01-27 12:51:08.278054	1704377541488080_1.jpg	image/jpg	1221	2010-01-27 12:51:08.157613
519	5	DE	EUR	apple IIe Computer	http://cgi.ebay.de/apple-IIe-Computer_W0QQitemZ170437748770QQcategoryZ8101QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704377487708080_1.jpg	170437748770	good	bare	\N	2010-02-05 16:03:10	2010-01-27 12:53:12.235864	2010-01-27 12:53:12.235864	1704377487708080_1.jpg	image/jpg	1155	2010-01-27 12:53:12.107165
521	36	DE	EUR	Commodore Amiga 1200	http://cgi.ebay.de/Commodore-Amiga-1200_W0QQitemZ200432663389QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004326633898080_1.jpg	200432663389	good	complete	\N	2010-02-05 17:22:54	2010-01-27 12:55:09.124458	2010-01-27 12:55:09.124458	2004326633898080_1.jpg	image/jpg	991	2010-01-27 12:55:09.011514
511	9	US	USD	Apple IIc WORKING with Orginal Boxes	http://cgi.ebay.com/Apple-IIc-WORKING-with-Orginal-Boxes_W0QQitemZ120522372223QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1205223722238080_1.jpg	120522372223	good	boxed	76.00	2010-01-29 20:42:07	2010-01-27 12:47:21.044059	2010-01-31 02:11:02.548394	1205223722238080_1.jpg	image/jpg	1233	2010-01-27 12:47:20.927689
517	38	DE	EUR	 Apple Keyboard II Tastatur  Mod. M0487  RAR qwerty	http://cgi.ebay.de/Apple-Keyboard-II-Tastatur-Mod-M0487-RAR-qwerty_W0QQitemZ180457768755QQcategoryZ26750QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1804577687558080_1.jpg	180457768755	good	bare	9.95	2010-01-27 18:00:31	2010-01-27 12:52:20.222164	2010-01-28 10:55:05.191118	1804577687558080_1.jpg	image/jpg	1307	2010-01-27 12:52:20.082111
522	7	FR	EUR	RARE ORDINATEUR COMMODORE 128 EN BOITE ULTRA COMPLET	http://cgi.ebay.fr/RARE-ORDINATEUR-COMMODORE-128-EN-BOITE-ULTRA-COMPLET_W0QQitemZ390146430789QQcategoryZ113190QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3901464307898080_1.jpg	390146430789	good	boxed	137.00	2010-01-28 21:52:07	2010-01-27 13:03:45.481688	2010-01-29 12:34:24.947314	3901464307898080_1.jpg	image/jpg	921	2010-01-27 13:03:45.361049
507	51	US	USD	Apple 5.25" Floppy Disk Drive	http://cgi.ebay.com/Apple-5-25-Floppy-Disk-Drive_W0QQitemZ220545492781QQcategoryZ82629QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2205454927818080_1.jpg	220545492781	average	bare	0.99	2010-02-01 03:00:17	2010-01-27 12:44:45.080321	2010-02-01 11:52:04.395508	2205454927818080_1.jpg	image/jpg	1156	2010-01-27 12:44:44.9594
512	9	US	USD	Vintage Apple IIc Computer system, software, periperals	http://cgi.ebay.com/Vintage-Apple-IIc-Computer-system-software-periperals_W0QQitemZ270520570597QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2705205705978080_1.jpg	270520570597	good	complete with extras	41.00	2010-01-31 20:36:33	2010-01-27 12:47:40.856684	2010-02-01 11:52:34.435949	2705205705978080_1.jpg	image/jpg	1189	2010-01-27 12:47:40.738138
524	4	DE	EUR	Commodore VC20 "weiß" - OVP & Zubehör - VC VIC 20 VIC20	http://cgi.ebay.de/Commodore-VC20-weiss-OVP-Zubehoer-VC-VIC-20-VIC20_W0QQitemZ190366783048QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903667830488080_1.jpg	190366783048	good	boxed	64.11	2010-01-31 19:10:09	2010-01-27 13:06:19.840094	2010-02-01 11:54:00.768933	1903667830488080_1.jpg	image/jpg	1831	2010-01-27 13:06:19.721719
520	36	DE	EUR	Amiga 1200, Funktionsfähig, für Bastler ohne Zubehör	http://cgi.ebay.de/Amiga-1200-Funktionsfaehig-fuer-Bastler-ohne-Zubehoer_W0QQitemZ160398122589QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1603981225898080_1.jpg	160398122589	good	bare	37.16	2010-01-31 18:50:05	2010-01-27 12:54:46.270101	2010-02-01 11:54:18.938975	1603981225898080_1.jpg	image/jpg	1142	2010-01-27 12:54:46.147963
518	5	DE	EUR	Apple computer Apple IIe Apple 2 Rechner	http://cgi.ebay.de/Apple-computer-Apple-IIe-Apple-2-Rechner_W0QQitemZ120522602496QQcategoryZ3736QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1205226024968080_1.jpg	120522602496	good	bare	46.66	2010-02-01 12:58:33	2010-01-27 12:53:02.761689	2010-02-02 00:17:03.825283	1205226024968080_1.jpg	image/jpg	871	2010-01-27 12:53:02.643414
526	4	DE	EUR	Commodore VC20 VC 20 in Originalverpackung OVP	http://cgi.ebay.de/Commodore-VC20-VC-20-in-Originalverpackung-OVP_W0QQitemZ200431946497QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004319464978080_1.jpg	200431946497	good	boxed	\N	2010-02-03 16:48:36	2010-01-27 13:07:07.495871	2010-01-27 13:07:07.495871	2004319464978080_1.jpg	image/jpg	1603	2010-01-27 13:07:07.393382
523	24	DE	EUR	Commodore 128D / C64 Metallgeh. geprüft, Originalumfang	http://cgi.ebay.de/Commodore-128D-C64-Metallgeh-geprueft-Originalumfang_W0QQitemZ150406092322QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1504060923228080_1.jpg	150406092322	good	complete	89.88	2010-01-27 18:19:45	2010-01-27 13:04:12.096169	2010-01-28 10:54:57.46943	1504060923228080_1.jpg	image/jpg	980	2010-01-27 13:04:11.821476
544	54	DE	EUR	Macintosh SE / 30, Netwerkkarte, ext. SCSI Festplatte	http://cgi.ebay.de/Macintosh-SE-30-Netwerkkarte-ext-SCSI-Festplatte_W0QQitemZ300388920372QQcategoryZ162507QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3003889203728080_1.jpg	300388920372	average	complete	152.00	2010-01-30 15:51:40	2010-01-28 21:51:04.691035	2010-01-31 02:10:42.347711	3003889203728080_1.jpg	image/jpg	928	2010-01-28 21:51:04.580417
525	21	DE	EUR	Commodore Floppy Disk VC 1541-II	http://cgi.ebay.de/Commodore-Floppy-Disk-VC-1541-II_W0QQitemZ200431187060QQcategoryZ3543QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2004311870608080_1.jpg	200431187060	good	boxed	5.51	2010-01-30 15:02:00	2010-01-27 13:06:49.851309	2010-01-31 02:10:42.792436	2004311870608080_1.jpg	image/jpg	897	2010-01-27 13:06:49.730885
531	53	CA	CAD	Apple Macintosh SE M5011 All-in-One Desktop PC VINTAGE!	http://cgi.ebay.ca/Apple-Macintosh-SE-M5011-All-in-One-Desktop-PC-VINTAGE_W0QQitemZ200432628889QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004326288898080_1.jpg	200432628889	poor	complete	\N	2010-02-02 15:36:14	2010-01-28 21:41:01.289	2010-01-28 21:41:01.289	2004326288898080_1.jpg	image/jpg	986	2010-01-28 21:41:01.197581
532	54	CA	CAD	Apple Macintosh SE/30 All-in-One Desktop M5119 VINTAGE!	http://cgi.ebay.ca/Apple-Macintosh-SE-30-All-in-One-Desktop-M5119-VINTAGE_W0QQitemZ310196917703QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3101969177038080_1.jpg	310196917703	poor	complete	\N	2010-02-02 15:36:15	2010-01-28 21:42:08.623724	2010-01-28 21:42:08.623724	3101969177038080_1.jpg	image/jpg	986	2010-01-28 21:42:08.516618
533	53	CA	CAD	Vintage Mac Macintosh SE M5011	http://cgi.ebay.ca/Vintage-Mac-Macintosh-SE-M5011_W0QQitemZ270520514226QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705205142268080_2.jpg	270520514226	average	complete with extras	\N	2010-02-03 19:06:43	2010-01-28 21:42:43.40012	2010-01-28 21:42:43.40012	2705205142268080_2.jpg	image/jpg	1015	2010-01-28 21:42:43.29371
534	53	CA	CAD	Apple Macintosh Mac SE Computer M5011	http://cgi.ebay.ca/Apple-Macintosh-Mac-SE-Computer-M5011_W0QQitemZ200274689172QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2002746891728080_15.jpg	200274689172	average	complete	\N	2010-02-05 02:54:20	2010-01-28 21:46:27.054454	2010-01-28 21:46:27.054454	2002746891728080_15.jpg	image/jpg	1363	2010-01-28 21:46:26.947216
535	53	CA	CAD	Apple M5011 Macintosh SE Desktop Computer	http://cgi.ebay.ca/Apple-M5011-Macintosh-SE-Desktop-Computer_W0QQitemZ200256095292QQcategoryZ179QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2002560952928080_17.jpg	200256095292	average	complete	\N	2010-02-12 07:05:14	2010-01-28 21:47:12.027852	2010-01-28 21:47:12.027852	2002560952928080_17.jpg	image/jpg	999	2010-01-28 21:47:11.922814
536	52	CA	CAD	Apple M5010 Macintosh SE Desktop Computer	http://cgi.ebay.ca/Apple-M5010-Macintosh-SE-Desktop-Computer_W0QQitemZ200256095295QQcategoryZ179QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2002560952958080_17.jpg	200256095295	poor	complete	\N	2010-02-12 07:05:16	2010-01-28 21:47:34.081119	2010-01-28 21:47:34.081119	2002560952958080_17.jpg	image/jpg	826	2010-01-28 21:47:33.974282
537	52	CA	CAD	Macintosh SE Computer M5010 Dual Disk 1MB Ram Kb Mouse	http://cgi.ebay.ca/Macintosh-SE-Computer-M5010-Dual-Disk-1MB-Ram-Kb-Mouse_W0QQitemZ190350767441QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1903507674418080_6.jpg	190350767441	average	complete	\N	2010-02-17 00:13:38	2010-01-28 21:47:58.866285	2010-01-28 21:47:58.866285	1903507674418080_6.jpg	image/jpg	1281	2010-01-28 21:47:58.748001
538	54	CA	CAD	Vintage Apple Macintosh Mac SE/30 - Collector's Item!	http://cgi.ebay.ca/Vintage-Apple-Macintosh-Mac-SE-30-Collectors-Item_W0QQitemZ330388943843QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3303889438438080_2.jpg	330388943843	poor	complete	\N	2010-02-19 17:52:55	2010-01-28 21:48:35.489116	2010-01-28 21:48:35.489116	3303889438438080_2.jpg	image/jpg	851	2010-01-28 21:48:35.376474
539	53	CA	CAD	Vintage Apple Macintosh SE M5011 Compact Mac Computer	http://cgi.ebay.ca/Vintage-Apple-Macintosh-SE-M5011-Compact-Mac-Computer_W0QQitemZ190359920981QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1903599209818080_2.jpg	190359920981	average	complete	\N	2010-02-20 03:54:22	2010-01-28 21:48:58.097265	2010-01-28 21:48:58.097265	1903599209818080_2.jpg	image/jpg	1362	2010-01-28 21:48:57.994217
540	53	CA	CAD	Apple Macintosh SE M5011 All-in-1 Desktop PC VINTAGE!	http://cgi.ebay.ca/Apple-Macintosh-SE-M5011-All-in-1-Desktop-PC-VINTAGE_W0QQitemZ380200893650QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3802008936508080_1.jpg	380200893650	average	complete	\N	2010-02-24 18:53:54	2010-01-28 21:49:31.186169	2010-01-28 21:49:31.186169	3802008936508080_1.jpg	image/jpg	995	2010-01-28 21:49:31.083204
541	53	CA	CAD	Apple Macintosh SE M5011 All-in-1 Desktop PC VINTAGE!	http://cgi.ebay.ca/Apple-Macintosh-SE-M5011-All-in-1-Desktop-PC-VINTAGE_W0QQitemZ200432681424QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2004326814248080_1.jpg	200432681424	average	complete	\N	2010-02-25 18:17:30	2010-01-28 21:49:53.560142	2010-01-28 21:49:53.560142	2004326814248080_1.jpg	image/jpg	919	2010-01-28 21:49:53.452328
542	53	CA	CAD	Apple Macintosh SE M5011 All-in-1 Desktop PC VINTAGE R1	http://cgi.ebay.ca/Apple-Macintosh-SE-M5011-All-in-1-Desktop-PC-VINTAGE-R1_W0QQitemZ380201529013QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3802015290138080_1.jpg	380201529013	average	complete	\N	2010-02-26 20:33:33	2010-01-28 21:50:09.117272	2010-01-28 21:50:09.117272	3802015290138080_1.jpg	image/jpg	938	2010-01-28 21:50:09.023568
543	53	CA	CAD	Apple Macintosh SE PC w/ Keyboard M5011 Parts or Repair	http://cgi.ebay.ca/Apple-Macintosh-SE-PC-w-Keyboard-M5011-Parts-or-Repair_W0QQitemZ300352442741QQcategoryZ111418QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3003524427418080_5.jpg	300352442741	poor	complete	\N	2010-02-26 21:24:48	2010-01-28 21:50:32.338922	2010-01-28 21:50:32.338922	3003524427418080_5.jpg	image/jpg	902	2010-01-28 21:50:32.214797
527	35	DE	EUR	Commodore VC-1541 Floppy (Ur-Version)	http://cgi.ebay.de/Commodore-VC-1541-Floppy-Ur-Version_W0QQitemZ230428688536QQcategoryZ3543QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304286885368080_1.jpg	230428688536	good	complete	23.10	2010-01-31 19:37:53	2010-01-27 13:07:17.481111	2010-02-01 11:53:56.339684	2304286885368080_1.jpg	image/jpg	1206	2010-01-27 13:07:17.360658
545	52	DE	EUR	Macintosh SE Würfelmac komplett und in Ordnung!!    RAR	http://cgi.ebay.de/Macintosh-SE-Wuerfelmac-komplett-und-in-Ordnung-RAR_W0QQitemZ230428135112QQcategoryZ162507QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304281351128080_1.jpg	230428135112	average	bare	\N	2010-02-02 13:46:50	2010-01-28 21:51:49.855194	2010-01-28 21:51:49.855194	2304281351128080_1.jpg	image/jpg	870	2010-01-28 21:51:49.754622
546	54	DE	EUR	APPLE MACINTOSH SE/30 MODEL No. 5119 KULT MAC RARITÄT !	http://cgi.ebay.de/APPLE-MACINTOSH-SE-30-MODEL-No-5119-KULT-MAC-RARITAT_W0QQitemZ380201046422QQcategoryZ162507QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3802010464228080_1.jpg	380201046422	poor	complete	\N	2010-02-07 18:33:42	2010-01-28 21:53:53.471718	2010-01-28 21:53:53.471718	3802010464228080_1.jpg	image/jpg	1273	2010-01-28 21:53:53.338708
548	54	UK	USD	Vintage Macintosh Mac SE SE/30 Computer for Parts	http://cgi.ebay.com/Vintage-Macintosh-Mac-SE-SE-30-Computer-for-Parts_W0QQitemZ390144407383QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3901444073838080_1.jpg	390144407383	poor	complete	\N	2010-02-16 06:05:06	2010-01-28 21:55:55.777897	2010-01-28 21:55:55.777897	3901444073838080_1.jpg	image/jpg	1046	2010-01-28 21:55:55.668441
550	52	UK	USD	Vintage Apple Macintosh SE 1MB Ram 2 800K Drives/ PARTS	http://cgi.ebay.com/Vintage-Apple-Macintosh-SE-1MB-Ram-2-800K-Drives-PARTS_W0QQitemZ390144051869QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3901440518698080_1.jpg	390144051869	average	complete	\N	2010-02-15 06:26:53	2010-01-28 21:57:15.310927	2010-01-28 21:57:15.310927	3901440518698080_1.jpg	image/jpg	843	2010-01-28 21:57:15.206899
551	52	UK	USD	Vintage Apple Macintosh SE 1MB Ram 2 800K Drives/ PARTS	http://cgi.ebay.com/Vintage-Apple-Macintosh-SE-1MB-Ram-2-800K-Drives-PARTS_W0QQitemZ390144051857QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3901440518578080_1.jpg	390144051857	average	complete	\N	2010-02-15 06:26:43	2010-01-28 21:57:28.363257	2010-01-28 21:57:28.363257	3901440518578080_1.jpg	image/jpg	1055	2010-01-28 21:57:28.259777
553	53	UK	USD	Macintosh SE 5011 4MB 20MB System 7.0 Carrying Bag Exc	http://cgi.ebay.com/Macintosh-SE-5011-4MB-20MB-System-7-0-Carrying-Bag-Exc_W0QQitemZ150408978736QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1504089787368080_1.jpg	150408978736	average	complete with extras	\N	2010-02-03 01:41:36	2010-01-28 21:58:38.447142	2010-01-28 21:58:38.447142	1504089787368080_1.jpg	image/jpg	1692	2010-01-28 21:58:38.340322
554	53	UK	USD	Macintosh SE SuperDrive	http://cgi.ebay.com/Macintosh-SE-SuperDrive_W0QQitemZ140378235068QQcategoryZ80075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1403782350688080_1.jpg	140378235068	average	complete	\N	2010-02-01 19:15:24	2010-01-28 21:59:03.099979	2010-01-28 21:59:03.099979	1403782350688080_1.jpg	image/jpg	911	2010-01-28 21:59:03.009794
555	53	UK	USD	Macintosh SE (Mac) with Dual Floppy Drives System	http://cgi.ebay.com/Macintosh-SE-Mac-with-Dual-Floppy-Drives-System_W0QQitemZ260543609737QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605436097378080_1.jpg	260543609737	good	complete	\N	2010-02-01 23:10:44	2010-01-28 22:00:09.483785	2010-01-28 22:00:09.483785	2605436097378080_1.jpg	image/jpg	1229	2010-01-28 22:00:09.378489
529	52	CA	CAD	Apple Mac Macintosh SE - FULLY FUNCTIONAL	http://cgi.ebay.ca/Apple-Mac-Macintosh-SE-FULLY-FUNCTIONAL_W0QQitemZ320478290847QQcategoryZ111418QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3204782908478080_1.jpg	320478290847	average	complete with extras	63.69	2010-01-29 07:39:32	2010-01-28 21:35:18.883173	2010-01-29 12:33:50.893444	3204782908478080_1.jpg	image/jpg	1265	2010-01-28 21:35:18.763707
513	9	US	USD	Apple IIc in very nice shape, with AC adaptor & MANUEL	http://cgi.ebay.com/Apple-IIc-in-very-nice-shape-with-AC-adaptor-MANUEL_W0QQitemZ330398985166QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3303989851668080_1.jpg	330398985166	good	complete	32.50	2010-01-31 01:53:06	2010-01-27 12:47:56.358092	2010-01-31 02:10:11.402292	3303989851668080_1.jpg	image/jpg	1119	2010-01-27 12:47:56.257453
556	11	US	USD	 Commodore CBM Model 8032 PET Vintage Computer & Guide	http://cgi.ebay.com/Commodore-CBM-Model-8032-PET-Vintage-Computer-Guide_W0QQitemZ250569833215QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2505698332158080_1.jpg	250569833215	good	bare	\N	2010-02-02 01:37:13	2010-01-31 12:50:48.390992	2010-01-31 12:50:48.390992	2505698332158080_1.jpg	image/jpg	1080	2010-01-31 12:50:48.276992
559	56	DE	EUR	Commodore CBM 8296-D BASIC computer IEEE-488 2x Floppy	http://cgi.ebay.de/Commodore-CBM-8296-D-BASIC-computer-IEEE-488-2x-Floppy_W0QQitemZ320481432744QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204814327448080_1.jpg	320481432744	average	complete	\N	2010-02-08 20:20:37	2010-01-31 12:57:16.090682	2010-01-31 12:57:16.090682	3204814327448080_1.jpg	image/jpg	1255	2010-01-31 12:57:15.972779
561	4	IT	EUR	COMMODORE VIC 20 I° SERIE VIC20 DA TESTARE no 64 c6 i9	http://cgi.ebay.it/COMMODORE-VIC-20-I-SERIE-VIC20-DA-TESTARE-no-64-c6-i9_W0QQitemZ220546822964QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2205468229648080_1.jpg	220546822964	good	boxed with extras	\N	2010-02-02 17:25:03	2010-01-31 12:59:58.666174	2010-01-31 12:59:58.666174	2205468229648080_1.jpg	image/jpg	1398	2010-01-31 12:59:58.555797
562	4	IT	EUR	N.2 COMMODORE VIC-20  (VIC 20 + VC-20) + ALIMENTATORE	http://cgi.ebay.it/N-2-COMMODORE-VIC-20-VIC-20-VC-20-ALIMENTATORE_W0QQitemZ180463284686QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1804632846868080_1.jpg	180463284686	average	complete	\N	2010-02-06 15:05:21	2010-01-31 13:00:16.377847	2010-01-31 13:00:16.377847	1804632846868080_1.jpg	image/jpg	1138	2010-01-31 13:00:16.253534
563	7	IT	EUR	RARISSIMO COMMODORE 128+CARICATORE CASSETTE IN BOX 	http://cgi.ebay.it/RARISSIMO-COMMODORE-128-CARICATORE-CASSETTE-IN-BOX_W0QQitemZ260545723045QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605457230458080_1.jpg	260545723045	good	boxed	\N	2010-02-06 15:45:20	2010-01-31 13:00:47.819691	2010-01-31 13:00:47.819691	2605457230458080_1.jpg	image/jpg	1004	2010-01-31 13:00:47.705292
558	56	DE	EUR	Commodore CBM 8032 SK  Computer, Sammler, Antik	http://cgi.ebay.de/Commodore-CBM-8032-SK-Computer-Sammler-Antik_W0QQitemZ280457679594QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2804576795948080_1.jpg	280457679594	poor	bare	10.59	2010-01-31 20:10:31	2010-01-31 12:55:09.911403	2010-02-01 11:52:54.618833	2804576795948080_1.jpg	image/jpg	1217	2010-01-31 12:55:09.794316
557	13	DE	EUR	Commodore CBM Model 3032 Computer, Sammler, Antik	http://cgi.ebay.de/Commodore-CBM-Model-3032-Computer-Sammler-Antik_W0QQitemZ280457679154QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2804576791548080_1.jpg	280457679154	poor	bare	22.05	2010-01-31 20:05:46	2010-01-31 12:53:08.719266	2010-02-01 11:52:57.351053	2804576791548080_1.jpg	image/jpg	1251	2010-01-31 12:53:08.606334
560	4	IT	EUR	CONSOLLE COMMODORE VIC 20 INTROVABILE	http://cgi.ebay.it/CONSOLLE-COMMODORE-VIC-20-INTROVABILE_W0QQitemZ230427372976QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304273729768080_1.jpg	230427372976	average	complete with extras	19.99	2010-01-31 16:41:43	2010-01-31 12:59:36.950776	2010-02-01 11:55:47.67052	2304273729768080_1.jpg	image/jpg	1299	2010-01-31 12:59:36.835599
549	53	UK	USD	Vintage Macintosh Mac SE M5011	http://cgi.ebay.com/Vintage-Macintosh-Mac-SE-M5011_W0QQitemZ120522213758QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1205222137588080_1.jpg	120522213758	average	complete	5.50	2010-01-31 15:46:22	2010-01-28 21:56:38.389012	2010-02-01 11:55:54.269316	1205222137588080_1.jpg	image/jpg	885	2010-01-28 21:56:38.279219
552	52	UK	USD	Apple Macintosh SE Computer Vintage MAC Model #M5010	http://cgi.ebay.com/Apple-Macintosh-SE-Computer-Vintage-MAC-Model-M5010_W0QQitemZ190368201402QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1903682014028080_1.jpg	190368201402	average	complete	5.50	2010-02-01 16:45:28	2010-01-28 21:58:00.710073	2010-02-02 00:17:09.771475	1903682014028080_1.jpg	image/jpg	1119	2010-01-28 21:58:00.592071
564	6	IT	EUR	COMMODORE 16 TASTIERA KEYBOARD NEW PERFETTE CONDIZIONI	http://cgi.ebay.it/COMMODORE-16-TASTIERA-KEYBOARD-NEW-PERFETTE-CONDIZIONI_W0QQitemZ320480529674QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204805296748080_1.jpg	320480529674	good	bare	\N	2010-02-06 17:12:05	2010-01-31 13:01:36.629255	2010-01-31 13:01:36.629255	3204805296748080_1.jpg	image/jpg	876	2010-01-31 13:01:36.517843
565	29	IT	EUR	Commodore 64 p c + imballo + joy stick	http://cgi.ebay.it/Commodore-64-p-c-imballo-joy-stick_W0QQitemZ320477918550QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204779185508080_1.jpg	320477918550	good	boxed	\N	2010-01-31 13:13:16	2010-01-31 13:02:08.199308	2010-01-31 13:02:08.199308	3204779185508080_1.jpg	image/jpg	969	2010-01-31 13:02:08.081129
566	32	IT	EUR	Commodore SX64 64SX SX 64 64 SX Ottimo, Manuale, Dischi	http://cgi.ebay.it/Commodore-SX64-64SX-SX-64-64-SX-Ottimo-Manuale-Dischi_W0QQitemZ300389915946QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3003899159468080_1.jpg	300389915946	good	complete	\N	2010-02-02 18:37:16	2010-01-31 13:02:34.491655	2010-01-31 13:02:34.491655	3003899159468080_1.jpg	image/jpg	1426	2010-01-31 13:02:34.392718
567	3	IT	EUR	COMMODORE 64 + JOYSTICK + 2 LETTORI + ALIMENTATORE '80	http://cgi.ebay.it/COMMODORE-64-JOYSTICK-2-LETTORI-ALIMENTATORE-80_W0QQitemZ200432242559QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2004322425598080_1.jpg	200432242559	good	complete with extras	\N	2010-02-02 20:03:08	2010-01-31 13:02:48.321008	2010-01-31 13:02:48.321008	2004322425598080_1.jpg	image/jpg	1138	2010-01-31 13:02:48.194214
568	3	IT	EUR	COMMODORE 64 biscottone + Datassette originale, ottimo 	http://cgi.ebay.it/COMMODORE-64-biscottone-Datassette-originale-ottimo_W0QQitemZ300391553008QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3003915530088080_1.jpg	300391553008	good	complete with extras	\N	2010-02-04 20:32:17	2010-01-31 13:03:17.972396	2010-01-31 13:03:17.972396	3003915530088080_1.jpg	image/jpg	1507	2010-01-31 13:03:17.853238
569	29	IT	EUR	Commodore 64 II + DATASETTE / REGISTRATORE il migliore 	http://cgi.ebay.it/Commodore-64-II-DATASETTE-REGISTRATORE-il-migliore_W0QQitemZ330399200503QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3303992005038080_1.jpg	330399200503	good	complete with extras	\N	2010-02-05 20:08:14	2010-01-31 13:03:33.212218	2010-01-31 13:03:33.212218	3303992005038080_1.jpg	image/jpg	1409	2010-01-31 13:03:33.085912
572	23	IT	EUR	COMMODORE AMIGA model 500 funzionante	http://cgi.ebay.it/COMMODORE-AMIGA-model-500-funzionante_W0QQitemZ280457014387QQcategoryZ4598QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2804570143878080_1.jpg	280457014387	good	complete	\N	2010-02-02 18:40:31	2010-01-31 13:06:56.731769	2010-01-31 13:06:56.731769	2804570143878080_1.jpg	image/jpg	1121	2010-01-31 13:06:56.612387
573	36	IT	EUR	2 AMIGA 1200 A1200 + LOTTO 150 FLOPPY + 2 CONTENITORI	http://cgi.ebay.it/2-AMIGA-1200-A1200-LOTTO-150-FLOPPY-2-CONTENITORI_W0QQitemZ180460280970QQcategoryZ4598QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1804602809708080_1.jpg	180460280970	good	complete with extras	\N	2010-02-02 19:34:03	2010-01-31 13:07:09.200945	2010-01-31 13:07:09.200945	1804602809708080_1.jpg	image/jpg	1243	2010-01-31 13:07:09.093464
574	8	IT	EUR	computer zx spectrum sinclair 48 kram con imballo 	http://cgi.ebay.it/computer-zx-spectrum-sinclair-48-kram-con-imballo_W0QQitemZ330398760285QQcategoryZ126968QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3303987602858080_1.jpg	330398760285	good	boxed	\N	2010-02-04 11:02:22	2010-01-31 13:10:04.85872	2010-01-31 13:10:04.85872	3303987602858080_1.jpg	image/jpg	1121	2010-01-31 13:10:04.743365
577	8	IT	EUR	SINCLAIR ZX SPECTRUM 16K NUOVO+ACCESSORI @GUARDA@	http://cgi.ebay.it/SINCLAIR-ZX-SPECTRUM-16K-NUOVO-ACCESSORI-GUARDA_W0QQitemZ290397012594QQcategoryZ126968QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2903970125948080_1.jpg	290397012594	good	complete with extras	\N	2010-02-05 21:17:35	2010-01-31 13:12:20.885056	2010-01-31 13:12:20.885056	2903970125948080_1.jpg	image/jpg	1225	2010-01-31 13:12:20.771787
578	20	IT	EUR	Commodore 1541 prima versione Raro	http://cgi.ebay.it/Commodore-1541-prima-versione-Raro_W0QQitemZ330399205530QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3303992055308080_1.jpg	330399205530	good	bare	\N	2010-02-05 20:23:13	2010-01-31 13:13:16.893035	2010-01-31 13:13:16.893035	3303992055308080_1.jpg	image/jpg	1112	2010-01-31 13:13:16.780058
580	39	DE	EUR	sinclair ZX81 Personal Computer 1980	http://cgi.ebay.de/sinclair-ZX81-Personal-Computer-1980_W0QQitemZ230431341020QQcategoryZ8099QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304313410208080_1.jpg	230431341020	good	complete	\N	2010-02-10 10:19:01	2010-01-31 13:16:12.623818	2010-01-31 13:16:12.623818	2304313410208080_1.jpg	image/jpg	1365	2010-01-31 13:16:12.510077
581	39	DE	EUR	Sinclair ZX81 Computer 	http://cgi.ebay.de/Sinclair-ZX81-Computer_W0QQitemZ260545796379QQcategoryZ8099QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2605457963798080_1.jpg	260545796379	good	complete	\N	2010-02-09 18:34:14	2010-01-31 13:16:23.870609	2010-01-31 13:16:23.870609	2605457963798080_1.jpg	image/jpg	1370	2010-01-31 13:16:23.757432
583	58	DE	EUR	**  Sinclair ZX Microdrive  **  FÜR SPECTRUM	http://cgi.ebay.de/Sinclair-ZX-Microdrive-FUR-SPECTRUM_W0QQitemZ290397370530QQcategoryZ8099QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2903973705308080_1.jpg	290397370530	good	bare	\N	2010-03-01 23:24:54	2010-01-31 13:21:00.917008	2010-01-31 13:21:00.917008	2903973705308080_1.jpg	image/jpg	953	2010-01-31 13:21:00.797118
585	61	DE	EUR	Sharp MZ-700  mit Quickdisc MZ-1F11	http://cgi.ebay.de/Sharp-MZ-700-mit-Quickdisc-MZ-1F11_W0QQitemZ200433350745QQcategoryZ8101QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004333507458080_1.jpg	200433350745	good	complete	\N	2010-02-07 16:46:21	2010-01-31 14:45:02.747072	2010-01-31 14:45:02.747072	2004333507458080_1.jpg	image/jpg	1714	2010-01-31 14:45:02.637326
579	22	DE	EUR	Commodore Floppy 1581 f. c16 c116 plus4 c64 128 	http://cgi.ebay.de/Commodore-Floppy-1581-f-c16-c116-plus4-c64-128_W0QQitemZ120523915968QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1205239159688080_1.jpg	120523915968	good	boxed	163.00	2010-01-31 18:59:53	2010-01-31 13:14:35.862324	2010-02-01 11:54:16.737872	1205239159688080_1.jpg	image/jpg	1279	2010-01-31 13:14:35.753827
575	10	IT	EUR	SINCLAIR ZX SPECTRUM+ FUNZIONANTE	http://cgi.ebay.it/SINCLAIR-ZX-SPECTRUM-FUNZIONANTE_W0QQitemZ270520447160QQcategoryZ126968QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2705204471608080_1.jpg	270520447160	good	complete	24.00	2010-01-31 17:25:00	2010-01-31 13:11:15.530143	2010-02-01 11:55:29.403139	2705204471608080_1.jpg	image/jpg	1333	2010-01-31 13:11:15.399147
571	23	IT	EUR	AMIGA 500-COMMODORE-SENZA ACESSORI COSI COME SI VEDE-	http://cgi.ebay.it/AMIGA-500-COMMODORE-SENZA-ACESSORI-COSI-COME-SI-VEDE_W0QQitemZ320480114535QQcategoryZ4598QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3204801145358080_1.jpg	320480114535	good	bare	9.99	2010-01-31 17:01:26	2010-01-31 13:04:28.51696	2010-02-01 11:55:43.912012	3204801145358080_1.jpg	image/jpg	783	2010-01-31 13:04:28.409243
576	8	IT	EUR	SINCLAIR ZX SPECTRUM + SCATOLA + PHILIPS -Negozio-	http://cgi.ebay.it/SINCLAIR-ZX-SPECTRUM-SCATOLA-PHILIPS-Negozio_W0QQitemZ320479760747QQcategoryZ126968QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3204797607478080_1.jpg	320479760747	good	complete	21.00	2010-02-01 19:04:38	2010-01-31 13:11:32.846391	2010-02-02 00:18:19.904542	3204797607478080_1.jpg	image/jpg	1249	2010-01-31 13:11:32.737453
570	23	IT	EUR	COMMODORE AMIGA 500 + GIOCHI VARI + STAMPANTE + MANUALI	http://cgi.ebay.it/COMMODORE-AMIGA-500-GIOCHI-VARI-STAMPANTE-MANUALI_W0QQitemZ330397656301QQcategoryZ4598QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3303976563018080_2.jpg	330397656301	good	complete with extras	30.50	2010-01-31 15:35:15	2010-01-31 13:04:11.799819	2010-02-01 11:58:55.490319	3303976563018080_2.jpg	image/jpg	1166	2010-01-31 13:04:11.67234
586	19	DE	EUR	Apple MACintosh 512K	http://cgi.ebay.de/Apple-MACintosh-512K_W0QQitemZ190369584230QQcategoryZ8101QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1903695842308080_1.jpg	190369584230	good	complete with extras	\N	2010-02-07 13:53:34	2010-01-31 23:30:06.771905	2010-01-31 23:30:06.771905	1903695842308080_1.jpg	image/jpg	1213	2010-01-31 23:30:06.664602
588	18	US	USD	Original Macintosh 128k all-in-one	http://cgi.ebay.com/Original-Macintosh-128k-all-in-one_W0QQitemZ220547053317QQcategoryZ80075QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2205470533178080_1.jpg	220547053317	good	complete with extras	\N	2010-02-03 01:34:09	2010-01-31 23:31:27.387501	2010-01-31 23:31:27.387501	2205470533178080_1.jpg	image/jpg	1009	2010-01-31 23:31:27.2715
587	18	US	USD	Original  1984 128k Apple Macintosh	http://cgi.ebay.com/Original-1984-128k-Apple-Macintosh_W0QQitemZ150409010383QQcategoryZ80075QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1504090103838080_1.jpg	150409010383	good	complete	122.50	2010-02-01 04:57:40	2010-01-31 23:31:14.326788	2010-02-01 11:52:02.934351	1504090103838080_1.jpg	image/jpg	1062	2010-01-31 23:31:14.196499
584	58	DE	EUR	ZX Spectrum Microdrive	http://cgi.ebay.de/ZX-Spectrum-Microdrive_W0QQitemZ120521199414QQcategoryZ8099QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1205211994148080_1.jpg	120521199414	good	complete	20.50	2010-01-31 21:53:53	2010-01-31 13:21:17.725798	2010-02-01 11:52:30.096571	1205211994148080_1.jpg	image/jpg	863	2010-01-31 13:21:17.622444
547	53	IT	EUR	Macintosh SE	http://cgi.ebay.it/Macintosh-SE_W0QQitemZ190367254142QQcategoryZ51046QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1903672541428080_2.jpg	190367254142	average	complete	40.50	2010-01-31 21:30:21	2010-01-28 21:55:07.682873	2010-02-01 11:52:30.406459	1903672541428080_2.jpg	image/jpg	1047	2010-01-28 21:55:07.569525
582	8	DE	EUR	Sinclair ZX Spectrum 16 K	http://cgi.ebay.de/Sinclair-ZX-Spectrum-16-K_W0QQitemZ170436944682QQcategoryZ3736QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704369446828080_1.jpg	170436944682	average	bare	29.08	2010-01-31 19:58:46	2010-01-31 13:16:51.731941	2010-02-01 11:53:54.332603	1704369446828080_1.jpg	image/jpg	1280	2010-01-31 13:16:51.61312
590	53	ES	EUR	Macintosh SE FDHD -  ColorVue SE Display Card ! LOOK	http://cgi.ebay.es/Macintosh-SE-FDHD-ColorVue-SE-Display-Card-LOOK_W0QQitemZ260546304549QQcategoryZ171QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605463045498080_1.jpg	260546304549	average	complete with extras	\N	2010-02-07 19:36:53	2010-02-01 18:57:01.512572	2010-02-01 18:57:01.512572	2605463045498080_1.jpg	image/jpg	1646	2010-02-01 18:57:01.375838
591	54	FR	EUR	Ordinateur Macintosh SE 30 COLLECTOR 1990 Fonctionne !	http://cgi.ebay.fr/Ordinateur-Macintosh-SE-30-COLLECTOR-1990-Fonctionne_W0QQitemZ120524997339QQcategoryZ69557QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1205249973398080_1.jpg	120524997339	good	complete	\N	2010-02-07 15:05:46	2010-02-01 18:58:03.493182	2010-02-01 18:58:03.493182	1205249973398080_1.jpg	image/jpg	963	2010-02-01 18:58:03.358612
592	54	FR	EUR	APPLE MACINTOSH FD HD + SACOCHE DE TRANSPORT ... RARE 	http://cgi.ebay.fr/APPLE-MACINTOSH-FD-HD-SACOCHE-DE-TRANSPORT-RARE_W0QQitemZ190369383041QQcategoryZ51046QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1903693830418080_1.jpg	190369383041	good	complete with extras	\N	2010-02-06 16:46:02	2010-02-01 18:58:37.560984	2010-02-01 18:58:37.560984	1903693830418080_1.jpg	image/jpg	941	2010-02-01 18:58:37.438365
593	3	AU	AUD	Commodore 64 computer C64 disk drive joysticks power	http://cgi.ebay.com.au/Commodore-64-computer-C64-disk-drive-joysticks-power_W0QQitemZ120521630447QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1205216304478080_1.jpg	120521630447	average	complete with extras	\N	2010-02-02 00:22:43	2010-02-01 21:00:38.638502	2010-02-01 21:00:38.638502	1205216304478080_1.jpg	image/jpg	1199	2010-02-01 21:00:38.512478
594	3	AU	AUD	Commodore 64 Computer with Tape Deck, Games, Joystick	http://cgi.ebay.com.au/Commodore-64-Computer-with-Tape-Deck-Games-Joystick_W0QQitemZ160398538867QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1603985388678080_1.jpg	160398538867	poor	complete with extras	\N	2010-02-02 00:53:46	2010-02-01 21:01:10.566425	2010-02-01 21:01:10.566425	1603985388678080_1.jpg	image/jpg	1624	2010-02-01 21:01:10.449761
595	3	AU	AUD	Vintage Commodore 64 + Games - Setup	http://cgi.ebay.com.au/Vintage-Commodore-64-Games-Setup_W0QQitemZ170438076327QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1704380763278080_1.jpg	170438076327	poor	complete with extras	\N	2010-02-03 10:09:27	2010-02-01 21:02:12.10678	2010-02-01 21:02:12.10678	1704380763278080_1.jpg	image/jpg	1275	2010-02-01 21:02:11.9998
596	29	AU	AUD	commodore 64 plus games and accessories	http://cgi.ebay.com.au/commodore-64-plus-games-and-accessories_W0QQitemZ190368092873QQcategoryZ162QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1903680928738080_1.jpg	190368092873	average	complete with extras	\N	2010-02-04 03:19:13	2010-02-01 21:02:29.148775	2010-02-01 21:02:29.148775	1903680928738080_1.jpg	image/jpg	1447	2010-02-01 21:02:29.033916
597	3	AU	AUD	Commodore 64 with 1541FDD, joystick, game cartridge	http://cgi.ebay.com.au/Commodore-64-with-1541FDD-joystick-game-cartridge_W0QQitemZ190368830730QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1903688307308080_1.jpg	190368830730	average	complete with extras	\N	2010-02-04 06:44:05	2010-02-01 21:02:45.157693	2010-02-01 21:02:45.157693	1903688307308080_1.jpg	image/jpg	888	2010-02-01 21:02:45.051149
598	21	AU	AUD	Commodore 1541-II External Floppy Drive	http://cgi.ebay.com.au/Commodore-1541-II-External-Floppy-Drive_W0QQitemZ110485927774QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1104859277748080_1.jpg	110485927774	average	complete	\N	2010-02-04 08:40:36	2010-02-01 21:03:14.197632	2010-02-01 21:03:14.197632	1104859277748080_1.jpg	image/jpg	844	2010-02-01 21:03:14.086273
599	6	AU	AUD	Commodore 16	http://cgi.ebay.com.au/Commodore-16_W0QQitemZ320410517585QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3204105175858080_1.jpg	320410517585	poor	bare	\N	2010-02-06 00:11:08	2010-02-01 21:03:40.774062	2010-02-01 21:03:40.774062	3204105175858080_1.jpg	image/jpg	1068	2010-02-01 21:03:40.656535
600	59	AU	AUD	Commodore 16 data tape player, also used on plus 4 & 64	http://cgi.ebay.com.au/Commodore-16-data-tape-player-also-used-on-plus-4-64_W0QQitemZ320410519866QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204105198668080_1.jpg	320410519866	average	complete	\N	2010-02-06 00:21:46	2010-02-01 21:04:27.21438	2010-02-01 21:04:27.21438	3204105198668080_1.jpg	image/jpg	1378	2010-02-01 21:04:27.104911
601	3	AU	AUD	COMMODORE 64 COMPUTER COMPLETE + APPROX 1000 GAMES 	http://cgi.ebay.com.au/COMMODORE-64-COMPUTER-COMPLETE-APPROX-1000-GAMES_W0QQitemZ110486756868QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1104867568688080_1.jpg	110486756868	average	complete with extras	\N	2010-02-06 08:33:36	2010-02-01 21:04:54.897615	2010-02-01 21:04:54.897615	1104867568688080_1.jpg	image/jpg	1138	2010-02-01 21:04:54.788797
602	29	AU	AUD	COMMODORE 64 Computer +Disk Drive, 33 Games inc PAC-MAN	http://cgi.ebay.com.au/COMMODORE-64-Computer-Disk-Drive-33-Games-inc-PAC-MAN_W0QQitemZ150409844822QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1504098448228080_1.jpg	150409844822	average	complete with extras	\N	2010-02-06 09:27:54	2010-02-01 21:05:37.828443	2010-02-01 21:05:37.828443	1504098448228080_1.jpg	image/jpg	1328	2010-02-01 21:05:37.710527
603	23	AU	AUD	Commodore Amiga 500 / A500 computer	http://cgi.ebay.com.au/Commodore-Amiga-500-A500-computer_W0QQitemZ320481948828QQcategoryZ4598QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204819488288080_1.jpg	320481948828	average	complete	\N	2010-02-07 01:55:46	2010-02-01 21:05:59.16524	2010-02-01 21:05:59.16524	3204819488288080_1.jpg	image/jpg	1098	2010-02-01 21:05:59.051469
604	23	AU	AUD	Commodore Amiga 500 / A500 Personal Computer. Boxed!	http://cgi.ebay.com.au/Commodore-Amiga-500-A500-Personal-Computer-Boxed_W0QQitemZ320481964098QQcategoryZ4598QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204819640988080_1.jpg	320481964098	good	boxed with extras	\N	2010-02-07 03:02:35	2010-02-01 21:06:14.770134	2010-02-01 21:06:14.770134	3204819640988080_1.jpg	image/jpg	1220	2010-02-01 21:06:14.655949
605	23	AU	AUD	Amiga Commodore 500 Computer & Accessories/Games	http://cgi.ebay.com.au/Amiga-Commodore-500-Computer-Accessories-Games_W0QQitemZ250571078962QQcategoryZ4598QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2505710789628080_1.jpg	250571078962	good	complete with extras	\N	2010-02-07 10:57:52	2010-02-01 21:06:43.772506	2010-02-01 21:06:43.772506	2505710789628080_1.jpg	image/jpg	1336	2010-02-01 21:06:43.662129
606	4	AU	AUD	VIC 20	http://cgi.ebay.com.au/VIC-20_W0QQitemZ220548564351QQcategoryZ4315QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2205485643518080_2.jpg	220548564351	poor	complete with extras	\N	2010-02-09 03:03:01	2010-02-01 21:07:20.641556	2010-02-01 21:07:20.641556	2205485643518080_2.jpg	image/jpg	944	2010-02-01 21:07:20.525921
607	29	AU	AUD	COMMODORE 64 PERSONAL COMPUTER x3 BULK LOT+ accessories	http://cgi.ebay.com.au/COMMODORE-64-PERSONAL-COMPUTER-x3-BULK-LOT-accessories_W0QQitemZ180461057394QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1804610573948080_1.jpg	180461057394	average	complete with extras	\N	2010-02-09 07:00:16	2010-02-01 21:07:44.410251	2010-02-01 21:07:44.410251	1804610573948080_1.jpg	image/jpg	1049	2010-02-01 21:07:44.303121
608	29	AU	AUD	Vintage Commodore 64 computer, power, disk drives Perth	http://cgi.ebay.com.au/Vintage-Commodore-64-computer-power-disk-drives-Perth_W0QQitemZ280458528666QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2804585286668080_1.jpg	280458528666	average	complete with extras	\N	2010-02-09 10:09:10	2010-02-01 21:09:47.471126	2010-02-01 21:09:47.471126	2804585286668080_1.jpg	image/jpg	1487	2010-02-01 21:09:47.357331
609	6	AU	AUD	Commodore 16	http://cgi.ebay.com.au/Commodore-16_W0QQitemZ320411867533QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3204118675338080_1.jpg	320411867533	poor	bare	\N	2010-02-09 13:38:40	2010-02-01 21:10:02.394587	2010-02-01 21:10:02.394587	3204118675338080_1.jpg	image/jpg	1045	2010-02-01 21:10:02.281751
610	59	AU	AUD	Commodore 16 data tape player, also used on plus 4 & 64	http://cgi.ebay.com.au/Commodore-16-data-tape-player-also-used-on-plus-4-64_W0QQitemZ320411867651QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3204118676518080_1.jpg	320411867651	average	complete	\N	2010-02-09 13:39:11	2010-02-01 21:10:08.243429	2010-02-01 21:10:08.243429	3204118676518080_1.jpg	image/jpg	1332	2010-02-01 21:10:08.110973
611	3	CA	CAD	VINTAGE COMMODORE KEYBOARD REDUCED PRICE	http://cgi.ebay.ca/VINTAGE-COMMODORE-KEYBOARD-REDUCED-PRICE_W0QQitemZ200432683184QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2004326831848080_1.jpg	200432683184	average	bare	\N	2010-02-02 18:22:28	2010-02-01 21:11:59.299809	2010-02-01 21:11:59.299809	2004326831848080_1.jpg	image/jpg	1024	2010-02-01 21:11:59.180937
612	3	CA	CAD	COMMODORE 64 W/BOX	http://cgi.ebay.ca/COMMODORE-64-W-BOX_W0QQitemZ300390937363QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003909373638080_1.jpg	300390937363	average	boxed with extras	\N	2010-02-02 21:30:09	2010-02-01 21:12:23.066243	2010-02-01 21:12:23.066243	3003909373638080_1.jpg	image/jpg	1256	2010-02-01 21:12:22.952831
613	20	CA	CAD	COMMODORE SINGLE FLOPPY DISK 1541	http://cgi.ebay.ca/COMMODORE-SINGLE-FLOPPY-DISK-1541_W0QQitemZ300390908407QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003909084078080_1.jpg	300390908407	average	complete	\N	2010-02-02 21:30:23	2010-02-01 21:12:34.719579	2010-02-01 21:12:34.719579	3003909084078080_1.jpg	image/jpg	1029	2010-02-01 21:12:34.604353
614	4	CA	CAD	vintage COMMODORE VIC-20 & DATASSETTE RECORDER 	http://cgi.ebay.ca/vintage-COMMODORE-VIC-20-DATASSETTE-RECORDER_W0QQitemZ370326158967QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3703261589678080_1.jpg	370326158967	average	boxed with extras	\N	2010-02-03 02:00:39	2010-02-01 21:13:01.22714	2010-02-01 21:13:01.22714	3703261589678080_1.jpg	image/jpg	1164	2010-02-01 21:13:01.105605
615	20	CA	CAD	Commodore 1541 Single Drive Floppy Disk	http://cgi.ebay.ca/Commodore-1541-Single-Drive-Floppy-Disk_W0QQitemZ390148904951QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3901489049518080_1.jpg	390148904951	poor	complete	\N	2010-02-03 20:04:43	2010-02-01 21:13:35.758276	2010-02-01 21:13:35.758276	3901489049518080_1.jpg	image/jpg	700	2010-02-01 21:13:35.655759
616	4	CA	CAD	1982 COMMODORE VIC-20 COMPUTER orig box 5 SCI FI GAMES	http://cgi.ebay.ca/1982-COMMODORE-VIC-20-COMPUTER-orig-box-5-SCI-FI-GAMES_W0QQitemZ160399112737QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1603991127378080_1.jpg	160399112737	poor	boxed with extras	\N	2010-02-04 02:09:34	2010-02-01 21:14:21.637152	2010-02-01 21:14:21.637152	1603991127378080_1.jpg	image/jpg	1095	2010-02-01 21:14:21.48537
617	3	CA	CAD	Vintage commodore 64 computer Silver Seal Low serial#	http://cgi.ebay.ca/Vintage-commodore-64-computer-Silver-Seal-Low-serial_W0QQitemZ290396396470QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2903963964708080_1.jpg	290396396470	average	boxed	\N	2010-02-04 04:39:02	2010-02-01 21:14:56.644833	2010-02-01 21:14:56.644833	2903963964708080_1.jpg	image/jpg	1195	2010-02-01 21:14:56.533342
618	29	CA	CAD	Vintage Commodore 64C Computer with Box & Manuals	http://cgi.ebay.ca/Vintage-Commodore-64C-Computer-with-Box-Manuals_W0QQitemZ390149513683QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3901495136838080_1.jpg	390149513683	average	boxed with extras	\N	2010-02-05 01:44:31	2010-02-01 21:16:23.74744	2010-02-01 21:16:23.74744	3901495136838080_1.jpg	image/jpg	1010	2010-02-01 21:16:23.631151
619	3	CA	CAD	1980's:COMMODORE 64/KEYBOARD&1541 DRIVE/Un-Tested Cond.	http://cgi.ebay.ca/1980s-COMMODORE-64-KEYBOARD-1541-DRIVE-Un-Tested-Cond_W0QQitemZ160399403400QQcategoryZ162075QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1603994034008080_1.jpg	160399403400	poor	complete with extras	\N	2010-02-05 02:31:10	2010-02-01 21:17:01.993721	2010-02-01 21:17:01.993721	1603994034008080_1.jpg	image/jpg	1205	2010-02-01 21:17:01.86419
620	3	CA	CAD	Commodore 64K	http://cgi.ebay.ca/Commodore-64K_W0QQitemZ390149890403QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3901498904038080_1.jpg	390149890403	average	boxed	\N	2010-02-05 20:38:00	2010-02-01 21:17:52.323005	2010-02-01 21:17:52.323005	3901498904038080_1.jpg	image/jpg	915	2010-02-01 21:17:52.195405
621	7	CA	CAD	Vintage Commodore 128 Computer With Mouse & Power Pack	http://cgi.ebay.ca/Vintage-Commodore-128-Computer-With-Mouse-Power-Pack_W0QQitemZ130362899680QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1303628996808080_1.jpg	130362899680	average	complete	\N	2010-02-05 22:01:00	2010-02-01 21:18:12.326706	2010-02-01 21:18:12.326706	1303628996808080_1.jpg	image/jpg	935	2010-02-01 21:18:12.204746
622	26	CA	CAD	Vintage Commodore 1571 Floppy Disk Drive	http://cgi.ebay.ca/Vintage-Commodore-1571-Floppy-Disk-Drive_W0QQitemZ140378838080QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1403788380808080_1.jpg	140378838080	average	complete	\N	2010-02-05 22:11:21	2010-02-01 21:18:36.53956	2010-02-01 21:18:36.53956	1403788380808080_1.jpg	image/jpg	893	2010-02-01 21:18:36.429631
623	3	CA	CAD	COMMODORE C-64 C64 vintage PC computer *untested*	http://cgi.ebay.ca/COMMODORE-C-64-C64-vintage-PC-computer-untested_W0QQitemZ280458208485QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804582084858080_1.jpg	280458208485	average	complete	\N	2010-02-06 02:27:53	2010-02-01 21:18:52.447361	2010-02-01 21:18:52.447361	2804582084858080_1.jpg	image/jpg	928	2010-02-01 21:18:52.324464
624	35	CA	CAD	Commodore VIC-1541 Disk Drive W/1 Floppy Disk 	http://cgi.ebay.ca/Commodore-VIC-1541-Disk-Drive-W-1-Floppy-Disk_W0QQitemZ380202296404QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3802022964048080_1.jpg	380202296404	poor	complete	\N	2010-02-06 14:31:00	2010-02-01 21:19:01.774881	2010-02-01 21:19:01.774881	3802022964048080_1.jpg	image/jpg	880	2010-02-01 21:19:01.663589
625	20	CA	CAD	vintage COMMODORE COMPUTER 5.25" Disk Drive #1541 	http://cgi.ebay.ca/vintage-COMMODORE-COMPUTER-5-25-Disk-Drive-1541_W0QQitemZ370328269598QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3703282695988080_1.jpg	370328269598	average	complete	\N	2010-02-07 02:25:48	2010-02-01 21:19:10.426832	2010-02-01 21:19:10.426832	3703282695988080_1.jpg	image/jpg	1059	2010-02-01 21:19:10.303222
626	62	CA	CAD	Commodore Amiga CD32 Console+PWSupply+Controls Complete	http://cgi.ebay.ca/Commodore-Amiga-CD32-Console-PWSupply-Controls-Complete_W0QQitemZ130363303475QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1303633034758080_1.jpg	130363303475	mint	boxed	\N	2010-02-07 02:59:10	2010-02-01 21:21:36.584232	2010-02-01 21:21:36.584232	1303633034758080_1.jpg	image/jpg	1472	2010-02-01 21:21:36.466857
627	20	CA	CAD	Commodore 1541 Floppy Disk Drive	http://cgi.ebay.ca/Commodore-1541-Floppy-Disk-Drive_W0QQitemZ150410184566QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1504101845668080_1.jpg	150410184566	good	boxed	\N	2010-02-07 16:44:30	2010-02-01 21:21:54.257156	2010-02-01 21:21:54.257156	1504101845668080_1.jpg	image/jpg	1155	2010-02-01 21:21:54.143251
628	3	CA	CAD	Commodore 64 Personal Computer	http://cgi.ebay.ca/Commodore-64-Personal-Computer_W0QQitemZ150410184573QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1504101845738080_1.jpg	150410184573	good	boxed	\N	2010-02-07 16:44:31	2010-02-01 21:22:09.493381	2010-02-01 21:22:09.493381	1504101845738080_1.jpg	image/jpg	1226	2010-02-01 21:22:09.375128
629	3	CA	CAD	COMMODORE 64 SYSTEM ORIGINAL BOXES W/ LOTS OF EXTRAS!!!	http://cgi.ebay.ca/COMMODORE-64-SYSTEM-ORIGINAL-BOXES-W-LOTS-OF-EXTRAS_W0QQitemZ160400108490QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1604001084908080_1.jpg	160400108490	poor	boxed with extras	\N	2010-02-07 16:47:21	2010-02-01 21:22:34.018771	2010-02-01 21:22:34.018771	1604001084908080_1.jpg	image/jpg	1223	2010-02-01 21:22:33.890661
630	3	CA	CAD	[Commodore 64] Original Silver Badge Model (S00018035)	http://cgi.ebay.ca/Commodore-64-Original-Silver-Badge-Model-S00018035_W0QQitemZ270524268674QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705242686748080_1.jpg	270524268674	good	complete	\N	2010-02-07 22:56:03	2010-02-01 21:23:22.264384	2010-02-01 21:23:22.264384	2705242686748080_1.jpg	image/jpg	1054	2010-02-01 21:23:22.127678
631	3	CA	CAD	Commodore 64 Computer System Console Floppy Drive Plus	http://cgi.ebay.ca/Commodore-64-Computer-System-Console-Floppy-Drive-Plus_W0QQitemZ370328631411QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3703286314118080_1.jpg	370328631411	poor	complete with extras	\N	2010-02-08 00:09:50	2010-02-01 21:23:47.892381	2010-02-01 21:23:47.892381	3703286314118080_1.jpg	image/jpg	906	2010-02-01 21:23:47.757805
632	22	CA	CAD	Commodore 1581 Disk Drive + P/S TESTED good condition	http://cgi.ebay.ca/Commodore-1581-Disk-Drive-P-S-TESTED-good-condition_W0QQitemZ190369788800QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903697888008080_1.jpg	190369788800	average	complete	\N	2010-02-08 02:28:40	2010-02-01 21:24:01.94275	2010-02-01 21:24:01.94275	1903697888008080_1.jpg	image/jpg	1007	2010-02-01 21:24:01.809121
633	20	CA	CAD	Commodore 1571 Disk Drive- Wrong Picture...	http://cgi.ebay.ca/Commodore-1571-Disk-Drive-Wrong-Picture_W0QQitemZ330380756074QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3303807560748080_3.jpg	330380756074	average	complete	\N	2010-02-23 21:35:37	2010-02-01 21:25:36.99047	2010-02-01 21:25:36.99047	3303807560748080_3.jpg	image/jpg	1240	2010-02-01 21:25:36.871383
634	3	CA	CAD	Commodore 64 - a great addition to your collection	http://cgi.ebay.ca/Commodore-64-a-great-addition-to-your-collection_W0QQitemZ330380756587QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3303807565878080_3.jpg	330380756587	poor	bare	\N	2010-02-23 21:37:39	2010-02-01 21:25:52.106785	2010-02-01 21:25:52.106785	3303807565878080_3.jpg	image/jpg	1013	2010-02-01 21:25:51.986053
635	4	CA	CAD	VERY OLD COMPUTER COMMODORE VIC 20 WITH ACCESORIES	http://cgi.ebay.ca/VERY-OLD-COMPUTER-COMMODORE-VIC-20-WITH-ACCESORIES_W0QQitemZ260438280937QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2604382809378080_10.jpg	260438280937	poor	boxed with extras	\N	2010-02-24 18:46:18	2010-02-01 21:26:11.684801	2010-02-01 21:26:11.684801	2604382809378080_10.jpg	image/jpg	1224	2010-02-01 21:26:11.570412
636	29	DE	EUR	=== Neuwertiger Commodore C64II Made in W.Germany ===	http://cgi.ebay.de/Neuwertiger-Commodore-C64II-Made-in-W-Germany_W0QQitemZ110488395159QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104883951598080_1.jpg	110488395159	average	complete	\N	2010-03-02 10:05:53	2010-02-01 21:30:30.758779	2010-02-01 21:30:30.758779	1104883951598080_1.jpg	image/jpg	861	2010-02-01 21:30:30.655069
637	3	DE	EUR	Commodore 64 G-Version, Top-Zustand, kein Gilb (72)	http://cgi.ebay.de/Commodore-64-G-Version-Top-Zustand-kein-Gilb-72_W0QQitemZ350311874405QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3503118744058080_1.jpg	350311874405	good	complete	\N	2010-03-03 09:01:15	2010-02-01 21:31:28.094051	2010-02-01 21:31:28.094051	3503118744058080_1.jpg	image/jpg	905	2010-02-01 21:31:27.976885
638	20	DE	EUR	**  FLOPPY 1541  **  FÜR COMMODORE 64 & C128	http://cgi.ebay.de/FLOPPY-1541-FUR-COMMODORE-64-C128_W0QQitemZ290394752482QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2903947524828080_1.jpg	290394752482	average	complete	\N	2010-02-22 15:59:06	2010-02-01 21:31:47.248728	2010-02-01 21:31:47.248728	2903947524828080_1.jpg	image/jpg	1051	2010-02-01 21:31:47.129375
639	59	DE	EUR	Commodore 1531 Datasette für C16 / C116 / plus/4	http://cgi.ebay.de/Commodore-1531-Datasette-fuer-C16-C116-plus-4_W0QQitemZ370328580701QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3703285807018080_1.jpg	370328580701	poor	complete	\N	2010-02-07 18:43:31	2010-02-01 21:32:13.611479	2010-02-01 21:32:13.611479	3703285807018080_1.jpg	image/jpg	1427	2010-02-01 21:32:13.488507
640	36	DE	EUR	=== Original Commodore Amiga A1200HD/40 ===	http://cgi.ebay.de/Original-Commodore-Amiga-A1200HD-40_W0QQitemZ110484462290QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1104844622908080_1.jpg	110484462290	average	complete	\N	2010-02-20 15:13:47	2010-02-01 21:32:46.194087	2010-02-01 21:32:46.194087	1104844622908080_1.jpg	image/jpg	907	2010-02-01 21:32:46.069548
641	29	DE	EUR	Commodore 64 C-Version * sealed,  no yellowing * [v13]	http://cgi.ebay.de/Commodore-64-C-Version-sealed-no-yellowing-v13_W0QQitemZ350308886852QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3503088868528080_1.jpg	350308886852	good	complete	\N	2010-02-23 08:15:35	2010-02-01 21:33:11.796436	2010-02-01 21:33:11.796436	3503088868528080_1.jpg	image/jpg	952	2010-02-01 21:33:11.652499
642	36	DE	EUR	Commodore Amiga 1200HD in rare Condition + Kick 3.1	http://cgi.ebay.de/Commodore-Amiga-1200HD-in-rare-Condition-Kick-3-1_W0QQitemZ260546271071QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2605462710718080_1.jpg	260546271071	good	complete	\N	2010-03-02 18:54:03	2010-02-01 21:34:59.934585	2010-02-01 21:34:59.934585	2605462710718080_1.jpg	image/jpg	1219	2010-02-01 21:34:59.816533
643	29	DE	EUR	Commodore C 64 mit Netzteil und Spielen	http://cgi.ebay.de/Commodore-C-64-mit-Netzteil-und-Spielen_W0QQitemZ180461647871QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1804616478718080_1.jpg	180461647871	poor	complete with extras	\N	2010-02-02 18:28:51	2010-02-01 21:35:46.243757	2010-02-01 21:35:46.243757	1804616478718080_1.jpg	image/jpg	1347	2010-02-01 21:35:46.110008
644	63	DE	EUR	PLA Ersatz Replace Commodore C64 und andere	http://cgi.ebay.de/PLA-Ersatz-Replace-Commodore-C64-und-andere_W0QQitemZ180462621463QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1804626214638080_1.jpg	180462621463	average	complete with extras	\N	2010-02-02 20:18:34	2010-02-01 21:37:21.307363	2010-02-01 21:37:21.307363	1804626214638080_1.jpg	image/jpg	1122	2010-02-01 21:37:21.186506
645	3	DE	EUR	Commodore C64 mit Floppy / Bastlerobjekt / kein Bild	http://cgi.ebay.de/Commodore-C64-mit-Floppy-Bastlerobjekt-kein-Bild_W0QQitemZ220545656637QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2205456566378080_1.jpg	220545656637	poor	complete with extras	\N	2010-02-03 12:49:22	2010-02-01 21:37:54.471978	2010-02-01 21:37:54.471978	2205456566378080_1.jpg	image/jpg	968	2010-02-01 21:37:54.358168
646	59	DE	EUR	Commodore DATASSETTE	http://cgi.ebay.de/Commodore-DATASSETTE_W0QQitemZ290396139511QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2903961395118080_1.jpg	290396139511	average	complete	\N	2010-02-03 13:30:52	2010-02-01 21:38:45.622336	2010-02-01 21:38:45.622336	2903961395118080_1.jpg	image/jpg	1113	2010-02-01 21:38:45.497819
647	23	DE	EUR	Commodore Amiga 500 mit Zubehör	http://cgi.ebay.de/Commodore-Amiga-500-mit-Zubehoer_W0QQitemZ190368672608QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903686726088080_1.jpg	190368672608	poor	complete with extras	\N	2010-02-03 15:50:11	2010-02-01 21:38:55.868486	2010-02-01 21:38:55.868486	1903686726088080_1.jpg	image/jpg	922	2010-02-01 21:38:55.74939
648	21	DE	EUR	Commodore 64 Floppys und Zubehör	http://cgi.ebay.de/Commodore-64-Floppys-und-Zubehoer_W0QQitemZ200432991770QQcategoryZ3543QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2004329917708080_1.jpg	200432991770	average	complete with extras	\N	2010-02-03 16:43:52	2010-02-01 21:39:21.558454	2010-02-01 21:39:21.558454	2004329917708080_1.jpg	image/jpg	928	2010-02-01 21:39:21.452194
649	11	DE	EUR	Commodore 8032	http://cgi.ebay.de/Commodore-8032_W0QQitemZ250569017026QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2505690170268080_1.jpg	250569017026	good	complete	\N	2010-02-03 17:18:28	2010-02-01 21:39:43.476209	2010-02-01 21:39:43.476209	2505690170268080_1.jpg	image/jpg	894	2010-02-01 21:39:43.354264
650	63	DE	EUR	Commodore 116	http://cgi.ebay.de/Commodore-116_W0QQitemZ180462974140QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1804629741408080_1.jpg	180462974140	good	complete with extras	\N	2010-02-03 17:51:02	2010-02-01 21:40:09.713606	2010-02-01 21:40:09.713606	1804629741408080_1.jpg	image/jpg	1245	2010-02-01 21:40:09.597557
651	6	DE	EUR	Commodore C16	http://cgi.ebay.de/Commodore-C16_W0QQitemZ280455158233QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804551582338080_1.jpg	280455158233	good	complete with extras	\N	2010-02-03 19:06:28	2010-02-01 21:40:51.266638	2010-02-01 21:40:51.266638	2804551582338080_1.jpg	image/jpg	939	2010-02-01 21:40:51.147839
652	29	DE	EUR	Commodore C64+Farbmonitor+Floppy Laufwerk+viel Zubehör	http://cgi.ebay.de/Commodore-C64-Farbmonitor-Floppy-Laufwerk-viel-Zubehoer_W0QQitemZ250569105678QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2505691056788080_1.jpg	250569105678	average	complete with extras	\N	2010-02-03 19:21:29	2010-02-01 21:41:08.97962	2010-02-01 21:41:08.97962	2505691056788080_1.jpg	image/jpg	1030	2010-02-01 21:41:08.856357
653	29	DE	EUR	Commodore C64 + Floppy 1541 + 2 Joysticks + Drucker	http://cgi.ebay.de/Commodore-C64-Floppy-1541-2-Joysticks-Drucker_W0QQitemZ140378755545QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1403787555458080_1.jpg	140378755545	good	complete with extras	\N	2010-02-03 19:24:35	2010-02-01 21:41:24.85536	2010-02-01 21:41:24.85536	1403787555458080_1.jpg	image/jpg	1395	2010-02-01 21:41:24.739982
654	23	DE	EUR	Amiga 500 Commodore Computer 	http://cgi.ebay.de/Amiga-500-Commodore-Computer_W0QQitemZ220547468298QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2205474682988080_1.jpg	220547468298	good	complete with extras	\N	2010-02-03 21:17:18	2010-02-01 21:41:47.033305	2010-02-01 21:41:47.033305	2205474682988080_1.jpg	image/jpg	1044	2010-02-01 21:41:46.901755
655	64	DE	EUR	Commodore Heimcomputer	http://cgi.ebay.de/Commodore-Heimcomputer_W0QQitemZ260544517943QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2605445179438080_1.jpg	260544517943	average	boxed	\N	2010-02-03 21:42:23	2010-02-01 21:42:55.836946	2010-02-01 21:42:55.836946	2605445179438080_1.jpg	image/jpg	1093	2010-02-01 21:42:55.713923
656	29	DE	EUR	Commodore C64 C 64  	http://cgi.ebay.de/Commodore-C64-C-64_W0QQitemZ140377556963QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1403775569638080_1.jpg	140377556963	poor	complete	\N	2010-02-04 14:14:56	2010-02-01 21:44:04.574885	2010-02-01 21:44:04.574885	1403775569638080_1.jpg	image/jpg	841	2010-02-01 21:44:04.453856
657	29	DE	EUR	Commodore C64 mit Zubehör 	http://cgi.ebay.de/Commodore-C64-mit-Zubehoer_W0QQitemZ320480834898QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204808348988080_1.jpg	320480834898	average	complete with extras	\N	2010-02-04 17:09:24	2010-02-01 21:44:33.425781	2010-02-01 21:44:33.425781	3204808348988080_1.jpg	image/jpg	1154	2010-02-01 21:44:33.32094
658	29	DE	EUR	Commodore - C 64 C und Zubehör	http://cgi.ebay.de/Commodore-C-64-C-und-Zubehoer_W0QQitemZ250571186046QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2505711860468080_1.jpg	250571186046	poor	complete with extras	\N	2010-02-04 15:55:23	2010-02-01 21:44:43.147404	2010-02-01 21:44:43.147404	2505711860468080_1.jpg	image/jpg	1246	2010-02-01 21:44:43.030778
659	23	DE	EUR	Commodore Amiga 500 Starter Edition mit OVP 	http://cgi.ebay.de/Commodore-Amiga-500-Starter-Edition-mit-OVP_W0QQitemZ200431700999QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2004317009998080_1.jpg	200431700999	good	boxed with extras	\N	2010-02-04 17:55:19	2010-02-01 21:45:46.645511	2010-02-01 21:45:46.645511	2004317009998080_1.jpg	image/jpg	1063	2010-02-01 21:45:46.539461
660	65	DE	EUR	Commodore Amiga 600 mit OVP +  2MB Chip Ram 	http://cgi.ebay.de/Commodore-Amiga-600-mit-OVP-2MB-Chip-Ram_W0QQitemZ200431705038QQcategoryZ8142QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2004317050388080_1.jpg	200431705038	good	boxed with extras	\N	2010-02-04 18:05:25	2010-02-01 21:46:43.537357	2010-02-01 21:46:43.537357	2004317050388080_1.jpg	image/jpg	1114	2010-02-01 21:46:43.414938
661	65	DE	EUR	Commodore Amiga 600	http://cgi.ebay.de/Commodore-Amiga-600_W0QQitemZ220546345989QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2205463459898080_1.jpg	220546345989	good	complete	\N	2010-02-04 18:26:51	2010-02-01 21:47:05.706505	2010-02-01 21:47:05.706505	2205463459898080_1.jpg	image/jpg	938	2010-02-01 21:47:05.59244
662	20	DE	EUR	Commodore 1541 Diskettenlaufwerk Floppy Disk Drive	http://cgi.ebay.de/Commodore-1541-Diskettenlaufwerk-Floppy-Disk-Drive_W0QQitemZ320480973318QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204809733188080_1.jpg	320480973318	average	complete	\N	2010-02-04 18:34:22	2010-02-01 21:47:12.568971	2010-02-01 21:47:12.568971	3204809733188080_1.jpg	image/jpg	1029	2010-02-01 21:47:12.451801
663	25	DE	EUR	Commodore 1541 C Diskettenlaufwerk Floppy Disk Drive	http://cgi.ebay.de/Commodore-1541-C-Diskettenlaufwerk-Floppy-Disk-Drive_W0QQitemZ320480974792QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204809747928080_1.jpg	320480974792	average	complete	\N	2010-02-04 18:37:50	2010-02-01 21:47:17.501881	2010-02-01 21:47:17.501881	3204809747928080_1.jpg	image/jpg	1035	2010-02-01 21:47:17.382201
664	29	DE	EUR	Commodore 64 - OK.	http://cgi.ebay.de/Commodore-64-OK_W0QQitemZ170439666192QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704396661928080_1.jpg	170439666192	good	complete	\N	2010-02-04 19:18:54	2010-02-01 21:47:47.849063	2010-02-01 21:47:47.849063	1704396661928080_1.jpg	image/jpg	1004	2010-02-01 21:47:47.724341
665	23	DE	EUR	Commodore Amiga 500 OVP! mit Monitor	http://cgi.ebay.de/Commodore-Amiga-500-OVP-mit-Monitor_W0QQitemZ180461273041QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1804612730418080_1.jpg	180461273041	poor	boxed	\N	2010-02-04 19:59:28	2010-02-01 21:48:26.300171	2010-02-01 21:48:26.300171	1804612730418080_1.jpg	image/jpg	1034	2010-02-01 21:48:26.183984
666	23	DE	EUR	Commodore Amiga 500 	http://cgi.ebay.de/Commodore-Amiga-500_W0QQitemZ310197489831QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3101974898318080_1.jpg	310197489831	good	complete with extras	\N	2010-02-05 12:00:57	2010-02-01 21:53:08.594782	2010-02-01 21:53:08.594782	3101974898318080_1.jpg	image/jpg	1045	2010-02-01 21:53:08.470509
667	3	DE	EUR	Commodore 64 Computer,Brotkasten !!!	http://cgi.ebay.de/Commodore-64-Computer-Brotkasten_W0QQitemZ280458231779QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2804582317798080_1.jpg	280458231779	average	complete with extras	\N	2010-02-05 15:33:24	2010-02-01 21:53:25.863384	2010-02-01 21:53:25.863384	2804582317798080_1.jpg	image/jpg	884	2010-02-01 21:53:25.748105
668	25	DE	EUR	Commodore 1541 Disk Drive	http://cgi.ebay.de/Commodore-1541-Disk-Drive_W0QQitemZ300390883961QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3003908839618080_1.jpg	300390883961	average	complete	\N	2010-02-05 18:18:29	2010-02-01 21:53:53.354205	2010-02-01 21:53:53.354205	3003908839618080_1.jpg	image/jpg	776	2010-02-01 21:53:53.23524
669	24	DE	EUR	*** COMMODORE C128D PLASTIK ***	http://cgi.ebay.de/COMMODORE-C128D-PLASTIK_W0QQitemZ320482268863QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3204822688638080_1.jpg	320482268863	average	complete	\N	2010-02-05 18:26:01	2010-02-01 21:54:18.149757	2010-02-01 21:54:18.149757	3204822688638080_1.jpg	image/jpg	1040	2010-02-01 21:54:18.032575
670	59	DE	EUR	Commodore Datasette, schwarz mit  Cassette	http://cgi.ebay.de/Commodore-Datasette-schwarz-mit-Cassette_W0QQitemZ260545373318QQcategoryZ8101QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2605453733188080_1.jpg	260545373318	average	complete	\N	2010-02-05 18:57:24	2010-02-01 21:54:23.734069	2010-02-01 21:54:23.734069	2605453733188080_1.jpg	image/jpg	1092	2010-02-01 21:54:23.620832
671	65	DE	EUR	Commodore A600 Amiga+Bildschirm+Maus+Joyst.+100 Diskett	http://cgi.ebay.de/Commodore-A600-Amiga-Bildschirm-Maus-Joyst-100-Diskett_W0QQitemZ270523141532QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2705231415328080_1.jpg	270523141532	good	complete with extras	\N	2010-02-05 19:46:53	2010-02-01 22:02:25.817802	2010-02-01 22:02:25.817802	2705231415328080_1.jpg	image/jpg	1082	2010-02-01 22:02:25.683963
672	59	DE	EUR	Datasette Commodore 1531 defekt für Bastler	http://cgi.ebay.de/Datasette-Commodore-1531-defekt-fuer-Bastler_W0QQitemZ280459210047QQcategoryZ3543QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2804592100478080_1.jpg	280459210047	poor	complete	\N	2010-02-05 20:14:18	2010-02-01 22:02:32.730032	2010-02-01 22:02:32.730032	2804592100478080_1.jpg	image/jpg	1213	2010-02-01 22:02:32.487565
673	21	DE	EUR	Commodore 5,25 Disketten Laufwerk: 1541 - II + Netzteil	http://cgi.ebay.de/Commodore-5-25-Disketten-Laufwerk-1541-II-Netzteil_W0QQitemZ180461738452QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1804617384528080_1.jpg	180461738452	average	complete	\N	2010-02-05 21:56:37	2010-02-01 22:04:22.321808	2010-02-01 22:04:22.321808	1804617384528080_1.jpg	image/jpg	1241	2010-02-01 22:04:22.205225
674	59	DE	EUR	Commodore Datasette Model 1531	http://cgi.ebay.de/Commodore-Datasette-Model-1531_W0QQitemZ300392015317QQcategoryZ3543QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3003920153178080_1.jpg	300392015317	poor	complete	\N	2010-02-06 11:59:18	2010-02-01 22:04:36.443515	2010-02-01 22:04:36.443515	3003920153178080_1.jpg	image/jpg	1144	2010-02-01 22:04:36.310789
675	23	DE	EUR	Commodore Amiga A500	http://cgi.ebay.de/Commodore-Amiga-A500_W0QQitemZ320480431438QQcategoryZ8154QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3204804314388080_1.jpg	320480431438	average	complete	\N	2010-02-06 12:28:45	2010-02-01 22:04:45.995799	2010-02-01 22:04:45.995799	3204804314388080_1.jpg	image/jpg	1161	2010-02-01 22:04:45.882519
676	29	DE	EUR	Commodore C64 + Monitor, Floppy, Drucker + Zubehör	http://cgi.ebay.de/Commodore-C64-Monitor-Floppy-Drucker-Zubehoer_W0QQitemZ300392704063QQcategoryZ3543QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003927040638080_1.jpg	300392704063	good	complete with extras	\N	2010-02-06 14:27:14	2010-02-01 22:05:06.656048	2010-02-01 22:05:06.656048	3003927040638080_1.jpg	image/jpg	1104	2010-02-01 22:05:06.536286
677	29	DE	EUR	Commodore 64+Bildschirm+Dataset+Floppy	http://cgi.ebay.de/Commodore-64-Bildschirm-Dataset-Floppy_W0QQitemZ220548735968QQcategoryZ3543QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2205487359688080_1.jpg	220548735968	good	complete with extras	\N	2010-02-06 14:55:02	2010-02-01 22:05:24.386088	2010-02-01 22:05:24.386088	2205487359688080_1.jpg	image/jpg	1409	2010-02-01 22:05:24.271593
678	55	DE	EUR	Commodore C64 + Floppylaufwerk + Software,funktioniert	http://cgi.ebay.de/Commodore-C64-Floppylaufwerk-Software-funktioniert_W0QQitemZ350311248759QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3503112487598080_1.jpg	350311248759	good	complete with extras	\N	2010-02-06 15:18:34	2010-02-01 22:06:08.293504	2010-02-01 22:06:08.293504	3503112487598080_1.jpg	image/jpg	1150	2010-02-01 22:06:08.171553
679	3	DE	EUR	Commodore C64 inkl. 2 Floppy Laufwerke	http://cgi.ebay.de/Commodore-C64-inkl-2-Floppy-Laufwerke_W0QQitemZ250570630363QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2505706303638080_1.jpg	250570630363	average	complete with extras	\N	2010-02-06 15:55:12	2010-02-01 22:06:20.504405	2010-02-01 22:06:20.504405	2505706303638080_1.jpg	image/jpg	1017	2010-02-01 22:06:20.377076
680	29	DE	EUR	Commodore 64 II mit Netzteil	http://cgi.ebay.de/Commodore-64-II-mit-Netzteil_W0QQitemZ300392089919QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003920899198080_1.jpg	300392089919	poor	complete	\N	2010-02-06 17:15:11	2010-02-01 22:07:02.421662	2010-02-01 22:07:02.421662	3003920899198080_1.jpg	image/jpg	929	2010-02-01 22:07:02.300374
681	29	DE	EUR	Commodore 64 II Spezial Umbau	http://cgi.ebay.de/Commodore-64-II-Spezial-Umbau_W0QQitemZ300392089944QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3003920899448080_1.jpg	300392089944	poor	complete	\N	2010-02-06 17:15:16	2010-02-01 22:07:13.571568	2010-02-01 22:07:13.571568	3003920899448080_1.jpg	image/jpg	922	2010-02-01 22:07:13.457431
682	24	DE	EUR	Commodore C128 C128D mit integr. C64	http://cgi.ebay.de/Commodore-C128-C128D-mit-integr-C64_W0QQitemZ180463343712QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1804633437128080_1.jpg	180463343712	good	complete	\N	2010-02-06 17:45:34	2010-02-01 22:07:36.046817	2010-02-01 22:07:36.046817	1804633437128080_1.jpg	image/jpg	1219	2010-02-01 22:07:35.934429
683	6	DE	EUR	Commodore C16	http://cgi.ebay.de/Commodore-C16_W0QQitemZ110488047178QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1104880471788080_1.jpg	110488047178	average	bare	\N	2010-02-06 18:46:46	2010-02-01 22:07:54.177078	2010-02-01 22:07:54.177078	1104880471788080_1.jpg	image/jpg	1081	2010-02-01 22:07:54.059856
684	29	DE	EUR	Commodore C64 mit Zubehör  56075 Koblenz	http://cgi.ebay.de/Commodore-C64-mit-Zubehoer-56075-Koblenz_W0QQitemZ120524706350QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1205247063508080_1.jpg	120524706350	average	complete with extras	\N	2010-02-06 19:00:16	2010-02-01 22:08:07.727567	2010-02-01 22:08:07.727567	1205247063508080_1.jpg	image/jpg	1028	2010-02-01 22:08:07.594831
685	3	DE	EUR	Commodore 64	http://cgi.ebay.de/Commodore-64_W0QQitemZ120524706822QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1205247068228080_1.jpg	120524706822	good	boxed with extras	\N	2010-02-06 19:01:31	2010-02-01 22:08:29.455473	2010-02-01 22:08:29.455473	1205247068228080_1.jpg	image/jpg	1237	2010-02-01 22:08:29.341208
686	29	DE	EUR	Commodore C 64 mit Floppy, Datasette, Zubehöhr	http://cgi.ebay.de/Commodore-C-64-mit-Floppy-Datasette-Zubehoehr_W0QQitemZ330400260220QQcategoryZ3545QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3304002602208080_1.jpg	330400260220	average	boxed with extras	\N	2010-02-06 19:14:38	2010-02-01 22:08:46.373385	2010-02-01 22:08:46.373385	3304002602208080_1.jpg	image/jpg	1161	2010-02-01 22:08:46.263585
687	55	DE	EUR	COMMODORE C 64 + VIEL ZUBEHÖR !!!!	http://cgi.ebay.de/COMMODORE-C-64-VIEL-ZUBEHOR_W0QQitemZ290398057547QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2903980575478080_1.jpg	290398057547	average	complete with extras	\N	2010-02-06 19:34:02	2010-02-01 22:09:13.734841	2010-02-01 22:09:13.734841	2903980575478080_1.jpg	image/jpg	1202	2010-02-01 22:09:13.616444
688	55	DE	EUR	Commodore 64 C64G + C64 Super Games + Netzteil	http://cgi.ebay.de/Commodore-64-C64G-C64-Super-Games-Netzteil_W0QQitemZ180462162106QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1804621621068080_1.jpg	180462162106	good	complete with extras	\N	2010-02-06 21:05:18	2010-02-01 22:09:26.224752	2010-02-01 22:09:26.224752	1804621621068080_1.jpg	image/jpg	1060	2010-02-01 22:09:26.109989
689	3	DE	EUR	Commodore 64 MicroComputer im Orginalkarton	http://cgi.ebay.de/Commodore-64-MicroComputer-im-Orginalkarton_W0QQitemZ160399889703QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1603998897038080_1.jpg	160399889703	poor	boxed	\N	2010-02-06 21:09:08	2010-02-01 22:09:36.022828	2010-02-01 22:09:36.022828	1603998897038080_1.jpg	image/jpg	1283	2010-02-01 22:09:35.905828
690	35	DE	EUR	Diskettenlaufwerk Commodore C64, VC1541 - 100% i.O.	http://cgi.ebay.de/Diskettenlaufwerk-Commodore-C64-VC1541-100-i-O_W0QQitemZ120523704820QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1205237048208080_1.jpg	120523704820	average	complete	\N	2010-02-07 06:11:33	2010-02-01 22:09:49.27468	2010-02-01 22:09:49.27468	1205237048208080_1.jpg	image/jpg	738	2010-02-01 22:09:49.162717
691	55	DE	EUR	Commodore C64 mit viel Zubehör	http://cgi.ebay.de/Commodore-C64-mit-viel-Zubehoer_W0QQitemZ200434253787QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2004342537878080_1.jpg	200434253787	average	complete with extras	\N	2010-02-07 08:40:15	2010-02-01 22:10:00.37815	2010-02-01 22:10:00.37815	2004342537878080_1.jpg	image/jpg	1093	2010-02-01 22:10:00.259546
692	29	DE	EUR	Commodore 64 Videospielkonsole	http://cgi.ebay.de/Commodore-64-Videospielkonsole_W0QQitemZ120524907134QQcategoryZ3545QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1205249071348080_1.jpg	120524907134	average	complete with extras	\N	2010-02-07 09:39:42	2010-02-01 22:10:11.536287	2010-02-01 22:10:11.536287	1205249071348080_1.jpg	image/jpg	1140	2010-02-01 22:10:11.435293
693	21	DE	EUR	Je 2 x Commodore C64 Floppy Bastler	http://cgi.ebay.de/Je-2-x-Commodore-C64-Floppy-Bastler_W0QQitemZ170439873003QQcategoryZ3543QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1704398730038080_1.jpg	170439873003	average	complete with extras	\N	2010-02-07 09:56:27	2010-02-01 22:10:27.864152	2010-02-01 22:10:27.864152	1704398730038080_1.jpg	image/jpg	885	2010-02-01 22:10:27.739567
694	21	DE	EUR	Je 2 x Commodore C64 Floppy Bastler	http://cgi.ebay.de/Je-2-x-Commodore-C64-Floppy-Bastler_W0QQitemZ170439873829QQcategoryZ3543QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704398738298080_1.jpg	170439873829	average	complete with extras	\N	2010-02-07 09:59:19	2010-02-01 22:10:32.960993	2010-02-01 22:10:32.960993	1704398738298080_1.jpg	image/jpg	856	2010-02-01 22:10:32.848364
695	3	DE	EUR	Commodore 64 (Brotkasten)	http://cgi.ebay.de/Commodore-64-Brotkasten_W0QQitemZ280458939922QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2804589399228080_1.jpg	280458939922	average	complete	\N	2010-02-07 10:15:18	2010-02-01 22:11:10.1398	2010-02-01 22:11:10.1398	2804589399228080_1.jpg	image/jpg	1228	2010-02-01 22:11:10.027794
696	20	DE	EUR	Commodore Single Floppy Disk Laufwerk im Orginalkarton	http://cgi.ebay.de/Commodore-Single-Floppy-Disk-Laufwerk-im-Orginalkarton_W0QQitemZ160400033995QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1604000339958080_1.jpg	160400033995	poor	complete	\N	2010-02-07 11:32:48	2010-02-01 22:11:31.758159	2010-02-01 22:11:31.758159	1604000339958080_1.jpg	image/jpg	965	2010-02-01 22:11:31.643221
697	24	DE	EUR	Commodore 128D mit über 380 Disketten	http://cgi.ebay.de/Commodore-128D-mit-ueber-380-Disketten_W0QQitemZ320482066036QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204820660368080_1.jpg	320482066036	average	complete with extras	\N	2010-02-07 11:33:42	2010-02-01 22:11:44.19372	2010-02-01 22:11:44.19372	3204820660368080_1.jpg	image/jpg	926	2010-02-01 22:11:44.079991
698	64	DE	EUR	Commodore Plus 4 + Datasette + viel Zubehör	http://cgi.ebay.de/Commodore-Plus-4-Datasette-viel-Zubehoer_W0QQitemZ110488416729QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1104884167298080_1.jpg	110488416729	average	complete with extras	\N	2010-02-07 11:40:24	2010-02-01 22:12:05.871406	2010-02-01 22:12:05.871406	1104884167298080_1.jpg	image/jpg	1225	2010-02-01 22:12:05.716772
699	4	DE	EUR	Commodore VC-20 mit Zubehör	http://cgi.ebay.de/Commodore-VC-20-mit-Zubehoer_W0QQitemZ180463624636QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1804636246368080_1.jpg	180463624636	poor	complete with extras	\N	2010-02-07 11:48:40	2010-02-01 22:12:16.000845	2010-02-01 22:12:16.000845	1804636246368080_1.jpg	image/jpg	1192	2010-02-01 22:12:15.819551
700	3	DE	EUR	 Oldtimer Commodore C64	http://cgi.ebay.de/Oldtimer-Commodore-C64_W0QQitemZ200434297525QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004342975258080_1.jpg	200434297525	poor	complete with extras	\N	2010-02-07 12:12:42	2010-02-01 22:12:27.481364	2010-02-01 22:12:27.481364	2004342975258080_1.jpg	image/jpg	1264	2010-02-01 22:12:27.365727
701	55	DE	EUR	Commodore C64 mit Datasette	http://cgi.ebay.de/Commodore-C64-mit-Datasette_W0QQitemZ190369576348QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903695763488080_1.jpg	190369576348	poor	complete with extras	\N	2010-02-07 13:13:38	2010-02-01 22:12:38.789602	2010-02-01 22:12:38.789602	1903695763488080_1.jpg	image/jpg	1208	2010-02-01 22:12:38.673474
702	21	DE	EUR	Disk Drive 1541-II Commodore C 64 Floppy	http://cgi.ebay.de/Disk-Drive-1541-II-Commodore-C-64-Floppy_W0QQitemZ150410149582QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1504101495828080_1.jpg	150410149582	average	boxed	\N	2010-02-07 14:47:37	2010-02-01 22:13:04.741362	2010-02-01 22:13:04.741362	1504101495828080_1.jpg	image/jpg	1060	2010-02-01 22:13:04.621829
703	20	DE	EUR	COMMODORE FLOPPY  MODELL 1541	http://cgi.ebay.de/COMMODORE-FLOPPY-MODELL-1541_W0QQitemZ150410166749QQcategoryZ42794QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1504101667498080_1.jpg	150410166749	average	complete	\N	2010-02-07 15:48:05	2010-02-01 22:13:21.72671	2010-02-01 22:13:21.72671	1504101667498080_1.jpg	image/jpg	832	2010-02-01 22:13:21.603578
704	63	DE	EUR	█ Commodore 116 + Datasette █ 	http://cgi.ebay.de/Commodore-116-Datasette_W0QQitemZ120523868270QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1205238682708080_1.jpg	120523868270	good	complete with extras	\N	2010-02-07 16:42:24	2010-02-01 22:13:37.151208	2010-02-01 22:13:37.151208	1205238682708080_1.jpg	image/jpg	1182	2010-02-01 22:13:37.019546
705	63	DE	EUR	Computer Commodore 116	http://cgi.ebay.de/Computer-Commodore-116_W0QQitemZ200434380983QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2004343809838080_1.jpg	200434380983	good	boxed	\N	2010-02-07 16:52:36	2010-02-01 22:13:56.032063	2010-02-01 22:13:56.032063	2004343809838080_1.jpg	image/jpg	1347	2010-02-01 22:13:55.914099
706	23	DE	EUR	Commodore AMIGA 500 + viel Zubehör	http://cgi.ebay.de/Commodore-AMIGA-500-viel-Zubehoer_W0QQitemZ300392403659QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003924036598080_1.jpg	300392403659	poor	complete	\N	2010-02-07 17:26:21	2010-02-01 22:14:17.77682	2010-02-01 22:14:17.77682	3003924036598080_1.jpg	image/jpg	1056	2010-02-01 22:14:17.664985
707	29	DE	EUR	Commodore C64	http://cgi.ebay.de/Commodore-C64_W0QQitemZ330400607899QQcategoryZ3543QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3304006078998080_1.jpg	330400607899	good	boxed with extras	\N	2010-02-07 17:22:09	2010-02-01 22:14:52.65378	2010-02-01 22:14:52.65378	3304006078998080_1.jpg	image/jpg	1257	2010-02-01 22:14:52.53131
708	55	DE	EUR	Commodore C 64 	http://cgi.ebay.de/Commodore-C-64_W0QQitemZ130363433138QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1303634331388080_1.jpg	130363433138	average	complete with extras	\N	2010-02-07 17:37:19	2010-02-01 22:15:13.334792	2010-02-01 22:15:13.334792	1303634331388080_1.jpg	image/jpg	1007	2010-02-01 22:15:13.220713
709	23	DE	EUR	Commodore Amiga 500 mit Monitor M1084	http://cgi.ebay.de/Commodore-Amiga-500-mit-Monitor-M1084_W0QQitemZ290397613971QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2903976139718080_1.jpg	290397613971	average	complete with extras	\N	2010-02-07 17:38:38	2010-02-01 22:15:20.516094	2010-02-01 22:15:20.516094	2903976139718080_1.jpg	image/jpg	1161	2010-02-01 22:15:20.392182
710	23	DE	EUR	*COMMODORE AMIGA-A500*+ FLOPPY DISK - DRIVE um 1 EURO!!	http://cgi.ebay.de/COMMODORE-AMIGA-A500-FLOPPY-DISK-DRIVE-um-1-EURO_W0QQitemZ380201762128QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3802017621288080_1.jpg	380201762128	average	complete with extras	\N	2010-02-07 17:43:38	2010-02-01 22:15:36.154145	2010-02-01 22:15:36.154145	3802017621288080_1.jpg	image/jpg	1088	2010-02-01 22:15:36.028126
711	55	DE	EUR	C64 Commodore Brotkasten***TOP*** weisse Tastatur 	http://cgi.ebay.de/C64-Commodore-Brotkasten-TOP-weisse-Tastatur_W0QQitemZ280457868602QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2804578686028080_1.jpg	280457868602	good	complete	\N	2010-02-07 18:08:14	2010-02-01 22:15:54.885636	2010-02-01 22:15:54.885636	2804578686028080_1.jpg	image/jpg	928	2010-02-01 22:15:54.764992
712	3	DE	EUR	Commodore C64 C 64 Floppy 1541 Joystick Brotkasten TOP	http://cgi.ebay.de/Commodore-C64-C-64-Floppy-1541-Joystick-Brotkasten-TOP_W0QQitemZ330400627334QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3304006273348080_1.jpg	330400627334	average	complete with extras	\N	2010-02-07 18:16:14	2010-02-01 22:16:06.226679	2010-02-01 22:16:06.226679	3304006273348080_1.jpg	image/jpg	1090	2010-02-01 22:16:06.120514
714	62	DE	EUR	Commodore Amiga CD 32 Bit Konsole Selten und GUT @OKAY@	http://cgi.ebay.de/Commodore-Amiga-CD-32-Bit-Konsole-Selten-und-GUT-OKAY_W0QQitemZ330400635890QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3304006358908080_1.jpg	330400635890	good	complete	\N	2010-02-07 18:35:58	2010-02-01 22:16:38.109916	2010-02-01 22:16:38.109916	3304006358908080_1.jpg	image/jpg	1014	2010-02-01 22:16:38.002345
715	29	DE	EUR	Commodore 64 !!! c64 Große Sammlung Sammler Set VC1541 	http://cgi.ebay.de/Commodore-64-c64-Grosse-Sammlung-Sammler-Set-VC1541_W0QQitemZ220548732056QQcategoryZ3545QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2205487320568080_1.jpg	220548732056	good	complete with extras	\N	2010-02-07 18:33:58	2010-02-01 22:16:55.436932	2010-02-01 22:16:55.436932	2205487320568080_1.jpg	image/jpg	1267	2010-02-01 22:16:55.320551
716	36	DE	EUR	Commodore Amiga 1200 "Top erhalten"	http://cgi.ebay.de/Commodore-Amiga-1200-Top-erhalten_W0QQitemZ280458426644QQcategoryZ8142QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2804584266448080_1.jpg	280458426644	good	complete	\N	2010-02-07 18:32:17	2010-02-01 22:17:07.994635	2010-02-01 22:17:07.994635	2804584266448080_1.jpg	image/jpg	1253	2010-02-01 22:17:07.883419
717	20	DE	EUR	Commodore Flobby 1541	http://cgi.ebay.de/Commodore-Flobby-1541_W0QQitemZ260546268608QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2605462686088080_1.jpg	260546268608	average	complete	\N	2010-02-07 18:45:23	2010-02-01 22:17:49.814983	2010-02-01 22:17:49.814983	2605462686088080_1.jpg	image/jpg	1016	2010-02-01 22:17:49.692214
718	24	DE	EUR	Commodore C128D, C 128 D, C128 D	http://cgi.ebay.de/Commodore-C128D-C-128-D-C128-D_W0QQitemZ220545793475QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2205457934758080_1.jpg	220545793475	good	complete	\N	2010-02-07 18:47:10	2010-02-01 22:18:24.074033	2010-02-01 22:18:24.074033	2205457934758080_1.jpg	image/jpg	1263	2010-02-01 22:18:23.956004
719	3	DE	EUR	Commodore C 64 Ovp + mit allen Zubehör alles Ovp	http://cgi.ebay.de/Commodore-C-64-Ovp-mit-allen-Zubehoer-alles-Ovp_W0QQitemZ250572801259QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2505728012598080_1.jpg	250572801259	good	boxed with extras	\N	2010-02-07 18:53:38	2010-02-01 22:18:59.233372	2010-02-01 22:18:59.233372	2505728012598080_1.jpg	image/jpg	1527	2010-02-01 22:18:59.116197
720	24	DE	EUR	Commodore C128D, C 128 D, C128 D - defekt	http://cgi.ebay.de/Commodore-C128D-C-128-D-C128-D-defekt_W0QQitemZ220548949373QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2205489493738080_1.jpg	220548949373	poor	complete	\N	2010-02-07 18:59:51	2010-02-01 22:19:11.48247	2010-02-01 22:19:11.48247	2205489493738080_1.jpg	image/jpg	870	2010-02-01 22:19:11.371022
721	29	DE	EUR	Commodore C64 inkl. Zubehör(Floppy-Laufwerk, Datasette)	http://cgi.ebay.de/Commodore-C64-inkl-Zubehoer-Floppy-Laufwerk-Datasette_W0QQitemZ290396133976QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2903961339768080_1.jpg	290396133976	average	complete	\N	2010-02-07 19:02:28	2010-02-01 22:19:26.525836	2010-02-01 22:19:26.525836	2903961339768080_1.jpg	image/jpg	1216	2010-02-01 22:19:26.255369
722	55	DE	EUR	Commodore C64 mit 2 Joystiks 3 spiele Anleitung neu	http://cgi.ebay.de/Commodore-C64-mit-2-Joystiks-3-spiele-Anleitung-neu_W0QQitemZ190368960694QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1903689606948080_1.jpg	190368960694	good	complete with extras	\N	2010-02-07 19:07:41	2010-02-01 22:19:42.567034	2010-02-01 22:19:42.567034	1903689606948080_1.jpg	image/jpg	1092	2010-02-01 22:19:42.455125
723	55	DE	EUR	Commodore 64 (G) "Sehr gepflegtes Komplettpaket"	http://cgi.ebay.de/Commodore-64-G-Sehr-gepflegtes-Komplettpaket_W0QQitemZ280457341133QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2804573411338080_1.jpg	280457341133	good	complete with extras	\N	2010-02-07 19:09:49	2010-02-01 22:19:55.964618	2010-02-01 22:19:55.964618	2804573411338080_1.jpg	image/jpg	1224	2010-02-01 22:19:55.846417
724	3	DE	EUR	Commodore C64	http://cgi.ebay.de/Commodore-C64_W0QQitemZ130362340968QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1303623409688080_1.jpg	130362340968	average	complete with extras	\N	2010-02-07 19:12:26	2010-02-01 22:20:09.68116	2010-02-01 22:20:09.68116	1303623409688080_1.jpg	image/jpg	1082	2010-02-01 22:20:09.550865
725	62	DE	EUR	Commodore CD32 auf  Amiga 1200 Basis mit SX32 !	http://cgi.ebay.de/Commodore-CD32-auf-Amiga-1200-Basis-mit-SX32_W0QQitemZ200433242357QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004332423578080_1.jpg	200433242357	good	complete	\N	2010-02-07 19:12:36	2010-02-01 22:20:24.558048	2010-02-01 22:20:24.558048	2004332423578080_1.jpg	image/jpg	849	2010-02-01 22:20:24.431045
726	29	DE	EUR	029  Commodore C64	http://cgi.ebay.de/029-Commodore-C64_W0QQitemZ140379561594QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1403795615948080_1.jpg	140379561594	good	complete with extras	\N	2010-02-07 19:25:11	2010-02-01 22:20:47.072618	2010-02-01 22:20:47.072618	1403795615948080_1.jpg	image/jpg	1240	2010-02-01 22:20:46.954716
727	29	DE	EUR	Commodore C 64 + Monitor, Floppy, Anleitung, Spiele TOP	http://cgi.ebay.de/Commodore-C-64-Monitor-Floppy-Anleitung-Spiele-TOP_W0QQitemZ300392458395QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003924583958080_1.jpg	300392458395	good	complete with extras	\N	2010-02-07 19:30:42	2010-02-01 22:21:02.657137	2010-02-01 22:21:02.657137	3003924583958080_1.jpg	image/jpg	1184	2010-02-01 22:21:02.545545
728	4	DE	EUR	Commodore VC20	http://cgi.ebay.de/Commodore-VC20_W0QQitemZ270522647638QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705226476388080_1.jpg	270522647638	poor	complete	\N	2010-02-07 20:03:07	2010-02-01 22:21:12.261052	2010-02-01 22:21:12.261052	2705226476388080_1.jpg	image/jpg	1270	2010-02-01 22:21:12.14203
729	3	DE	EUR	Commodore c64 Brotkasten	http://cgi.ebay.de/Commodore-c64-Brotkasten_W0QQitemZ270522652712QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2705226527128080_1.jpg	270522652712	poor	bare	\N	2010-02-07 20:09:48	2010-02-01 22:21:22.983444	2010-02-01 22:21:22.983444	2705226527128080_1.jpg	image/jpg	1162	2010-02-01 22:21:22.867783
730	3	DE	EUR	Commodore C64 ,Sammlung, Floppy, Disketen , 2Joysticks	http://cgi.ebay.de/Commodore-C64-Sammlung-Floppy-Disketen-2Joysticks_W0QQitemZ130362632497QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1303626324978080_1.jpg	130362632497	average	complete with extras	\N	2010-02-07 20:10:23	2010-02-01 22:21:34.757203	2010-02-01 22:21:34.757203	1303626324978080_1.jpg	image/jpg	1134	2010-02-01 22:21:34.641707
731	63	DE	EUR	Commodore C 116 c116 Datasette u. Spiele ORIGINALKARTON	http://cgi.ebay.de/Commodore-C-116-c116-Datasette-u-Spiele-ORIGINALKARTON_W0QQitemZ150410270185QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1504102701858080_1.jpg	150410270185	good	boxed with extras	\N	2010-02-07 20:10:33	2010-02-01 22:21:48.216156	2010-02-01 22:21:48.216156	1504102701858080_1.jpg	image/jpg	1241	2010-02-01 22:21:48.104351
732	3	DE	EUR	___ COMMODORE C64 Computer mit Extra C-64 TOP retro ___	http://cgi.ebay.de/COMMODORE-C64-Computer-mit-Extra-C-64-TOP-retro_W0QQitemZ370328647564QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3703286475648080_1.jpg	370328647564	poor	complete	\N	2010-02-07 20:28:51	2010-02-01 22:21:58.330236	2010-02-01 22:21:58.330236	3703286475648080_1.jpg	image/jpg	687	2010-02-01 22:21:58.218937
733	3	DE	EUR	Commodore C 64 mit viel Zubehör 100 % funktionsfähig	http://cgi.ebay.de/Commodore-C-64-mit-viel-Zubehoer-100-funktionsfaehig_W0QQitemZ170438867223QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1704388672238080_1.jpg	170438867223	average	boxed with extras	\N	2010-02-07 20:33:51	2010-02-01 22:22:10.047311	2010-02-01 22:22:10.047311	1704388672238080_1.jpg	image/jpg	1428	2010-02-01 22:22:09.925962
734	6	DE	EUR	   COMMODORE C16 Computer mit Zubehör und Spiele TOP   	http://cgi.ebay.de/COMMODORE-C16-Computer-mit-Zubehoer-und-Spiele-TOP_W0QQitemZ370328650430QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3703286504308080_1.jpg	370328650430	average	boxed with extras	\N	2010-02-07 20:33:55	2010-02-01 22:22:23.834817	2010-02-01 22:22:23.834817	3703286504308080_1.jpg	image/jpg	1258	2010-02-01 22:22:23.71868
735	15	DE	EUR	Commodore 610   / Amiga / C 64 /	http://cgi.ebay.de/Commodore-610-Amiga-C-64_W0QQitemZ170438867319QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1704388673198080_1.jpg	170438867319	average	complete	\N	2010-02-07 20:33:57	2010-02-01 22:22:37.078545	2010-02-01 22:22:37.078545	1704388673198080_1.jpg	image/jpg	856	2010-02-01 22:22:36.953602
736	65	DE	EUR	2 Commodore Amiga 600 A 600	http://cgi.ebay.de/2-Commodore-Amiga-600-A-600_W0QQitemZ170438868673QQcategoryZ8142QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704388686738080_1.jpg	170438868673	poor	complete with extras	\N	2010-02-07 20:35:37	2010-02-01 22:22:51.063561	2010-02-01 22:22:51.063561	1704388686738080_1.jpg	image/jpg	932	2010-02-01 22:22:50.954615
737	21	DE	EUR	Commodore 1541-II mit Netzteil	http://cgi.ebay.de/Commodore-1541-II-mit-Netzteil_W0QQitemZ270524208709QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2705242087098080_1.jpg	270524208709	average	complete	\N	2010-02-07 21:04:49	2010-02-01 22:22:57.561451	2010-02-01 22:22:57.561451	2705242087098080_1.jpg	image/jpg	960	2010-02-01 22:22:57.445154
738	20	DE	EUR	Commodore 1541 Floppy	http://cgi.ebay.de/Commodore-1541-Floppy_W0QQitemZ270524210369QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2705242103698080_1.jpg	270524210369	poor	complete	\N	2010-02-07 21:07:42	2010-02-01 22:23:17.992204	2010-02-01 22:23:17.992204	2705242103698080_1.jpg	image/jpg	940	2010-02-01 22:23:17.870743
739	29	DE	EUR	Commodore C 64 C-64 - II Computer 	http://cgi.ebay.de/Commodore-C-64-C-64-II-Computer_W0QQitemZ270524212082QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705242120828080_1.jpg	270524212082	poor	complete	\N	2010-02-07 21:10:35	2010-02-01 22:23:28.370574	2010-02-01 22:23:28.370574	2705242120828080_1.jpg	image/jpg	1039	2010-02-01 22:23:28.261967
740	3	DE	EUR	Commodore C 64 C-64  Computer 	http://cgi.ebay.de/Commodore-C-64-C-64-Computer_W0QQitemZ270524213222QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705242132228080_1.jpg	270524213222	average	bare	\N	2010-02-07 21:12:21	2010-02-01 22:23:40.434827	2010-02-01 22:23:40.434827	2705242132228080_1.jpg	image/jpg	981	2010-02-01 22:23:40.254425
741	23	DE	EUR	Commodore Amiga	http://cgi.ebay.de/Commodore-Amiga_W0QQitemZ180463920601QQcategoryZ151997QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1804639206018080_1.jpg	180463920601	average	complete with extras	\N	2010-02-07 22:25:58	2010-02-01 22:24:13.744132	2010-02-01 22:24:13.744132	1804639206018080_1.jpg	image/jpg	933	2010-02-01 22:24:13.614209
742	55	DE	EUR	Commodore C 64 mit Laufwerk, Drucker, Spiele & Joystik	http://cgi.ebay.de/Commodore-C-64-mit-Laufwerk-Drucker-Spiele-Joystik_W0QQitemZ200434650624QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2004346506248080_1.jpg	200434650624	average	complete with extras	\N	2010-02-08 07:25:01	2010-02-01 22:24:25.910443	2010-02-01 22:24:25.910443	2004346506248080_1.jpg	image/jpg	1121	2010-02-01 22:24:25.792258
743	7	DE	EUR	Commodore C 128	http://cgi.ebay.de/Commodore-C-128_W0QQitemZ290397868413QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2903978684138080_1.jpg	290397868413	good	complete	\N	2010-02-08 08:29:23	2010-02-01 22:24:36.01301	2010-02-01 22:24:36.01301	2903978684138080_1.jpg	image/jpg	1020	2010-02-01 22:24:35.897576
744	21	DE	EUR	Commodore 1541-II ** Komplett-Set ** [02/03]	http://cgi.ebay.de/Commodore-1541-II-Komplett-Set-02-03_W0QQitemZ350310419697QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3503104196978080_1.jpg	350310419697	good	complete	\N	2010-02-27 07:28:16	2010-02-01 22:24:50.244793	2010-02-01 22:24:50.244793	3503104196978080_1.jpg	image/jpg	1017	2010-02-01 22:24:50.12603
745	29	DE	EUR	Commodore 64 C mit Netzteil 100% OK C64 C 	http://cgi.ebay.de/Commodore-64-C-mit-Netzteil-100-OK-C64-C_W0QQitemZ370328571024QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3703285710248080_1.jpg	370328571024	poor	complete	\N	2010-02-03 18:26:20	2010-02-01 22:25:09.936592	2010-02-01 22:25:09.936592	3703285710248080_1.jpg	image/jpg	1164	2010-02-01 22:25:09.798613
746	3	DE	EUR	Commodore C 64 + Floppy-Disk + Netzteil für Bastler	http://cgi.ebay.de/Commodore-C-64-Floppy-Disk-Netzteil-fuer-Bastler_W0QQitemZ300392779578QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3003927795788080_1.jpg	300392779578	poor	complete with extras	\N	2010-02-08 18:40:18	2010-02-01 22:25:19.293703	2010-02-01 22:25:19.293703	3003927795788080_1.jpg	image/jpg	1174	2010-02-01 22:25:19.163902
747	23	DE	EUR	Commodore Amiga 500, Netzteil, Spiele, Maus, Disketten	http://cgi.ebay.de/Commodore-Amiga-500-Netzteil-Spiele-Maus-Disketten_W0QQitemZ300392784399QQcategoryZ8142QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3003927843998080_1.jpg	300392784399	poor	complete with extras	\N	2010-02-08 18:53:39	2010-02-01 22:25:29.826695	2010-02-01 22:25:29.826695	3003927843998080_1.jpg	image/jpg	1299	2010-02-01 22:25:29.714289
748	20	DE	EUR	Altes Diskettenlaufwerk für Commodore Computer 154i	http://cgi.ebay.de/Altes-Diskettenlaufwerk-fuer-Commodore-Computer-154i_W0QQitemZ330399993614QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3303999936148080_1.jpg	330399993614	average	complete	\N	2010-02-08 19:00:13	2010-02-01 22:25:40.320886	2010-02-01 22:25:40.320886	3303999936148080_1.jpg	image/jpg	1150	2010-02-01 22:25:40.20469
749	41	DE	EUR	Commodore 720, Sammler, PC, Computer, rar	http://cgi.ebay.de/Commodore-720-Sammler-PC-Computer-rar_W0QQitemZ290398057941QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2903980579418080_1.jpg	290398057941	average	complete	\N	2010-02-08 19:34:49	2010-02-01 22:26:45.419966	2010-02-01 22:26:45.419966	2903980579418080_1.jpg	image/jpg	1253	2010-02-01 22:26:45.304967
750	29	DE	EUR	Commodore 64  Personal Computer	http://cgi.ebay.de/Commodore-64-Personal-Computer_W0QQitemZ290396981656QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2903969816568080_1.jpg	290396981656	average	complete	\N	2010-02-08 20:01:03	2010-02-01 22:26:58.488426	2010-02-01 22:26:58.488426	2903969816568080_1.jpg	image/jpg	978	2010-02-01 22:26:58.361166
751	29	DE	EUR	Commodore 64	http://cgi.ebay.de/Commodore-64_W0QQitemZ270523379077QQcategoryZ1487QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2705233790778080_1.jpg	270523379077	good	complete with extras	\N	2010-02-09 10:02:18	2010-02-01 22:27:17.173324	2010-02-01 22:27:17.173324	2705233790778080_1.jpg	image/jpg	1226	2010-02-01 22:27:17.061579
752	21	DE	EUR	Commodore 1541 II Single Floppy Disk Drive für C64 C128	http://cgi.ebay.de/Commodore-1541-II-Single-Floppy-Disk-Drive-fuer-C64-C128_W0QQitemZ160399348754QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1603993487548080_1.jpg	160399348754	poor	complete	\N	2010-02-27 21:45:00	2010-02-01 22:27:27.93179	2010-02-01 22:27:27.93179	1603993487548080_1.jpg	image/jpg	1115	2010-02-01 22:27:27.822451
753	21	DE	EUR	Commodore C64 Floppy Laufwerk 1541-II	http://cgi.ebay.de/Commodore-C64-Floppy-Laufwerk-1541-II_W0QQitemZ350310928928QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3503109289288080_1.jpg	350310928928	average	complete	\N	2010-02-28 16:17:49	2010-02-01 22:27:39.541138	2010-02-01 22:27:39.541138	3503109289288080_1.jpg	image/jpg	1123	2010-02-01 22:27:39.418017
754	24	DE	EUR	Commodore C 128 D, 128D, C128D, 128 mit Software	http://cgi.ebay.de/Commodore-C-128-D-128D-C128D-128-mit-Software_W0QQitemZ110488156749QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1104881567498080_1.jpg	110488156749	average	complete	\N	2010-02-09 18:16:11	2010-02-01 22:27:55.127097	2010-02-01 22:27:55.127097	1104881567498080_1.jpg	image/jpg	1010	2010-02-01 22:27:55.009499
755	29	DE	EUR	Commodore 64, C64, C 64 mit Floppy, Drucker, TV Tuner 	http://cgi.ebay.de/Commodore-64-C64-C-64-mit-Floppy-Drucker-TV-Tuner_W0QQitemZ110488166110QQcategoryZ3544QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1104881661108080_1.jpg	110488166110	average	complete with extras	\N	2010-02-09 18:46:18	2010-02-01 22:28:08.486335	2010-02-01 22:28:08.486335	1104881661108080_1.jpg	image/jpg	1040	2010-02-01 22:28:08.370256
756	22	DE	EUR	Commodore 1581 Diskettenlaufwerk für C64 / C128	http://cgi.ebay.de/Commodore-1581-Diskettenlaufwerk-fuer-C64-C128_W0QQitemZ160397980984QQcategoryZ3544QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1603979809848080_1.jpg	160397980984	good	complete	\N	2010-02-03 09:53:56	2010-02-01 22:28:27.784786	2010-02-01 22:28:27.784786	1603979809848080_1.jpg	image/jpg	1356	2010-02-01 22:28:27.672182
757	21	DE	EUR	Commodore 1541 II Diskettenlaufwerk 	http://cgi.ebay.de/Commodore-1541-II-Diskettenlaufwerk_W0QQitemZ160400215329QQcategoryZ3544QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1604002153298080_1.jpg	160400215329	good	complete	\N	2010-02-07 21:14:12	2010-02-01 22:28:41.352239	2010-02-01 22:28:41.352239	1604002153298080_1.jpg	image/jpg	1432	2010-02-01 22:28:41.23757
758	21	DE	EUR	Commodore 1541-II  Bundle ** no yellowing ** l@@k! (46)	http://cgi.ebay.de/Commodore-1541-II-Bundle-no-yellowing-l-k-46_W0QQitemZ350311188887QQcategoryZ3544QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3503111888878080_1.jpg	350311188887	good	complete	\N	2010-03-01 10:41:17	2010-02-01 22:28:57.528089	2010-02-01 22:28:57.528089	3503111888878080_1.jpg	image/jpg	1111	2010-02-01 22:28:57.410084
759	23	ES	EUR	COMMODORE AMIGA 500 para piezas	http://cgi.ebay.es/COMMODORE-AMIGA-500-para-piezas_W0QQitemZ300391904530QQcategoryZ89183QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3003919045308080_1.jpg	300391904530	poor	bare	\N	2010-02-01 22:37:03	2010-02-01 22:30:36.433404	2010-02-01 22:30:36.433404	3003919045308080_1.jpg	image/jpg	917	2010-02-01 22:30:36.31037
760	3	ES	EUR	ORDENADOR COMMODORE 64	http://cgi.ebay.es/ORDENADOR-COMMODORE-64_W0QQitemZ300392299914QQcategoryZ89183QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3003922999148080_1.jpg	300392299914	good	complete	\N	2010-02-03 10:31:49	2010-02-01 22:30:54.414389	2010-02-01 22:30:54.414389	3003922999148080_1.jpg	image/jpg	853	2010-02-01 22:30:54.301098
761	36	ES	EUR	Commodore Amiga 1200	http://cgi.ebay.es/Commodore-Amiga-1200_W0QQitemZ220547939347QQcategoryZ89183QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2205479393478080_1.jpg	220547939347	good	complete	\N	2010-02-04 20:26:42	2010-02-01 22:31:22.47104	2010-02-01 22:31:22.47104	2205479393478080_1.jpg	image/jpg	1226	2010-02-01 22:31:22.361805
762	29	ES	EUR	Commodore 64 + 1 Juego	http://cgi.ebay.es/Commodore-64-1-Juego_W0QQitemZ130362616324QQcategoryZ50227QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1303626163248080_1.jpg	130362616324	good	complete with extras	\N	2010-02-07 19:40:01	2010-02-01 22:31:47.205341	2010-02-01 22:31:47.205341	1303626163248080_1.jpg	image/jpg	876	2010-02-01 22:31:47.078936
763	29	ES	EUR	COMMODORE 64 CON GRABADORA, INSTRUC.Y ACCESORIOS VARIOS	http://cgi.ebay.es/COMMODORE-64-CON-GRABADORA-INSTRUC-Y-ACCESORIOS-VARIOS_W0QQitemZ160399258768QQcategoryZ89183QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1603992587688080_1.jpg	160399258768	good	complete with extras	\N	2010-02-07 21:08:47	2010-02-01 22:31:58.347203	2010-02-01 22:31:58.347203	1603992587688080_1.jpg	image/jpg	1040	2010-02-01 22:31:58.227821
764	3	ES	EUR	►Vintage COMMODORE C64 C Teclas Blancas Made In Japan★	http://cgi.ebay.es/Vintage-COMMODORE-C64-C-Teclas-Blancas-Made-In-Japan_W0QQitemZ370321902274QQcategoryZ89183QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/3703219022748080_1.jpg	370321902274	poor	complete with extras	\N	2010-02-16 18:16:50	2010-02-01 22:33:13.910615	2010-02-01 22:33:13.910615	3703219022748080_1.jpg	image/jpg	1540	2010-02-01 22:33:13.787606
765	3	ES	EUR	Ordenador Commodore 64 + Alimentador. Perfecto	http://cgi.ebay.es/Ordenador-Commodore-64-Alimentador-Perfecto_W0QQitemZ170435565586QQcategoryZ89183QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704355655868080_1.jpg	170435565586	average	complete	\N	2010-02-20 17:45:27	2010-02-01 22:33:34.37076	2010-02-01 22:33:34.37076	1704355655868080_1.jpg	image/jpg	898	2010-02-01 22:33:34.242662
766	55	ES	EUR	Ordenador Commodore 64G blanco con teclado SPANISH	http://cgi.ebay.es/Ordenador-Commodore-64G-blanco-con-teclado-SPANISH_W0QQitemZ170435565606QQcategoryZ89183QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704355656068080_1.jpg	170435565606	average	complete	\N	2010-02-20 17:45:30	2010-02-01 22:33:50.019214	2010-02-01 22:33:50.019214	1704355656068080_1.jpg	image/jpg	1203	2010-02-01 22:33:49.918489
767	66	ES	EUR	COMMODORE MAX MACHINE BOXED+ BASIC FUNCIONANDO 100% OK	http://cgi.ebay.es/COMMODORE-MAX-MACHINE-BOXED-BASIC-FUNCIONANDO-100-OK_W0QQitemZ220545400116QQcategoryZ89183QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2205454001168080_1.jpg	220545400116	poor	boxed	\N	2010-02-22 20:25:31	2010-02-01 22:36:02.828076	2010-02-01 22:36:02.828076	2205454001168080_1.jpg	image/jpg	1199	2010-02-01 22:36:02.711142
768	23	ES	EUR	Commodore Amiga 500 + accesorios	http://cgi.ebay.es/Commodore-Amiga-500-accesorios_W0QQitemZ170439243635QQcategoryZ89183QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1704392436358080_1.jpg	170439243635	average	bare	\N	2010-02-28 17:56:58	2010-02-01 22:36:19.042929	2010-02-01 22:36:19.042929	1704392436358080_1.jpg	image/jpg	1083	2010-02-01 22:36:18.926256
769	3	ES	EUR	COMMODORE 64 COMPLETO FUNCIONANDO 100% OK	http://cgi.ebay.es/COMMODORE-64-COMPLETO-FUNCIONANDO-100-OK_W0QQitemZ220549762600QQcategoryZ89183QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2205497626008080_1.jpg	220549762600	poor	complete	\N	2010-03-03 12:44:05	2010-02-01 22:36:56.35586	2010-02-01 22:36:56.35586	2205497626008080_1.jpg	image/jpg	1261	2010-02-01 22:36:56.237058
770	6	ES	EUR	COMMODORE 16 C16 BOXED FUNCIONANDO 100% OK	http://cgi.ebay.es/COMMODORE-16-C16-BOXED-FUNCIONANDO-100-OK_W0QQitemZ220549763138QQcategoryZ89183QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2205497631388080_1.jpg	220549763138	poor	boxed	\N	2010-03-03 12:45:29	2010-02-01 22:37:13.745006	2010-02-01 22:37:13.745006	2205497631388080_1.jpg	image/jpg	1328	2010-02-01 22:37:13.643661
771	3	FR	EUR	Commodore 64 avec accessoires et jeux	http://cgi.ebay.fr/Commodore-64-avec-accessoires-et-jeux_W0QQitemZ250571624245QQcategoryZ113190QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2505716242458080_1.jpg	250571624245	average	complete with extras	\N	2010-02-03 11:50:58	2010-02-01 22:37:44.00796	2010-02-01 22:37:44.00796	2505716242458080_1.jpg	image/jpg	1381	2010-02-01 22:37:43.884671
772	64	FR	EUR	Commodore Plus/4 en boite - Complet - Parfait état	http://cgi.ebay.fr/Commodore-Plus-4-en-boite-Complet-Parfait-etat_W0QQitemZ160398728405QQcategoryZ113190QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1603987284058080_1.jpg	160398728405	poor	boxed	\N	2010-02-05 19:02:31	2010-02-01 22:37:59.751399	2010-02-01 22:37:59.751399	1603987284058080_1.jpg	image/jpg	908	2010-02-01 22:37:59.640865
773	3	FR	EUR	COMMODORE 64 + Lect. 1541 + Disquettes + Accessoires	http://cgi.ebay.fr/COMMODORE-64-Lect-1541-Disquettes-Accessoires_W0QQitemZ200434859815QQcategoryZ113190QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/2004348598158080_1.jpg	200434859815	poor	boxed with extras	\N	2010-02-11 20:07:45	2010-02-01 22:38:24.107724	2010-02-01 22:38:24.107724	2004348598158080_1.jpg	image/jpg	1377	2010-02-01 22:38:23.96609
774	6	IT	EUR	Commodore 16 funzionante con scatola in polistirolo	http://cgi.ebay.it/Commodore-16-funzionante-con-scatola-in-polistirolo_W0QQitemZ170437624340QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1704376243408080_1.jpg	170437624340	good	complete	\N	2010-02-02 08:53:04	2010-02-01 22:39:14.847396	2010-02-01 22:39:14.847396	1704376243408080_1.jpg	image/jpg	1059	2010-02-01 22:39:14.655728
775	3	IT	EUR	Commodore 64 funzionante + Floppy 1541	http://cgi.ebay.it/Commodore-64-funzionante-Floppy-1541_W0QQitemZ170437638241QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704376382418080_1.jpg	170437638241	average	complete with extras	\N	2010-02-02 10:02:26	2010-02-01 22:39:34.696686	2010-02-01 22:39:34.696686	1704376382418080_1.jpg	image/jpg	1134	2010-02-01 22:39:34.576689
776	6	IT	EUR	Commodore 16 funzionante in confezione originale	http://cgi.ebay.it/Commodore-16-funzionante-in-confezione-originale_W0QQitemZ170437644311QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1704376443118080_1.jpg	170437644311	good	boxed	\N	2010-02-02 10:29:13	2010-02-01 22:39:58.767387	2010-02-01 22:39:58.767387	1704376443118080_1.jpg	image/jpg	1155	2010-02-01 22:39:58.651664
777	6	IT	EUR	Commodore 16 funzionante	http://cgi.ebay.it/Commodore-16-funzionante_W0QQitemZ170437653745QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704376537458080_1.jpg	170437653745	average	complete	\N	2010-02-02 11:08:13	2010-02-01 22:40:15.649201	2010-02-01 22:40:15.649201	1704376537458080_1.jpg	image/jpg	1194	2010-02-01 22:40:15.529897
778	29	IT	EUR	Commodore 64 C funzionante con scatola originale	http://cgi.ebay.it/Commodore-64-C-funzionante-con-scatola-originale_W0QQitemZ170437707053QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1704377070538080_1.jpg	170437707053	poor	boxed	\N	2010-02-02 13:40:29	2010-02-01 22:40:36.564261	2010-02-01 22:40:36.564261	1704377070538080_1.jpg	image/jpg	898	2010-02-01 22:40:36.449685
779	64	IT	EUR	Commodore Plus 4 boxed + datassette	http://cgi.ebay.it/Commodore-Plus-4-boxed-datassette_W0QQitemZ130361516940QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1303615169408080_1.jpg	130361516940	good	boxed with extras	\N	2010-02-03 17:48:50	2010-02-01 22:41:26.00817	2010-02-01 22:41:26.00817	1303615169408080_1.jpg	image/jpg	1038	2010-02-01 22:41:25.885547
780	62	IT	EUR	COMMODORE AMIGA CD32 CON FULL MOTION VIDEO MODULE	http://cgi.ebay.it/COMMODORE-AMIGA-CD32-CON-FULL-MOTION-VIDEO-MODULE_W0QQitemZ260542917065QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605429170658080_1.jpg	260542917065	good	complete	\N	2010-02-03 18:02:05	2010-02-01 22:42:03.133261	2010-02-01 22:42:03.133261	2605429170658080_1.jpg	image/jpg	1282	2010-02-01 22:42:03.017819
781	6	IT	EUR	RETROCOMPUTER  COMMODORE 16 con accessori	http://cgi.ebay.it/RETROCOMPUTER-COMMODORE-16-con-accessori_W0QQitemZ230429924009QQcategoryZ4598QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2304299240098080_1.jpg	230429924009	good	complete	\N	2010-02-03 20:38:26	2010-02-01 22:42:36.423259	2010-02-01 22:42:36.423259	2304299240098080_1.jpg	image/jpg	1185	2010-02-01 22:42:36.302622
782	3	IT	EUR	COMPUTER COMMODORE 64 ORIGINALE RETRO VINTAGE ANNI 80	http://cgi.ebay.it/COMPUTER-COMMODORE-64-ORIGINALE-RETRO-VINTAGE-ANNI-80_W0QQitemZ270520825950QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2705208259508080_1.jpg	270520825950	poor	bare	\N	2010-02-04 09:45:16	2010-02-01 22:43:28.217673	2010-02-01 22:43:28.217673	2705208259508080_1.jpg	image/jpg	1216	2010-02-01 22:43:28.091583
783	3	IT	EUR	COMMODORE 64 1a serie UK testato e funzionante //////	http://cgi.ebay.it/COMMODORE-64-1a-serie-UK-testato-e-funzionante_W0QQitemZ120522194667QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1205221946678080_1.jpg	120522194667	poor	complete with extras	\N	2010-02-03 21:04:00	2010-02-01 22:44:00.657741	2010-02-01 22:44:00.657741	1205221946678080_1.jpg	image/jpg	1523	2010-02-01 22:44:00.535929
784	23	IT	EUR	COMMODORE AMIGA A500	http://cgi.ebay.it/COMMODORE-AMIGA-A500_W0QQitemZ220547931913QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2205479319138080_1.jpg	220547931913	poor	bare	\N	2010-02-04 20:14:43	2010-02-01 22:44:17.577065	2010-02-01 22:44:17.577065	2205479319138080_1.jpg	image/jpg	647	2010-02-01 22:44:17.46562
785	29	IT	EUR	COMMODORE 64-FUNZIONANTE-SENZA ACESSORI COSI COME SI , 	http://cgi.ebay.it/COMMODORE-64-FUNZIONANTE-SENZA-ACESSORI-COSI-COME-SI_W0QQitemZ320482359337QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/3204823593378080_1.jpg	320482359337	good	complete	\N	2010-02-05 20:44:10	2010-02-01 22:45:26.470941	2010-02-01 22:45:26.470941	3204823593378080_1.jpg	image/jpg	925	2010-02-01 22:45:26.324595
786	65	IT	EUR	COMMODORE A600  + MOUSE + CAVO ALIMENTAZIONE 	http://cgi.ebay.it/COMMODORE-A600-MOUSE-CAVO-ALIMENTAZIONE_W0QQitemZ370327727911QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/3703277279118080_1.jpg	370327727911	poor	complete	\N	2010-02-05 21:04:59	2010-02-01 22:45:42.636474	2010-02-01 22:45:42.636474	3703277279118080_1.jpg	image/jpg	1071	2010-02-01 22:45:42.526924
787	29	IT	EUR	Commodore 64	http://cgi.ebay.it/Commodore-64_W0QQitemZ200434011985QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2004340119858080_1.jpg	200434011985	average	complete with extras	\N	2010-02-06 15:33:51	2010-02-01 22:45:58.96947	2010-02-01 22:45:58.96947	2004340119858080_1.jpg	image/jpg	1254	2010-02-01 22:45:58.852075
788	29	IT	EUR	COMMODORE 64 Seconda Edizione	http://cgi.ebay.it/COMMODORE-64-Seconda-Edizione_W0QQitemZ170440198578QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1704401985788080_1.jpg	170440198578	poor	complete	\N	2010-02-07 22:37:39	2010-02-01 22:46:21.465066	2010-02-01 22:46:21.465066	1704401985788080_1.jpg	image/jpg	847	2010-02-01 22:46:21.358042
789	65	IT	EUR	AMIGA 600 + MONITOR COLORI COMMODORE 1084S 	http://cgi.ebay.it/AMIGA-600-MONITOR-COLORI-COMMODORE-1084S_W0QQitemZ250573178938QQcategoryZ4598QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2505731789388080_1.jpg	250573178938	poor	complete with extras	\N	2010-02-08 11:03:52	2010-02-01 22:46:41.484711	2010-02-01 22:46:41.484711	2505731789388080_1.jpg	image/jpg	832	2010-02-01 22:46:41.361407
790	7	IT	EUR	COMMODORE 128 - RETROCOMPUTER INBOX PERFETTO -	http://cgi.ebay.it/COMMODORE-128-RETROCOMPUTER-INBOX-PERFETTO_W0QQitemZ320481234940QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/3204812349408080_1.jpg	320481234940	average	boxed with extras	\N	2010-02-08 11:29:51	2010-02-01 22:47:01.034145	2010-02-01 22:47:01.034145	3204812349408080_1.jpg	image/jpg	1246	2010-02-01 22:47:00.92462
791	21	IT	EUR	floppy disk  commodore 64 1541 II serie	http://cgi.ebay.it/floppy-disk-commodore-64-1541-II-serie_W0QQitemZ190369925152QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/1903699251528080_1.jpg	190369925152	poor	bare	\N	2010-02-08 17:52:27	2010-02-01 22:47:17.467988	2010-02-01 22:47:17.467988	1903699251528080_1.jpg	image/jpg	1058	2010-02-01 22:47:17.34669
792	8	IT	EUR	sinclair  ZX SPECTRUM  scatolo anni 80 commodore VIVE	http://cgi.ebay.it/sinclair-ZX-SPECTRUM-scatolo-anni-80-commodore-VIVE_W0QQitemZ190369014906QQcategoryZ3545QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/1903690149068080_1.jpg	190369014906	good	boxed	\N	2010-02-08 20:34:34	2010-02-01 22:48:09.749164	2010-02-01 22:48:09.749164	1903690149068080_1.jpg	image/jpg	1326	2010-02-01 22:48:09.63592
793	29	IT	EUR	COMMODORE C64C+Supply+ Recorder C2N+Lettore 1541 floppy	http://cgi.ebay.it/COMMODORE-C64C-Supply-Recorder-C2N-Lettore-1541-floppy_W0QQitemZ220547761800QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2205477618008080_1.jpg	220547761800	poor	complete with extras	\N	2010-02-08 20:35:14	2010-02-01 22:48:21.531691	2010-02-01 22:48:21.531691	2205477618008080_1.jpg	image/jpg	713	2010-02-01 22:48:21.399656
794	20	IT	EUR	COMMODORE - FLOPPY DISK 1541 CON CAVO	http://cgi.ebay.it/COMMODORE-FLOPPY-DISK-1541-CON-CAVO_W0QQitemZ110488650249QQcategoryZ74945QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/1104886502498080_1.jpg	110488650249	average	complete	\N	2010-02-10 20:56:29	2010-02-01 22:48:35.130127	2010-02-01 22:48:35.130127	1104886502498080_1.jpg	image/jpg	947	2010-02-01 22:48:34.957568
795	64	IT	EUR	COMMODORE PLUS/4 FUNZIONANTE	http://cgi.ebay.it/COMMODORE-PLUS-4-FUNZIONANTE_W0QQitemZ110488659799QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1104886597998080_1.jpg	110488659799	average	complete	\N	2010-02-10 21:14:43	2010-02-01 22:48:50.142556	2010-02-01 22:48:50.142556	1104886597998080_1.jpg	image/jpg	1099	2010-02-01 22:48:50.015484
796	4	IT	EUR	COMMODORE VIC 20 TASTI BEIGE IN BOX FUNZIONANTE!!!!!!!!	http://cgi.ebay.it/COMMODORE-VIC-20-TASTI-BEIGE-IN-BOX-FUNZIONANTE_W0QQitemZ130363688127QQcategoryZ74945QQcmdZViewItem	http://thumbs4.ebaystatic.com/pict/1303636881278080_1.jpg	130363688127	average	boxed	\N	2010-02-11 12:40:54	2010-02-01 22:49:25.752917	2010-02-01 22:49:25.752917	1303636881278080_1.jpg	image/jpg	995	2010-02-01 22:49:25.621973
797	25	IT	EUR	DRIVE COMMODORE 1541	http://cgi.ebay.it/DRIVE-COMMODORE-1541_W0QQitemZ260546781965QQcategoryZ4193QQcmdZViewItem	http://thumbs2.ebaystatic.com/pict/2605467819658080_1.jpg	260546781965	poor	complete	\N	2010-02-11 17:38:42	2010-02-01 22:49:40.788658	2010-02-01 22:49:40.788658	2605467819658080_1.jpg	image/jpg	1074	2010-02-01 22:49:40.671942
798	29	IT	EUR	Commodore 64 completo di registratore perfetto!!	http://cgi.ebay.it/Commodore-64-completo-di-registratore-perfetto_W0QQitemZ200429804206QQcategoryZ74945QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2004298042068080_1.jpg	200429804206	poor	complete with extras	\N	2010-02-17 18:54:29	2010-02-01 22:50:02.452386	2010-02-01 22:50:02.452386	2004298042068080_1.jpg	image/jpg	1268	2010-02-01 22:50:02.328929
799	3	IT	EUR	RETROCOMPUTER COMMODORE 64 1° versione CON ACCESSORI 	http://cgi.ebay.it/RETROCOMPUTER-COMMODORE-64-1-versione-CON-ACCESSORI_W0QQitemZ230429922604QQcategoryZ74945QQcmdZViewItem	http://thumbs1.ebaystatic.com/pict/2304299226048080_1.jpg	230429922604	average	complete	\N	2010-02-26 20:40:42	2010-02-01 22:50:29.096399	2010-02-01 22:50:29.096399	2304299226048080_1.jpg	image/jpg	948	2010-02-01 22:50:28.962304
589	53	CA	CAD	Macintosh Mac SE M5010 2.5mb Ram 50mb Hard Drive OS 7.1	http://cgi.ebay.ca/Macintosh-Mac-SE-M5010-2-5mb-Ram-50mb-Hard-Drive-OS-7-1_W0QQitemZ260545471618QQcategoryZ80075QQcmdZViewItem	http://thumbs3.ebaystatic.com/pict/2605454716188080_1.jpg	260545471618	average	complete	106.55	2010-02-01 22:23:33	2010-02-01 18:53:02.387563	2010-02-02 00:18:03.045685	2605454716188080_1.jpg	image/jpg	979	2010-02-01 18:53:02.253587
\.


--
-- Data for Name: builtin_languages; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY builtin_languages (name, created_at, updated_at, permalink) FROM stdin;
Applesoft Basic	2010-01-08 02:56:55.259289	2010-01-13 10:21:38.229725	applesoft-basic
Microsoft Basic	2010-01-08 02:56:55.263453	2010-01-13 10:21:38.240632	microsoft-basic
Basic	2010-01-08 02:56:55.267538	2010-01-13 10:21:38.255691	basic
Commodore BASIC	2010-01-11 10:19:18.943342	2010-01-13 10:21:38.259482	commodore-basic
Sinclair BASIC	2010-01-13 17:57:19.427584	2010-01-13 17:57:19.427584	sinclair-basic
8080 assembler	2010-01-17 21:29:04.394024	2010-01-17 21:29:04.394024	8080-assembler
\.


--
-- Data for Name: builtin_storages; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY builtin_storages (id, storage_name_id, storage_format_id, storage_size_id, created_at, updated_at) FROM stdin;
4	tape drive	audiocassette		2010-01-11 10:37:00.049258	2010-01-11 10:37:00.049258
7	floppy disk drive	3.5'' Single Side	400Kb	2010-01-18 13:02:51.807306	2010-01-18 13:02:51.807306
2	floppy disk drive	5.25" Double Side	360Kb	2010-01-08 02:56:55.65317	2010-01-19 01:51:32.431902
3	floppy disk drive	3.5" Double Side	880Kb	2010-01-11 00:00:41.985681	2010-01-19 01:51:41.998846
5	floppy disk drive	5.25" Single Side	140Kb	2010-01-13 18:47:37.348144	2010-01-19 01:51:53.55917
6	floppy disk drive	5.25" Double Side	1Mb	2010-01-17 14:49:13.863944	2010-01-19 01:52:08.149927
8	floppy disk drive	5.25" Single Side	170Kb	2010-01-21 04:00:16.991444	2010-01-21 04:00:16.991444
9	floppy disk drive	3.5" Double Side	800Kb	2010-01-21 11:23:32.433879	2010-01-21 11:23:32.433879
11	hard disk drive	SCSI	40Mb	2010-01-28 21:24:32.35947	2010-01-28 21:25:21.94551
10	hard disk drive	SCSI	20Mb	2010-01-28 21:24:23.043721	2010-01-28 21:26:24.089035
12	floppy disk drive	3.5" Double Side	1.6Mb	2010-01-28 21:32:35.59027	2010-01-28 21:32:35.59027
\.


--
-- Data for Name: builtin_storages_hardware; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY builtin_storages_hardware (hardware_id, builtin_storage_id) FROM stdin;
1	3
2	4
9	5
14	6
18	7
19	7
20	8
21	8
23	3
22	9
25	8
26	8
31	5
24	8
30	4
32	8
34	8
45	3
48	9
49	5
52	7
53	9
53	10
54	12
54	11
\.


--
-- Data for Name: co_cpu_names; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY co_cpu_names (name, created_at, updated_at) FROM stdin;
8087	2010-01-08 02:56:55.472728	2010-01-08 02:56:55.472728
Paula	2010-01-08 02:56:55.47994	2010-01-08 02:56:55.47994
Gary	2010-01-08 02:56:55.48416	2010-01-08 02:56:55.48416
68881	2010-01-08 02:56:55.487792	2010-01-08 02:56:55.487792
Agnus	2010-01-10 22:22:11.505102	2010-01-10 22:22:11.505102
Denise	2010-01-10 23:37:13.094416	2010-01-10 23:37:13.094416
VIC-I	2010-01-12 21:44:17.178151	2010-01-12 21:44:17.178151
TED 7360	2010-01-13 10:58:36.129459	2010-01-13 10:58:36.129459
SID 6581	2010-01-13 11:29:37.600676	2010-01-13 11:29:37.600676
8563	2010-01-21 11:04:50.074179	2010-01-21 11:04:50.074179
8568	2010-01-21 11:04:57.363126	2010-01-21 11:04:57.363126
8580	2010-01-21 21:48:38.093837	2010-01-21 21:48:38.093837
ULA	2010-01-23 21:49:49.924892	2010-01-23 21:49:49.924892
\.


--
-- Data for Name: co_cpu_types; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY co_cpu_types (name) FROM stdin;
math
I/O
video
generic
ram/video
video/sound
sound
\.


--
-- Data for Name: co_cpus; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY co_cpus (id, co_cpu_name_id, co_cpu_type_id, manufacturer_id, created_at, updated_at, cpu_family_id, description) FROM stdin;
2	8087	math	8	2010-01-08 02:56:55.500061	2010-01-08 02:56:55.500061	\N	\N
3	Agnus	ram/video	16	2010-01-10 22:44:56.964291	2010-01-11 00:08:41.265998		Agnus is the main custom chip in the Amiga chipset. It controls the access to chip RAM and is divided in 2 main parts: the blitter and the copper.
5	Denise	video	16	2010-01-10 23:38:32.050297	2010-01-11 00:08:50.736176		Denise is the video custom chip of the Amiga original chipset.
6	Gary	I/O	16	2010-01-11 00:10:17.267229	2010-01-11 00:10:17.267229		Gray is the custom chip of the Amiga original chip set that handles I/O ports and bus.
7	VIC-I	video/sound	15	2010-01-12 21:47:08.027456	2010-01-13 10:57:32.008905	65XX	The VIC-I was the first attempt of Commodore to create a custom chip for its home computers. The VIC-I (Video Inteface Chip) was used in the Commodore VIC-20 and handles both graphics and sound.
8	TED 7360	video/sound	15	2010-01-13 11:01:03.167742	2010-01-13 11:01:03.167742		
4	Paula	sound	16	2010-01-10 23:36:45.809325	2010-01-13 11:39:13.474934		Paula is part of the Amiga original chip set and is used mostly for sound. The chip has 4 channels, 2 for left and 2 for right output.
9	SID 6581	sound	15	2010-01-13 11:36:53.590335	2010-01-17 15:07:01.710566	65XX	The MOS-6581 SID (Sound Interface Device) is the first custom chip designed to manage sound developed by Commodore for its 8bit computers. Late productions chips were marked with the 8580 code. It was used in the C64 and C128 home computers, but later in the 90s also in musical intruments such as MIDI synthesizers.
10	8563	video	15	2010-01-21 11:06:53.634907	2010-01-21 11:06:53.634907	65XX	Improved version of VIC-II co-cpu
11	8568	video	15	2010-01-21 11:07:24.534905	2010-01-21 11:07:24.534905	65XX	Improved version of VIC-II co-cpu
12	8580	sound	15	2010-01-21 21:49:08.753099	2010-01-21 21:49:08.753099	65XX	Revised version of the original SID
13	ULA	generic	21	2010-01-23 22:02:39.341286	2010-01-23 22:02:39.341286		
\.


--
-- Data for Name: co_cpus_hardware; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY co_cpus_hardware (hardware_id, co_cpu_id) FROM stdin;
1	3
1	5
1	4
1	6
4	7
6	8
7	9
3	9
15	9
23	3
23	5
23	6
23	4
24	10
32	9
29	9
33	12
39	13
8	13
10	13
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY countries (name, created_at, updated_at, flag_file_name, flag_content_type, flag_file_size, flag_updated_at) FROM stdin;
Italy	2010-01-08 02:56:50.626129	2010-01-11 08:43:41.336536	italy.png	image/png	211	2010-01-11 08:43:41.023292
USA	2010-01-08 02:56:50.905023	2010-01-11 08:43:41.681768	usa.png	image/png	4756	2010-01-11 08:43:41.553483
France	2010-01-08 02:56:51.199566	2010-01-11 08:43:41.960471	france.png	image/png	2861	2010-01-11 08:43:41.860239
Germany	2010-01-08 02:56:51.490207	2010-01-11 08:43:42.309243	germany.png	image/png	216	2010-01-11 08:43:42.073365
Spain	2010-01-08 02:56:51.664053	2010-01-11 08:43:42.582153	spain.png	image/png	628	2010-01-11 08:43:42.475985
Japan	2010-01-08 02:56:51.821555	2010-01-11 08:43:42.848786	japan.png	image/png	3575	2010-01-11 08:43:42.74755
Great Britain	2010-01-08 02:56:52.184428	2010-01-11 08:43:43.048059	great-britain.png	image/png	3301	2010-01-11 08:43:42.951205
Holland	2010-01-08 02:56:52.396095	2010-01-11 08:43:43.372443	holland.png	image/png	2871	2010-01-11 08:43:43.280456
Canada	2010-01-08 02:56:52.582974	2010-01-11 08:43:43.569962	canada.png	image/png	1407	2010-01-11 08:43:43.483176
Australia	2010-01-08 02:56:52.898486	2010-01-11 08:43:43.816915	australia.png	image/png	2947	2010-01-11 08:43:43.73097
Austria	2010-01-08 02:56:53.079224	2010-01-11 08:43:44.159255	austria.png	image/png	490	2010-01-11 08:43:44.043452
Portugal	2010-01-08 02:56:53.283115	2010-01-11 08:43:44.444465	portugal.png	image/png	1691	2010-01-11 08:43:44.328408
\.


--
-- Data for Name: cpu_bits; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY cpu_bits (name) FROM stdin;
8 bit
4 bit
16 bit
32 bit
4/8 bit
8/16 bit
16/32 bit
\.


--
-- Data for Name: cpu_families; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY cpu_families (name, created_at, updated_at) FROM stdin;
Z80	2010-01-08 02:56:55.122915	2010-01-08 02:56:55.122915
X86	2010-01-08 02:56:55.140814	2010-01-08 02:56:55.140814
65XX	2010-01-08 02:56:55.145981	2010-01-08 02:56:55.145981
68K	2010-01-10 22:16:37.564317	2010-01-10 22:16:37.564317
\.


--
-- Data for Name: cpu_names; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY cpu_names (name, created_at, updated_at) FROM stdin;
Z80	2010-01-08 02:56:55.165611	2010-01-08 02:56:55.165611
6502	2010-01-08 02:56:55.173653	2010-01-08 02:56:55.173653
68000	2010-01-08 02:56:55.177889	2010-01-08 02:56:55.177889
8088	2010-01-10 22:16:07.722092	2010-01-10 22:16:07.722092
6509	2010-01-10 22:16:20.209094	2010-01-10 22:16:20.209094
6510	2010-01-11 21:11:25.494686	2010-01-11 21:11:25.494686
7501	2010-01-13 10:51:56.415953	2010-01-13 10:51:56.415953
8502	2010-01-13 11:37:20.267183	2010-01-13 11:37:20.267183
65C02	2010-01-13 18:44:21.897153	2010-01-13 18:44:21.897153
Z80A	2010-01-14 13:00:15.777683	2010-01-14 13:00:15.777683
D780C	2010-01-14 13:38:37.850179	2010-01-14 13:38:37.850179
8080	2010-01-17 21:29:17.32117	2010-01-17 21:29:17.32117
HD68000P8	2010-01-19 10:40:40.754613	2010-01-19 10:40:40.754613
6502A	2010-01-21 14:57:27.634283	2010-01-21 14:57:27.634283
8510	2010-01-21 20:26:02.952988	2010-01-21 20:26:02.952988
8500	2010-01-21 21:33:47.592738	2010-01-21 21:33:47.592738
6502B	2010-01-31 15:54:03.426909	2010-01-31 15:54:03.426909
\.


--
-- Data for Name: cpus; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY cpus (id, cpu_bit_id, cpu_family_id, manufacturer_id, cpu_name_id, clock, created_at, updated_at, description, parent_cpu_id) FROM stdin;
5	8 bit	65XX	15	6510	1.02Mhz	2010-01-11 21:15:18.784514	2010-01-11 21:15:18.784514	The MOS-6510 is an improved version of the famous MOS-6502, it was used mostly in the C64 computer and in its variants.	\N
7	8 bit	65XX	15	8502	2MHz	2010-01-13 11:41:08.370334	2010-01-14 09:14:46.646542	The 8502 is a revised version of the 6510 able to run at the twice clock speed of its predecessor. The 8502 is a special CPU used only in the C128.	\N
9	8 bit	65XX	15	65C02	1Mhz	2010-01-13 18:45:33.080723	2010-01-14 09:36:24.875167	The MOS-65C02 is the CMOS version of the famous 6502 microprocessor. The CMOS version uses less power to run and most of the bugs of 6502 is fixed.	\N
15	16/32 bit	68K	19	HD68000P8	8MHz	2010-01-19 10:43:43.444482	2010-01-25 22:00:50.984428	The P8  is a variant of Motorola 68000 produced by Hitachi. It was used in the Amiga 1000 rev. A.	22
6	8 bit	65XX	15	7501	1MHz	2010-01-13 10:57:10.585578	2010-01-25 22:01:56.632135	The MOS Technology 7501 was a direct evolution of the MOS-6510 that equipped the Commodore 64 home computer. Its main new feature was dynamic bank switching. Commodore 16, Commodore 116 and the Plus/4 were the target computer for the MOS 7501.	\N
10	8 bit	Z80	17	D780C	3.5MHz	2010-01-14 13:53:39.402826	2010-01-25 22:10:01.564635	The D780C is a Z80 clone used mainly in the first production runs of early Sinclair computers such as ZX80, ZX81, ZX Spectrum and in several computers of the MSX consortium. It is fully Z80 compatible with an "odd" clock speed compared to the original ZiLOG scheme (2MHz step clock). 	23
11	8 bit	65XX	15	6509	2Mhz	2010-01-17 15:00:02.319811	2010-01-17 15:00:02.319811		\N
12	8 bit		8	8080	2Mhz	2010-01-17 21:34:07.586637	2010-01-17 21:34:07.586637	The Intel 8080 was one of the first successful CPU produced by Intel. Production started in 1974 and soon the CPU was adopted by many early personal computer manufacturers. 	\N
18	8 bit	65XX	15	8510	1MHz	2010-01-21 20:26:50.594739	2010-01-21 20:26:50.594739	Improved version of 6510	\N
19	8 bit	65XX	15	8500	1MHz	2010-01-21 21:36:21.71701	2010-01-21 21:36:21.71701	HMOS Version of the classic 6510	\N
16	8 bit	65XX	15	6502	2Mhz	2010-01-21 11:22:28.813088	2010-01-25 21:12:42.55529		21
13	8 bit	65XX	15	6502	1.79Mhz	2010-01-17 22:03:57.131778	2010-01-25 21:12:57.902544		21
17	8 bit	65XX	15	6502A	2Mhz	2010-01-21 14:59:07.052454	2010-01-25 21:13:17.878448	This is an improved version of the original MOS-6502. The CPU now runs at 2Mhz and the "A" character has been appended to the name.	21
22	16/32 bit	68K	9	68000		2010-01-25 21:14:50.745616	2010-01-25 21:14:50.745616		\N
14	16/32 bit	68K	9	68000	8MHz	2010-01-18 12:50:17.567356	2010-01-25 21:15:19.971215	This is the G8 variant of the famous Motorola 68000 able to run at 8MHz (MC68000G8).	22
3	16/32 bit	68K	9	68000	7.16Mhz	2010-01-10 22:19:46.424622	2010-01-25 21:16:02.592871	This was the standard CPU mounted on the first Commodore Amiga computers such as the Amiga 1000, 500, 500 Plus and 2000.	22
2	8 bit	Z80	14	Z80	2MHz	2010-01-08 02:56:55.234888	2010-01-25 22:21:27.086487		23
23	8 bit	Z80	14	Z80		2010-01-25 21:16:27.393051	2010-01-25 21:18:52.464246	Z80 is the most produced and used 8BIT CPU. Due to the incredible vastity of variants, it's actually difficult to classify all versions. The 2.5MHz is generally accepted as the original version of the Z80 although clock speeds could range between 2.0MHz and 20MHz. Usually different speeds are identified by a subversion letter (e.g. Z80A is the 4MHz Z80).	\N
4	8 bit	65XX	15	6502	1Mhz	2010-01-11 10:25:33.322747	2010-01-25 21:52:20.815604		21
21	8 bit	65XX	15	6502		2010-01-25 21:05:22.601382	2010-01-25 21:58:45.806234	One of the most successful CPU of all times, the MOS 6502 was very cheap compared to its competitors and so it was a very common choice for early 8 bit computers.<br />\r\nThe CPU design was made uniquely by Chuck Peddle and Bill Mensch using rubylith, a particular film material for lithography. The physical design was literally cut from rubylith sheets with a normal cutter. Traces, logics, circuitries: everything was designed on blueprint paper and then moved to the film. When the three main slices of the 6502 were cut, the process involved a photographic reduction to silicon. Usually the project team needs to run two or three revision cycles before the CPU can work properly, but the 6502 prototype worked at the first try. Along with the first production of Intel, designed with the same procedure, this CPU is one of the masterpieces in the computer history.	\N
8	8 bit	Z80	14	Z80A	3.5Mhz	2010-01-13 18:00:43.230961	2010-01-25 22:23:34.853565	The Z80A is a revised version of Z80 that can run twice as fast as the original.	23
20	8 bit	65XX	20	6502B	2MHz	2010-01-22 22:24:38.449972	2010-01-31 15:54:32.725164	Synertek clone of the MOS 6502B.	21
\.


--
-- Data for Name: cpus_hardware; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY cpus_hardware (hardware_id, cpu_id) FROM stdin;
2	4
3	5
4	4
5	4
6	6
7	2
7	7
9	9
8	10
10	8
11	4
12	4
13	4
14	4
15	11
16	12
17	13
18	14
19	14
23	3
24	8
24	7
22	16
25	16
26	17
32	5
20	4
29	18
33	19
1	3
34	20
39	8
21	4
46	4
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY currencies (name, created_at, updated_at) FROM stdin;
EUR	2010-01-08 02:56:53.458001	2010-01-08 02:56:53.458001
USD	2010-01-08 02:56:53.465699	2010-01-08 02:56:53.465699
GBP	2010-01-08 02:56:53.469587	2010-01-08 02:56:53.469587
CAD	2010-01-08 02:56:53.484002	2010-01-08 02:56:53.484002
AUD	2010-01-08 02:56:53.488169	2010-01-08 02:56:53.488169
YEN	2010-01-08 02:56:53.492022	2010-01-08 02:56:53.492022
ITL	2010-01-08 02:56:53.4959	2010-01-08 02:56:53.4959
FRF	2010-01-08 02:56:53.499872	2010-01-08 02:56:53.499872
DEM	2010-01-08 02:56:53.50394	2010-01-08 02:56:53.50394
PTE	2010-01-08 02:56:53.508189	2010-01-08 02:56:53.508189
ESP	2010-01-08 02:56:53.512266	2010-01-08 02:56:53.512266
ATS	2010-01-08 02:56:53.51614	2010-01-08 02:56:53.51614
NLG	2010-01-08 02:56:53.519974	2010-01-08 02:56:53.519974
\.


--
-- Data for Name: ebay_keywords; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY ebay_keywords (id, name, searchable_id, searchable_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ebay_sites; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY ebay_sites (name, site_id, created_at, updated_at, currency_id, country_id) FROM stdin;
DE	77	2010-01-08 02:56:55.821059	2010-01-08 02:56:55.821059	EUR	Germany
IT	101	2010-01-08 02:56:55.83024	2010-01-08 02:56:55.83024	EUR	Italy
US	1	2010-01-08 02:56:55.861441	2010-01-08 02:56:55.861441	USD	USA
FR	71	2010-01-08 02:56:55.867344	2010-01-08 02:56:55.867344	EUR	France
ES	186	2010-01-08 02:56:55.873245	2010-01-08 02:56:55.873245	EUR	Spain
UK	3	2010-01-08 02:56:55.87972	2010-01-08 02:56:55.87972	GBP	Great Britain
NL	146	2010-01-08 02:56:55.885603	2010-01-08 02:56:55.885603	EUR	Holland
AU	15	2010-01-08 02:56:55.891945	2010-01-08 02:56:55.891945	AUD	Australia
CA	2	2010-01-08 02:56:55.898201	2010-01-08 02:56:55.898201	CAD	Canada
\.


--
-- Data for Name: hardware; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY hardware (id, name, code, notes, manufacturer_id, production_start, production_stop, codename, text_modes, graphic_modes, sound, builtin_language_id, ram, vram, rom, hardware_category, hardware_type_id, description, trivia) FROM stdin;
3	Commodore 64			12	1982	1994			320x200, 16 colors	3 channels, 8 octaves via the SID 6581 chip	Commodore BASIC	64Kb	1Kb	20Kb	computer	Home Computer	The Commodore 64 was the most successful computer of all time, as sales scored a total of 17 million units sold during his long production lifespan.	\N
9	Apple IIc	A2S4000		11	1984	1989		80x25, 40x25	140x192 16 colors, 280x192 6 colors, 569x192 monochromatic 	1 channel, builtin speaker	Microsoft Basic	128Kb, max 1.25Mb		16Kb	computer	Personal Computer	The Apple IIc was the compact version of the successful Apple IIe computer. It was launched in january 1984 together with the first Macintosh, and was equipped with the MOS-65C02 CPU, a low consumption version of the standard MOS-6502.	\N
5	Apple IIe			11	1983	1993		40 columns, 24 rows	280x160	1 channel (builtin speaker)	Microsoft Basic	64Kb		16Kb	computer	Personal Computer	The Apple IIe is the third model of the successful Apple II computer series. With this model Apple introduced new hardware features and reduced manufacturing costs by redesigning the motherboard and reducing the number of chips mounted on it.	\N
17	Atari 400			10	1979	1982	Candy	40x25	320x192 max	4 voices, 3 octaves		4/8Kb		10Kb	computer	Home Computer	The Atari 400 was launched in 1979 as a entry level home computer. It was basically a stripped down version of the Atari 800 computer, which had better hardware such as a real keyboard, more memory and cartridge slots, but otherwise the computers are very similar.	\N
10	ZX Spectrum +		The upgrade kit sold by Sinclair had high rate of defective keys, as many of them fell off.	13	1984	\N	TB	32x22	256x192, 8 colors	internal speaker, 1 channel 5 octaves	Sinclair BASIC	16/48Kb		16Kb	computer	Home Computer	In late 1984 Sinclair decided to produce a face-lifted version of the ZX Spectrum, as the original had an awkward keyboard and this was becoming a serious issue with customers. So the ZX Spectrum + was born, with a better case and a better keyboard (but still not that good). The computer was sold at 179.95 GBP, about 50 GBP more than the original version; for the same price Sinclair offered an upgrade kit (basically the computer case and keyboard) to let user update their old Spectrum computers.	\N
4	VIC-20			12	1980	1985		23 rows, 22 columns	184x176	3 voices, 3 octaves	Commodore BASIC	5Kb, 32Kb max		8Kb	computer	Home Computer	The VIC-20 was the first low cost color computer produced by Commodore. It a was very successful computer as more than 1 million units were sold in five years. Sales started in 1980 in Japan where the machine was marketed with the name "VIC-1001".	\N
6	Commodore 16		This was the first computer created by Bil Herd at Commodore. Production is uncertain due to the quantity of derived models. An approximative estimation is of about half a million 264 computer family.	12	1984	\N			320x200, 320x160, 160x200, 160x160	2 channels, 4 octaves	Commodore BASIC	16Kb			computer	Home Computer	The Commodore 16 was released in 1984 as a replacement for the aging low cost VIC-20 home computer. It is a member of the 264 family which includes the Commodore 116 and Plus 4. Commodore did not use the same connectors of the C64/VIC-20 computers on the C16, so it was not compatible with existing C64/VIC-20 peripherals.	\N
2	PET 2001 - early version		Third parties soon started to sell external keyboards for this computer, as the builtin one was quite awkward.	12	1977	1979		40x25	graphics was accomplished using alternate characters	none	Commodore BASIC	4-8Kb	1Kb	14Kb	computer	Personal Computer	The Commodore PET was one of the first personal computers produced, and was the first one built by Commodore. Early models had an integrated tape recorder, a small  keyboard ("chicklet") and had a quite buggy firmware.	\N
14	CBM 8250 LP			12	\N	\N									peripheral	External Floppy Disk Drive	This is the LP (low profile) version of the more common CBM 8250 dual drive. Commodore also replaced the metal case with a slick one made of stiff plastic.	\N
12	CBM 3016			12	1979	\N		40x25	only via graphic characters	none	Commodore BASIC	16Kb			computer	Personal Computer	The CBM 3016 is a PET/CBM 30XX computer equipped with 16Kb of RAM. After some legal troubles with Philips Commodore had to change the name of his PET computers to CBM, an acronym that stands for Commodore Business Machines.	\N
7	Commodore 128		Surely one of the most interesting and underrated 8 bit computers of all times. Commodore sold about 4 million of C128.	12	1985	1989			320x200, 160x200 4 colors, 8 sprites	3 channels, 6 octaves	Commodore BASIC	128Kb, max 512Kb		64Kb	computer	Home Computer	The Commodore 128 is the last and most powerful home computer marketed by Commodore. It sports 2 independent CPUs, a big memory and the ability to run Digital Research CP/M operative system and to boot in a C64 compatible mode.  To solve the troubles coming from the CP/M compatibility, Bil Herd and his staff decided to include a Z80 CPU on the motherboard. A working prototype with the auxiliary CPU was created in just one night. Unfortunately the computer was mostly used in C64 mode, so people rarely took advantage of its improved hardware capabilities.	\N
13	CBM 3032			12	1979	\N		40x25	only via graphic characters	none	Commodore BASIC	32Kb			computer	Personal Computer	The CBM 3032 is the top model of the Commodore CBM 30XX computer series.	\N
15	CBM 610			12	1982	1984		80x25		3 voices, SID 6881 co-CPU		128/256Kb		24Kb	computer	Personal Computer	This computer is a member of the CBM-II computer series, launched by Commodore to replace the original CBM series. The name CBM 610 refers to the European market, while in the US the computer was named B128.	\N
8	ZX Spectrum			13	1982	1984		32x24	256×192	1 channel, 10 octaves (internal beeper)	Sinclair BASIC	16Kb, max 128Kb		16Kb	computer	Home Computer	The ZX Spectrum was one of the best selling home computers of the 80s. launched in 1982 it quickly became very popular above all in UK. It soon became the most dangerous rival of the Commodore 64.	\N
16	Altair 8800		it was available both in kit (395$) or assembled (495$)	18	1975	\N		none	none	none	8080 assembler	256 bytes			computer	Personal Computer	The Altair 8800 was one of the first microcomputers in history. It had no builtin monitor or keyboard, so programs were initially entered using the switches located on the front panel, and results were displayed by leds blinking on the same panel. This was a system used by most of the IT pioneers. Two of the most famous of them were Bill Gates and Paul Allen who wrote most of their BASIC using an Altair.	\N
11	CBM 8032			12	1981	\N		80x25	Only via graphic characters set (PETSCII)	Internal Speaker	Commodore BASIC	32Kb		16Kb	computer	Personal Computer	The CBM 8032 was the first computer produced by Commodore for the business market. When it was launched it was a quite impressive machine with 32K of RAM, a big 12 inches wide monitor and an improved BASIC that could handle disk I/O more cleanly than previous versions.	\N
20	1541			12	\N	\N						2Kb		16Kb	peripheral	External Floppy Disk Drive	This was one of the best selling peripherals for the Commodore 64. Commodore did not use the same mechanism on every unit, so there are a few variants around: Alps mechanisms mount a central horizontal shutter, while Mistsumi variants mount a lever located on the right side of the panel. One of the most common issues with 1541 drives was (and still is) head misaligment.	\N
30	Datassette - early version			12	\N	\N									peripheral	tape recorder	This is the first version of the most famous of Commodore peripherals, the Datassette, later known also as C2N. This model was introduced with the PET computer series and was available in two colors, white and black.	\N
21	1541-II			12	1988	1994									peripheral	External Floppy Disk Drive	This is the last version of the famous 1541 floppy disk drive produced by Commodore for its 8bit home computers. The PSU has been moved out of the case to improve the drive reliability. It has been marketed until the last days of Commodore in the early 90s.	\N
19	Macintosh 512K	M0001W		11	1984	1986		no text modes; everything is bitmap graphics	512x342	Internal speaker with headphone connector.		512KB		64Kb	computer	Personal Computer	Macintosh 512K is completely identical to the previous model (128K), the only difference is the amount of RAM 512Kb. Like its predecessor the Macintosh 512K is non expandable. 	\N
18	Macintosh 128K	M0001	The Apple Macintosh wasn't upgradable; you couldn't install an internal HDD since there wasn't  a internal SCSI port. Although you could use the serial attached external HDD. This kind of approach was probably the first true example of Apple "closed case" philosophy. \r\n\r\nApple had planned to sell about 350.000 Macintosh 128Kb, but after the firsts 70,000 sold computers, selling has begun to slow. 	11	1984	1985		no text modes; everything is bitmap graphics	512x342	Internal speaker with headphone connector.		128Kb		64Kb	computer	Personal Computer	This was the first Apple Macintosh that was ever produced. It is probably one of the most innovative product in the first half of eighties. Most notable features are the compact case with the integrated 9'' monitor and the first edition of Mac OS System (1.0). The market evolution of the product seen a later revision with more memory (Macintosh 512K). Due to this fact the original name of the computer (simply Macintosh) was changed in Macintosh 128K, also know as Thin Mac. Macintosh 128K was also the protagonist of the famous Ridley Scott's spot "1984", aired during the 1984's Superbowl. 	\N
1	Amiga 1000		In the Amiga 1000 rev. A was used an Hitachi version (HD68000P8) of the Motorola 68000.	12	1985	1987	Lorraine		320×200 with 32 colors \r\n320×400 with 32 colors\r\n640×200 with 16 colors\r\n640×400 with 16 colors	4 channels 8 bit stereo - dedicated custom chip Paula		256-512Kb		8Kb, + 256Kb loaded at power up (kickstart)	computer	Personal Computer	Commodore unveiled the Amiga 1000 during a special event in summer 1985. The Amiga can be considered the first multimedia computer with his spectacular graphics and sound, and was also one of the first personal computers to sport a WIMP operative system and prehemptive multitasking.	\N
28	Disk II			11	\N	\N									peripheral	External Floppy Disk Drive	The Disk II has been for sure one of the most important ingredients for Apple success during the late 70s and early 80s. Woz designed the Disk II analog card in a very short time and with such a clever design that it's considered a masterpiece. The good design resulted in low production cost, which meant lower prices and higher profits for Apple.	\N
22	1581			12	1987	\N						8Kb		32Kb	peripheral	External Floppy Disk Drive	This is one of the nicest and sought Commodore 64 peripherals, as it allows to use big capacity 3.5" disks with many Commodore 8bit computers. A single 3.5" floppy disk can in fact store almost 5 times mora data than a 5.25" floppy disk formatted on the Commodore 1541 drive. 	\N
29	Commodore 64C			12	1986	1994			320x200, 16 colors	3 channels, 8 octaves via the SID 6581 chip	Commodore BASIC	64Kb	1Kb	20Kb	computer	Home Computer	After three years from the initial production of the breadbox C64, Commodore renewed the old and classic brown chassis. Following the new trend launched with the C128 slick case, Commodore adopted a slim line as the new C64 shape. Nice to see but essentially the same old C64 with just some adjustment to the chipset to reduce costs.	\N
23	Amiga 500			12	1987	1992	Rock Lobster		320×200 with 32 colors \r\n320×400 with 32 colors\r\n640×200 with 16 colors\r\n640×400 with 16 colors	4 channels 8 bit stereo - dedicated custom chip Paula		512Kb			computer	Home Computer	Commodore launched the Amiga 500 during the 1987 winter edition of CES in Las Vegas. The Amiga 500 sold in high volumes expecially in Europe, it was basically an Amiga 1000 packed in a all-in-one case with 512Kb of memory and kickstart 1.2 on a ROM chip. The computer was mostly used as a game machine thanks to the good multimedia hardware capabilities. It was later replaced by the Amiga 500 Plus and by the Amiga 600 models.	\N
25	1541C			12	1986	\N								16Kb	peripheral	External Floppy Disk Drive	In 1986 Commodore marketed a slightly improved version of the 1541 disk drive. This new version had a lighter beige case that matched the new Commodore 64C case color. 	\N
27	SFD-1001		ROMS: 901467, 901887-01, 901888-01, 241257-02A, floppy disks should be 96tpi	12	\N	\N						4Kb			peripheral	External Floppy Disk Drive	The SFD-1001 is a single floppy drive unit produced by Commodore during the early 80s. It's aesthetically similar to the more famous 1541, but it can store 1Mb of data on each floppy disk. It has a IEEE-488 port, so it can be used directly only on the computers of the CBM/PET series. The acronym SFD stands for Super Floppy Disk.	\N
26	1570		1 x 27256 EPROM	12	\N	\N									peripheral	External Floppy Disk Drive	The Commodore 1570 is the single side disk drive version of the 1571. Though being compatible with the Commodore 64, the 1570 disk drive combined with the C128 could reach higher data transfer rates.	\N
31	Duodisk	A9M0108		11	\N	\N									peripheral	External Floppy Disk Drive	Apple produced the Duodisk as a convenient alternative to buying a couple of Disk II or Unidisk 5.25" floppy disk drives. It requires a cable for connection to the computer.	\N
32	Commodore SX-64		Sales of this Commodore jewel were very poor: about 100.000 units were sold during the short life of the SX-64. This is also a record machine as it was the first color portable computer of history. Commodore wasn't new to this kind of innovation.	12	1984	1986			320x200, 16 colors	3 channels, 8 octaves via the SID 6581 chip	Commodore BASIC	64Kb	1Kb	20Kb	computer	Portable Computer	This computer is surely a good example of the ambiguous Commodore soul. The Commodore 64 was mainly a home computer and as time passed by its name became synonymous of great and cheap game machine. The SX-64 was Commodore first attempt to enter the market of portable computer, at the time dominated by Osborne and Compaq.\r\n<br />\r\nThe good old Commodore 64 hardware was almost unusable with a small 5 inches screen, while bad marketing and lack of business software did the rest.<br />\r\n\r\nIn Europe Commodore marketed this machine also under the Executive 64 and VIP 64 fancy names.	\N
33	Commodore 64GS		About 80.000 C64GSs were produced, but only 20.000 were sold and exclusively in Europe. 	12	1990	\N						64Kb	0.5Kb	20Kb	computer	Home Computer	The aim of this site is not to track game console. This is a special case. The Commodore 64GS (that stands for Game System) is one of the many commercial failures of Commodore.\r\n<br />\r\nA cut down version of the C64, without keyboard or support for external devices, the C64GS was designed and produced to compete in the raising console market. The problems were always the same: bad timing (8BIT era was definitively over), bad marketing strategies and lack of software. The production of C64GS was quickly stopped and Commodore tried another (unsuccessful) shot in the console world with the Amiga CD32.	\N
24	Commodore 128D and 128DCR		Actually the 128 family was not the last attempt to make a C64 heir. The ultra rare C65 (or C64DX) was under development in Commodore's labs at the beginning of nineties. That was the real last 8BIT computer from Commodore.	12	1985	1989		80x25 or 80x50	320x200, 640x200 and 640×400 (only interlaced)	3 channels, 6 octaves	Commodore BASIC	128Kb	64Kb	64Kb	computer	Home Computer	The Commodore 128D (DCR in USA) is a slightly improved version of the Commodore 128, where the main difference resides in the completely redesigned chassis. Instead of the classic all-in-one Commodore design, the 128D has a desktop PC like chassis with a detachable keyboard and an integrated floppy disk drive (1571). The improved chipset (VDC 8563 or 8568 depending on the model) and the increased Video Memory give to the 128D a better graphic with high resolution mode and more colors.\r\n<br />\r\nThe 128D was the last Commodore attempt to create an heir to the oversold C64. The PC shaped chassis shows how Commodore had tried to find a good product to fill  the 8BIT CP/M business market. This was at the sunset of 8BIT CPU era and this is the reason why the Commodore 128D was quickly forgotten, though it was a really good example of hardware art. 	\N
35	VIC 1541			12	\N	\N									peripheral	External Floppy Disk Drive	An initial version of the 1541 external disk drive from Commodore.	\N
39	ZX81			13	1982	\N		32x24	64x44	none	Sinclair BASIC	1Kb max 128Kb			computer	Home Computer	After the big success of the ZX80 Sinclair released in 1981 a new improved version of the machine and appropriately named it ZX81. This is one of the most little and inexpensive computers ever produced measuring less than 17x17x4cm and having a price of 70 GBP at launch. This computer was marketed in the US with the name of Timex Sinclair 1000.	\N
42	CBM 8296			12	\N	\N					Commodore BASIC				computer	Personal Computer	Please wait, we are working on it...	\N
51	5.25" Disk Drive	A9M0107		11	\N	\N									peripheral	External Floppy Disk Drive	Another 5.25" floppy disk drive for the Apple II.	\N
44	CBM 8050			12	1980	\N									peripheral	External Floppy Disk Drive	The 8050 is the 512K per side version of the classic Commodore external double disk. It use an IEEE interface and it is usually combined with PET/CBM machine although it was compatible with all 8BIT Commodore.	\N
37	Joystick IIe and IIc	A2M2012		11	\N	\N									peripheral	Joystick	This is the official Apple joystick for the Apple IIe and Apple IIc computers.	\N
38	Keyboard II	M0487 1991		11	\N	\N									peripheral	Keyboard	The Keyboard II is a common Apple ADB keyboard. It can be used on all Apple computers with ADB ports such as the Mac SE, Classic, Classic II and even with the Apple IIgs.	\N
36	Amiga 1200	A1200 530311		12	\N	\N						2Mb			computer	Personal Computer	The Amiga 1200 is one of the last computer produced by Commodore. It was released in late 1992, sales were good but the fate of the machine was doomed when Commodore went bankrupt. 	\N
40	PDP 8			22	\N	\N						4096K in 12bits words			computer	Mini Computer	The DEC PDP-8 was the first commercially successful minicomputer in history. It was launched in 1965 and it's present in this website as one of the most significative ancestors of the 70s microcomputers.	\N
45	Amiga 1010	1010		12	1985	\N									peripheral	External Floppy Disk Drive	This was the first external floppy disk drive available from Commodore. The design matches the Amiga 1000 style.	\N
46	Apple II europlus	A2S2		11	\N	\N					Applesoft Basic				computer	Personal Computer	This was the european version of the Apple Plus computer.	\N
47	3022 Tractor Printer			12	1978	\N									peripheral	Printer	This is the first dot matrix printer produced by Commodore for the PET computer series	\N
48	3.5" Disk Drive	A9M0106		11	\N	\N									peripheral	External Floppy Disk Drive	This is the standard Apple II 3.5 disk drive. It works also with Macintosh computers.	\N
49	Unidisk 5.25"	A9M0104		11	\N	\N									peripheral	External Floppy Disk Drive	5.25" floppy disk drive for the Apple II computer series.	\N
52	Macintosh SE	M5010		11	1987	1989						1Mb		256Kb	computer	Personal Computer	Please wait... We are working on it. :)	\N
53	Macintosh SE FDHD	M5011	This particular models uses an early version of compact HD (5 1/4 size). Because of this is very difficult to find a system with a fully functional HD today. Most of them suffer of stiction a particular problem strictly related to the inadequate lubricant. \r\n\r\nThe Macintosh SE FDHD was known in Europe with the names SE 1/20 or SE 1/40 depending on the size of the internal HD.	11	1989	1990						1Mb		256Kb	computer	Personal Computer	Macintosh SE FDHD is an enhanced version of the previous Macintosh SE. It uses a double density floppy (SuperDrive) and it mounts a SCSI HD. 	\N
54	Macintosh SE/30	M5119		11	1989	1991						1Mb	64Kb	256Kb	computer	Personal Computer	Enhanced version of Macintosh SE with the Motorola 68030.	\N
50	Disk III	A3M0004	Early models were packed in a Disk II case and had the model number A3M0003. 	11	\N	\N									peripheral	External Floppy Disk Drive	This is the external floppy disk for the Apple III computer.	\N
55	Commodore 64G			12	\N	\N					Commodore BASIC	64Kb			computer	Home Computer		\N
57	CBM 8296-D			12	\N	\N					Commodore BASIC				computer	Personal Computer		\N
56	CBM 8032-SK			12	\N	\N					Commodore BASIC				computer	Personal Computer		\N
58	ZX Microdrive			13	\N	\N									peripheral	Cartridge Recorder		\N
60	1530 Datassette C2N	C2N		12	\N	\N									computer	tape recorder		\N
59	1531 Datassette			12	\N	\N									peripheral	tape recorder		\N
41	CBM 710/720			12	\N	\N									computer	Personal Computer	Please wait, we are working on it...	
61	MZ-700			23	\N	\N					Basic				computer	Personal Computer		\N
34	Apple III	A3S1	Custom ICs: 342-0031 342-0032 341-0060 341-0035-00	11	1980	1984	Sara					128/2356Kb			computer	Personal Computer	The Apple III was Apple first attempt to enter the business market, but unfortunately the final product was buggy so it became more famous for being Apple's first commercial flop. Bad design (fanless case for noiseless operation), rushed release and poor quality controls made it a complete commercial failure.\r\n<br />\r\n This is the only computer known to have an official medieval remedy for fixing overheat chipset instability (you surely know what I'm talking about). Dropping an expensive computer to make it work again was not exactly what the business market was looking for, so after initial good sales the Apple III was quickly assigned to the stores shelves with the only purpose of dust collector. However this was a good computer in the first half of eighties with good hardware and a nice operating system (Apple SOS, Sophisticated Operative System) which brought some new concepts in file system management.	\N
62	Amiga CD32			12	\N	\N									computer	Home Computer	Please wait, we are working on it...	
63	Commodore 116			12	\N	\N									computer	Home Computer	Please wait, we are working on it...	
64	Commodore Plus/4			12	\N	\N									computer	Home Computer	Please wait, we are working on it...	
65	Amiga 600			12	\N	\N									computer	Personal Computer	Please wait, we are working on it...	
66	Commodore MAX Machine			12	\N	\N									computer	Home Computer	Please wait, we are working on it...	
\.


--
-- Data for Name: hardware_io_ports; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY hardware_io_ports (hardware_id, io_port_id) FROM stdin;
1	17
1	18
1	15
1	14
1	13
2	21
2	22
2	20
3	22
3	20
3	9
3	12
3	26
3	24
4	26
4	20
4	23
4	22
5	14
6	24
7	24
7	20
7	23
7	25
7	22
8	24
8	20
8	27
9	8
10	24
10	20
10	27
11	20
11	22
11	21
12	20
12	22
12	21
13	20
13	21
13	22
15	20
15	22
15	21
15	13
14	21
16	28
18	8
18	30
18	29
7	32
7	33
7	9
19	30
19	29
19	8
20	23
21	23
22	23
25	23
1	25
1	34
23	34
23	25
23	32
23	13
23	18
1	35
23	35
1	19
23	19
23	17
4	25
3	25
26	23
24	24
24	23
24	20
24	22
24	9
24	32
24	33
24	25
32	25
32	26
32	23
32	21
32	38
29	24
29	26
29	20
29	22
29	9
29	25
33	24
33	26
33	25
33	39
29	23
23	40
34	25
34	14
34	41
34	8
34	38
36	34
36	25
36	18
36	17
36	19
36	35
36	13
36	14
36	24
9	25
9	14
9	41
9	44
37	25
9	45
38	46
39	20
39	24
39	32
27	21
30	20
45	18
46	14
46	20
46	27
46	47
47	21
48	45
49	45
51	45
55	20
55	23
55	25
55	9
55	26
55	22
55	24
59	20
60	20
61	20
61	14
61	24
61	9
61	50
61	48
61	49
34	51
34	32
\.


--
-- Data for Name: hardware_operative_systems; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY hardware_operative_systems (hardware_id, operative_system_id) FROM stdin;
1	7
3	9
5	8
7	9
9	12
9	8
16	11
18	13
19	13
23	7
24	9
24	11
32	9
29	9
34	26
46	12
46	8
52	13
53	13
54	13
55	9
\.


--
-- Data for Name: hardware_types; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY hardware_types (name) FROM stdin;
Home Computer
Personal Computer
Portable Computer
Pocket Computer
Monitor
Printer
Keyboard
Mouse
External Floppy Disk Drive
External Hard Disk
tape recorder
Joystick
Mini Computer
Cartridge Recorder
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY images (id, original_filename, title, caption, created_at, updated_at, imageable_id, imageable_type, picture_file_name, picture_content_type, picture_file_size, picture_updated_at) FROM stdin;
12	\N			2010-01-11 08:52:49.033848	2010-01-11 08:52:49.033848	1	Hardware	amiga1000_1.jpg	image/jpeg	135900	2010-01-11 08:52:48.378413
13	\N			2010-01-11 08:53:10.868046	2010-01-11 08:53:10.868046	1	Hardware	amiga1000_2.jpg	image/jpeg	114345	2010-01-11 08:53:10.187345
14	\N			2010-01-11 08:53:33.986023	2010-01-11 08:53:33.986023	1	Hardware	amiga1000_4.jpg	image/jpeg	126837	2010-01-11 08:53:33.177215
15	\N			2010-01-11 08:53:56.654555	2010-01-11 08:53:56.654555	1	Hardware	amiga1000_3.jpg	image/jpeg	106248	2010-01-11 08:53:56.081759
16	\N			2010-01-11 08:54:22.863182	2010-01-11 08:54:22.863182	1	Hardware	amiga1000_5.jpg	image/jpeg	145964	2010-01-11 08:54:22.248442
17	\N			2010-01-11 08:54:49.073185	2010-01-11 08:54:49.073185	1	Hardware	amiga1000.jpg	image/jpeg	118163	2010-01-11 08:54:48.437363
18	\N			2010-01-11 09:07:22.456732	2010-01-11 09:07:22.456732	1	Hardware	wb1.1.gif	image/gif	40608	2010-01-11 09:07:21.379708
19	\N			2010-01-11 10:38:18.884112	2010-01-11 10:38:18.884112	2	Hardware	pet.jpg	image/jpeg	54232	2010-01-11 10:38:18.32195
20	\N			2010-01-11 10:51:11.563541	2010-01-11 10:51:11.563541	2	Hardware	pet1.JPG	image/jpeg	112403	2010-01-11 10:51:10.962983
21	\N			2010-01-11 21:24:39.100648	2010-01-11 21:24:39.100648	3	Hardware	oldbox.jpg	image/jpeg	87612	2010-01-11 21:24:38.48375
24	\N	C64 games		2010-01-11 21:26:31.761814	2010-01-11 21:26:31.761814	3	Hardware	games.jpg	image/jpeg	159067	2010-01-11 21:26:31.136541
25	\N	Boot screen		2010-01-11 21:59:24.547859	2010-01-11 21:59:24.547859	3	Hardware	C64_startup_animiert.gif	image/gif	1654	2010-01-11 21:59:23.927425
26	\N			2010-01-12 21:31:05.996668	2010-01-12 21:31:05.996668	4	Hardware	box.jpg	image/jpeg	69905	2010-01-12 21:31:05.374149
27	\N			2010-01-12 21:31:29.304602	2010-01-12 21:31:29.304602	4	Hardware	box1.jpg	image/jpeg	73363	2010-01-12 21:31:28.769115
28	\N	Games cartridges		2010-01-12 21:31:53.321534	2010-01-12 21:32:12.191195	4	Hardware	cart.jpg	image/jpeg	129973	2010-01-12 21:31:52.733277
29	\N			2010-01-12 21:33:02.725425	2010-01-12 21:33:02.725425	4	Hardware	vic20.jpg	image/jpeg	61203	2010-01-12 21:33:02.191353
30	\N			2010-01-12 21:33:40.907046	2010-01-12 21:33:40.907046	4	Hardware	vic201.JPG	image/jpeg	67957	2010-01-12 21:33:40.419574
31	\N			2010-01-12 22:01:53.89892	2010-01-12 22:01:53.89892	5	Hardware	apple2e.jpg	image/jpeg	79613	2010-01-12 22:01:53.332872
32	\N			2010-01-12 22:03:10.141318	2010-01-12 22:03:10.141318	5	Hardware	a2open.jpg	image/jpeg	124728	2010-01-12 22:03:09.489643
33	\N			2010-01-12 22:03:31.622273	2010-01-12 22:03:31.622273	5	Hardware	a2side.jpg	image/jpeg	69211	2010-01-12 22:03:31.008027
34	\N			2010-01-12 22:03:52.986079	2010-01-12 22:03:52.986079	5	Hardware	box.jpg	image/jpeg	86304	2010-01-12 22:03:52.370004
35	\N			2010-01-13 11:04:51.537519	2010-01-13 11:04:51.537519	6	Hardware	c16.jpg	image/jpeg	46771	2010-01-13 11:04:51.00114
36	\N			2010-01-13 11:05:20.884746	2010-01-13 11:05:20.884746	6	Hardware	c16box.jpg	image/jpeg	100455	2010-01-13 11:05:20.309773
39	\N			2010-01-13 11:06:22.906819	2010-01-13 11:06:22.906819	6	Hardware	c16box1.jpg	image/jpeg	116461	2010-01-13 11:06:22.312343
40	\N			2010-01-13 11:08:04.276634	2010-01-13 11:08:04.276634	6	Hardware	c16details.jpg	image/jpeg	67631	2010-01-13 11:08:03.699311
41	\N			2010-01-13 11:08:28.176156	2010-01-13 11:08:28.176156	6	Hardware	c16_2.jpg	image/jpeg	39234	2010-01-13 11:08:27.67474
42	\N			2010-01-13 18:50:20.92468	2010-01-13 18:50:20.92468	9	Hardware	apple2c_1.jpg	image/jpeg	69713	2010-01-13 18:50:20.269456
43	\N			2010-01-13 18:50:42.191454	2010-01-13 18:50:42.191454	9	Hardware	apple2c1.jpg	image/jpeg	90421	2010-01-13 18:50:41.53215
44	\N			2010-01-13 18:51:15.848883	2010-01-13 18:51:15.848883	9	Hardware	apple2c_inside.jpg	image/jpeg	174270	2010-01-13 18:51:15.126791
45	\N			2010-01-13 18:51:37.696175	2010-01-13 18:51:37.696175	9	Hardware	apple2c_back.jpg	image/jpeg	92651	2010-01-13 18:51:37.044853
46	\N			2010-01-13 18:52:02.893758	2010-01-13 18:52:02.893758	9	Hardware	apple2c.jpg	image/jpeg	168236	2010-01-13 18:52:02.203646
47	\N			2010-01-17 13:58:13.9683	2010-01-17 13:58:13.9683	11	Hardware	8032asso.jpg	image/jpeg	91556	2010-01-17 13:58:13.41555
48	\N			2010-01-17 13:58:39.980186	2010-01-17 13:58:39.980186	11	Hardware	8032back.jpg	image/jpeg	108181	2010-01-17 13:58:39.452601
49	\N			2010-01-17 13:59:01.07015	2010-01-17 13:59:01.07015	11	Hardware	8032backclose.jpg	image/jpeg	109143	2010-01-17 13:59:00.533353
50	\N			2010-01-17 13:59:27.681726	2010-01-17 13:59:27.681726	11	Hardware	8032sideopen.jpg	image/jpeg	93302	2010-01-17 13:59:27.162899
51	\N			2010-01-17 13:59:45.85045	2010-01-17 13:59:45.85045	11	Hardware	8032sideclose.jpg	image/jpeg	74693	2010-01-17 13:59:45.353163
52	\N			2010-01-17 14:00:17.021817	2010-01-17 14:00:17.021817	11	Hardware	8032front.jpg	image/jpeg	102285	2010-01-17 14:00:16.517031
53	\N			2010-01-17 14:00:47.467665	2010-01-17 14:00:47.467665	11	Hardware	8032top.jpg	image/jpeg	118150	2010-01-17 14:00:46.957332
54	\N			2010-01-17 14:01:09.695617	2010-01-17 14:01:09.695617	11	Hardware	8032.jpg	image/jpeg	77801	2010-01-17 14:01:09.226244
55	\N			2010-01-17 14:01:41.396404	2010-01-17 14:01:41.396404	11	Hardware	8032mb.jpg	image/jpeg	153156	2010-01-17 14:01:40.861101
56	\N			2010-01-17 14:02:02.391475	2010-01-17 14:02:02.391475	11	Hardware	8032wrap.jpg	image/jpeg	118644	2010-01-17 14:02:01.859801
57	\N			2010-01-17 14:17:16.625678	2010-01-17 14:17:16.625678	12	Hardware	3016.jpg	image/jpeg	88923	2010-01-17 14:17:15.974355
58	\N			2010-01-17 14:17:47.429436	2010-01-17 14:17:47.429436	12	Hardware	3016_2.jpg	image/jpeg	82069	2010-01-17 14:17:46.927443
59	\N			2010-01-17 14:18:52.099689	2010-01-17 14:18:52.099689	12	Hardware	3016_6.jpg	image/jpeg	124135	2010-01-17 14:18:51.539092
61	\N			2010-01-17 14:19:48.827855	2010-01-17 14:19:48.827855	12	Hardware	3016_4.jpg	image/jpeg	105484	2010-01-17 14:19:47.320126
62	\N			2010-01-17 14:20:18.031053	2010-01-17 14:20:18.031053	12	Hardware	3016_1.jpg	image/jpeg	138126	2010-01-17 14:20:16.83124
63	\N			2010-01-17 15:03:15.43758	2010-01-17 15:03:15.43758	15	Hardware	cbm610.jpg	image/jpeg	41818	2010-01-17 15:03:15.027156
64	\N			2010-01-17 15:03:37.066434	2010-01-17 15:03:37.066434	15	Hardware	cbm610detail.jpg	image/jpeg	79971	2010-01-17 15:03:36.568731
65	\N			2010-01-17 15:03:55.558868	2010-01-17 15:03:55.558868	15	Hardware	cbm610front.jpg	image/jpeg	57827	2010-01-17 15:03:55.171059
66	\N			2010-01-17 15:04:10.065933	2010-01-17 15:04:10.065933	15	Hardware	cbm610side.jpg	image/jpeg	36401	2010-01-17 15:04:09.679353
67	\N			2010-01-17 15:04:30.020489	2010-01-17 15:04:30.020489	15	Hardware	cbm610box.jpg	image/jpeg	84070	2010-01-17 15:04:29.544819
68	\N			2010-01-17 21:05:25.879503	2010-01-17 21:05:25.879503	2	Hardware	popularscience.jpg	image/jpeg	230818	2010-01-17 21:05:24.991345
69	\N			2010-01-17 21:49:54.260794	2010-01-17 21:49:54.260794	16	Hardware	09236-13.jpg	image/jpeg	37244	2010-01-17 21:49:53.705006
70	\N			2010-01-17 21:50:14.394017	2010-01-17 21:50:14.394017	16	Hardware	09236-11.jpg	image/jpeg	69309	2010-01-17 21:50:13.750436
71	\N			2010-01-17 21:50:32.172288	2010-01-17 21:50:32.172288	16	Hardware	09236-15.jpg	image/jpeg	29699	2010-01-17 21:50:31.597173
72	\N			2010-01-17 22:05:11.812009	2010-01-17 22:05:11.812009	17	Hardware	a400top.jpg	image/jpeg	77607	2010-01-17 22:05:11.300767
73	\N			2010-01-17 22:05:30.62714	2010-01-17 22:05:30.62714	17	Hardware	a400op.jpg	image/jpeg	45925	2010-01-17 22:05:30.116764
74	\N			2010-01-17 22:05:56.199391	2010-01-17 22:05:56.199391	17	Hardware	a400f.jpg	image/jpeg	30292	2010-01-17 22:05:55.736572
81	\N	ZX Spectrum+	New materials for the professional keyboard	2010-01-18 21:42:10.121819	2010-01-18 21:42:10.121819	10	Hardware	DPP_0035.JPG	image/jpeg	226786	2010-01-18 21:42:09.608023
84	\N	Raised Keyboard	Raising keyboard for comfort	2010-01-18 21:45:26.276307	2010-01-18 21:45:26.276307	10	Hardware	DPP_0041.JPG	image/jpeg	222847	2010-01-18 21:45:25.736724
85	\N			2010-01-19 02:08:29.455616	2010-01-19 02:08:29.455616	18	Hardware	mac512k.jpg	image/jpeg	104587	2010-01-19 02:08:28.765449
86	\N	The nice and small keyboard		2010-01-19 02:09:28.527707	2010-01-19 02:09:28.527707	18	Hardware	mac512kkb.jpg	image/jpeg	87456	2010-01-19 02:09:27.935011
87	\N	Side view		2010-01-19 02:10:00.298727	2010-01-19 02:10:00.298727	18	Hardware	mac512kside.jpg	image/jpeg	113956	2010-01-19 02:09:59.654186
88	\N			2010-01-19 02:10:44.865777	2010-01-19 02:10:44.865777	18	Hardware	mac512kdetail.jpg	image/jpeg	72209	2010-01-19 02:10:44.386161
89	\N	Some developers		2010-01-19 02:11:14.730944	2010-01-19 02:11:14.730944	18	Hardware	developers.jpg	image/jpeg	44542	2010-01-19 02:11:14.267367
90	\N	Back view		2010-01-19 10:11:58.931981	2010-01-19 10:11:58.931981	3	Hardware	c64back.jpg	image/jpeg	81832	2010-01-19 10:11:58.232905
91	\N	Side view		2010-01-19 10:12:23.8322	2010-01-19 10:12:23.8322	3	Hardware	c64side.jpg	image/jpeg	80349	2010-01-19 10:12:23.136345
92	\N			2010-01-19 10:23:06.330041	2010-01-19 10:23:06.330041	3	Hardware	c64other.jpg	image/jpeg	87081	2010-01-19 10:23:05.647463
93	\N			2010-01-19 10:51:37.933097	2010-01-19 10:51:37.933097	3	Hardware	c64.jpg	image/jpeg	81183	2010-01-19 10:51:37.316109
94	\N	The box		2010-01-19 10:57:23.710665	2010-01-19 10:57:23.710665	10	Hardware	zxplusbox.jpg	image/jpeg	122426	2010-01-19 10:57:22.853421
95	\N	Atari 400 Screen	Normal boot screen	2010-01-19 10:59:39.800641	2010-01-19 10:59:39.800641	17	Hardware	Atari400.png	image/png	916	2010-01-19 10:59:39.297055
98	\N	C16 Screen	Normal boot screen	2010-01-19 11:03:45.391938	2010-01-19 11:03:45.391938	6	Hardware	0000.png	image/png	1104	2010-01-19 11:03:44.921122
143	\N			2010-01-21 15:12:46.705892	2010-01-21 15:12:46.705892	27	Hardware	sfd-1001_1.jpg	image/jpeg	70030	2010-01-21 15:12:45.955095
102	\N			2010-01-19 13:14:53.867387	2010-01-19 13:14:53.867387	8	Hardware	zxspectrum.jpg	image/jpeg	72516	2010-01-19 13:14:53.241538
103	\N	The box		2010-01-19 13:15:31.406135	2010-01-19 13:15:31.406135	8	Hardware	zxspectrumbox.jpg	image/jpeg	111143	2010-01-19 13:15:30.658725
105	\N			2010-01-19 13:44:34.115357	2010-01-19 13:44:34.115357	7	Hardware	c128.jpg	image/jpeg	91620	2010-01-19 13:44:33.448414
106	\N			2010-01-19 13:45:13.845304	2010-01-19 13:45:13.845304	7	Hardware	c128det1.jpg	image/jpeg	101375	2010-01-19 13:45:13.099319
107	\N			2010-01-19 13:45:35.099682	2010-01-19 13:45:35.099682	7	Hardware	c128det2.jpg	image/jpeg	103561	2010-01-19 13:45:34.298803
108	\N			2010-01-19 13:46:04.119171	2010-01-19 13:46:04.119171	7	Hardware	c128back.jpg	image/jpeg	65748	2010-01-19 13:46:03.427916
109	\N			2010-01-19 13:46:31.623086	2010-01-19 13:46:31.623086	7	Hardware	c128box.jpg	image/jpeg	103302	2010-01-19 13:46:30.909342
110	\N	Boot screen		2010-01-19 14:18:03.956656	2010-01-19 14:18:03.956656	11	Hardware	picture.jpg	image/jpeg	6997	2010-01-19 14:18:03.447047
112	\N	ZX Spectrum		2010-01-20 22:13:08.408623	2010-01-20 22:13:08.408623	8	Hardware	DPP_0059.JPG	image/jpeg	195868	2010-01-20 22:13:07.902463
113	\N	Keyboard Closeup		2010-01-20 22:13:52.458768	2010-01-20 22:13:52.458768	8	Hardware	DPP_0063.JPG	image/jpeg	283060	2010-01-20 22:13:51.907356
114	\N	ZX Spectrum Back		2010-01-20 22:14:25.722335	2010-01-20 22:14:25.722335	8	Hardware	DPP_0064.JPG	image/jpeg	169192	2010-01-20 22:14:25.247513
115	\N	Spectrum stripes		2010-01-20 22:14:55.584458	2010-01-20 22:14:55.584458	8	Hardware	DPP_0065.JPG	image/jpeg	223658	2010-01-20 22:14:55.067154
116	\N	ZX Spectrum Logo		2010-01-20 22:15:43.294807	2010-01-20 22:15:43.294807	8	Hardware	DPP_0062.JPG	image/jpeg	218491	2010-01-20 22:15:42.773139
117	\N	ZX Spectrum+ Logo		2010-01-20 22:18:02.777614	2010-01-20 22:18:02.777614	10	Hardware	DPP_0068.JPG	image/jpeg	187150	2010-01-20 22:18:02.22793
118	\N	Keyboard Closeup		2010-01-20 22:18:39.766278	2010-01-20 22:18:39.766278	10	Hardware	DPP_0066.JPG	image/jpeg	259201	2010-01-20 22:18:39.241037
119	\N	Mic and Ear jack on ZX Spectrum + back		2010-01-20 22:19:18.78647	2010-01-20 22:19:18.78647	10	Hardware	DPP_0070.JPG	image/jpeg	152347	2010-01-20 22:19:18.286063
120	\N	ZX Spectrum Boot Screen		2010-01-20 22:21:46.637546	2010-01-20 22:21:46.637546	8	Hardware	0000.png	image/png	1083	2010-01-20 22:21:46.172925
125	\N			2010-01-21 04:03:38.356366	2010-01-21 04:03:38.356366	21	Hardware	1541IIa.jpg	image/jpeg	54540	2010-01-21 04:03:37.726411
126	\N			2010-01-21 04:04:02.640302	2010-01-21 04:04:02.640302	21	Hardware	1541a1.jpg	image/jpeg	109677	2010-01-21 04:04:01.95523
127	\N			2010-01-21 04:04:24.408088	2010-01-21 04:04:24.408088	21	Hardware	1541IIback.jpg	image/jpeg	98539	2010-01-21 04:04:23.731733
128	\N			2010-01-21 04:05:00.265625	2010-01-21 04:05:00.265625	21	Hardware	1541II.jpg	image/jpeg	97029	2010-01-21 04:04:59.594501
129	\N			2010-01-21 04:06:43.438839	2010-01-21 04:06:43.438839	22	Hardware	1581.jpg	image/jpeg	94519	2010-01-21 04:06:42.753602
130	\N			2010-01-21 04:07:05.396687	2010-01-21 04:07:05.396687	22	Hardware	1581box.jpg	image/jpeg	108130	2010-01-21 04:07:04.68495
131	\N			2010-01-21 04:07:27.824467	2010-01-21 04:07:27.824467	22	Hardware	1581front.jpg	image/jpeg	92460	2010-01-21 04:07:27.139064
132	\N			2010-01-21 04:07:47.408294	2010-01-21 04:07:47.408294	22	Hardware	1581back.jpg	image/jpeg	91243	2010-01-21 04:07:46.719656
133	\N			2010-01-21 04:23:51.770197	2010-01-21 04:23:51.770197	23	Hardware	amiga500.jpg	image/jpeg	77600	2010-01-21 04:23:51.116412
134	\N			2010-01-21 04:24:16.561801	2010-01-21 04:24:16.561801	23	Hardware	amiga500det.jpg	image/jpeg	96441	2010-01-21 04:24:15.854014
135	\N			2010-01-21 04:24:46.536622	2010-01-21 04:24:46.536622	23	Hardware	amiga500manuals.jpg	image/jpeg	81460	2010-01-21 04:24:45.870017
136	\N			2010-01-21 04:25:09.494386	2010-01-21 04:25:09.494386	23	Hardware	amiga500back.jpg	image/jpeg	92830	2010-01-21 04:25:08.836537
137	\N			2010-01-21 04:25:26.270695	2010-01-21 04:25:26.270695	23	Hardware	amiga500box.jpg	image/jpeg	92992	2010-01-21 04:25:25.547963
138	\N			2010-01-21 14:46:52.236377	2010-01-21 14:46:52.236377	26	Hardware	1570.jpg	image/jpeg	55922	2010-01-21 14:46:51.629707
139	\N			2010-01-21 14:47:11.495754	2010-01-21 14:47:11.495754	26	Hardware	1570front.jpg	image/jpeg	97439	2010-01-21 14:47:10.868205
140	\N			2010-01-21 14:47:32.105717	2010-01-21 14:47:32.105717	26	Hardware	1570back.jpg	image/jpeg	71068	2010-01-21 14:47:31.322206
141	\N			2010-01-21 14:55:34.107184	2010-01-21 14:55:34.107184	26	Hardware	1570inner.jpg	image/jpeg	130627	2010-01-21 14:55:33.426832
142	\N			2010-01-21 14:55:56.585725	2010-01-21 14:55:56.585725	26	Hardware	1570inner2.jpg	image/jpeg	165747	2010-01-21 14:55:55.91624
144	\N			2010-01-21 15:13:08.892358	2010-01-21 15:13:08.892358	27	Hardware	sfd-1001front.jpg	image/jpeg	81448	2010-01-21 15:13:08.234312
145	\N			2010-01-21 15:13:54.886273	2010-01-21 15:13:54.886273	27	Hardware	sfd-1001det.jpg	image/jpeg	63743	2010-01-21 15:13:54.21247
146	\N			2010-01-21 15:15:32.76695	2010-01-21 15:15:32.76695	27	Hardware	sfd-1001backj.jpg	image/jpeg	85238	2010-01-21 15:15:32.07966
147	\N			2010-01-21 15:17:00.195614	2010-01-21 15:17:00.195614	27	Hardware	sfd-1001open.jpg	image/jpeg	116317	2010-01-21 15:16:59.495978
148	\N			2010-01-21 15:17:38.633454	2010-01-21 15:17:38.633454	27	Hardware	sfd-1001opendet.jpg	image/jpeg	159449	2010-01-21 15:17:37.898721
149	\N			2010-01-21 15:45:43.75895	2010-01-21 15:45:43.75895	28	Hardware	disk2.jpg	image/jpeg	67655	2010-01-21 15:45:42.998232
150	\N			2010-01-21 15:46:10.218681	2010-01-21 15:46:10.218681	28	Hardware	diskII-fornt.jpg	image/jpeg	111618	2010-01-21 15:46:09.338986
151	\N			2010-01-21 15:46:49.508802	2010-01-21 15:46:49.508802	28	Hardware	disk2back.jpg	image/jpeg	150043	2010-01-21 15:46:48.778672
152	\N			2010-01-21 15:47:10.132706	2010-01-21 15:47:10.132706	28	Hardware	disk2inside.jpg	image/jpeg	118432	2010-01-21 15:47:09.380295
153	\N			2010-01-21 15:47:32.516054	2010-01-21 15:47:32.516054	28	Hardware	disk2side.jpg	image/jpeg	111970	2010-01-21 15:47:31.824086
154	\N			2010-01-21 15:56:45.151679	2010-01-21 15:56:45.151679	29	Hardware	c64c.jpg	image/jpeg	76410	2010-01-21 15:56:44.468737
155	\N			2010-01-21 15:57:07.258206	2010-01-21 15:57:07.258206	29	Hardware	c64cside.jpg	image/jpeg	110418	2010-01-21 15:57:06.54586
156	\N			2010-01-21 15:57:34.506143	2010-01-21 15:57:34.506143	29	Hardware	c64cbox.jpg	image/jpeg	96857	2010-01-21 15:57:33.637868
157	\N			2010-01-21 15:57:59.714069	2010-01-21 15:57:59.714069	29	Hardware	c64cboxback.jpg	image/jpeg	120646	2010-01-21 15:57:58.997499
158	\N			2010-01-21 15:58:20.09308	2010-01-21 15:58:20.09308	29	Hardware	c64cdet1.jpg	image/jpeg	107709	2010-01-21 15:58:19.34462
159	\N			2010-01-21 15:59:21.228875	2010-01-21 15:59:21.228875	29	Hardware	c64cdet.jpg	image/jpeg	97362	2010-01-21 15:59:20.494632
160	\N			2010-01-21 16:01:42.382623	2010-01-21 16:01:42.382623	30	Hardware	datassette1.jpg	image/jpeg	73415	2010-01-21 16:01:41.632335
161	\N			2010-01-21 16:09:07.119452	2010-01-21 16:09:07.119452	31	Hardware	duodisk-front.jpg	image/jpeg	80163	2010-01-21 16:09:06.512358
162	\N			2010-01-21 16:09:30.367223	2010-01-21 16:09:30.367223	31	Hardware	duodisk.jpg	image/jpeg	66842	2010-01-21 16:09:29.746257
163	\N			2010-01-21 16:09:53.247848	2010-01-21 16:09:53.247848	31	Hardware	duodisk-det1.jpg	image/jpeg	90723	2010-01-21 16:09:52.344718
164	\N			2010-01-21 16:10:13.908811	2010-01-21 16:10:13.908811	31	Hardware	duodisk-det.jpg	image/jpeg	108981	2010-01-21 16:10:13.222692
121	\N	Commodore 1541 with Alps mechanism		2010-01-21 03:57:51.390645	2010-01-21 18:22:28.858615	20	Hardware	1541.jpg	image/jpeg	64375	2010-01-21 03:57:50.738746
165	\N			2010-01-21 23:44:16.454393	2010-01-21 23:44:16.454393	20	Hardware	1541box.jpg	image/jpeg	91957	2010-01-21 23:44:15.761175
166	\N			2010-01-21 23:44:38.010224	2010-01-21 23:44:38.010224	20	Hardware	1541back.jpg	image/jpeg	84630	2010-01-21 23:44:37.312398
167	\N			2010-01-21 23:45:23.802505	2010-01-21 23:45:23.802505	20	Hardware	1541manual.jpg	image/jpeg	51144	2010-01-21 23:45:22.002429
211	\N			2010-01-31 12:32:25.494496	2010-01-31 12:32:25.494496	50	Hardware	a3drive.jpg	image/jpeg	86468	2010-01-31 12:32:24.806799
172	\N			2010-01-23 20:10:42.504823	2010-01-23 20:10:42.504823	36	Hardware	amiga1200.jpg	image/jpeg	73871	2010-01-23 20:10:41.812109
173	\N			2010-01-23 20:11:01.937773	2010-01-23 20:11:01.937773	36	Hardware	amiga1200det.jpg	image/jpeg	103651	2010-01-23 20:11:01.086927
174	\N			2010-01-23 20:11:22.193282	2010-01-23 20:11:22.193282	36	Hardware	amiga1200det1.jpg	image/jpeg	101282	2010-01-23 20:11:21.369502
175	\N			2010-01-23 20:48:02.849516	2010-01-23 20:48:02.849516	37	Hardware	appleIIjoystick.jpg	image/jpeg	63177	2010-01-23 20:48:02.097181
176	\N			2010-01-23 21:41:08.670345	2010-01-23 21:41:08.670345	38	Hardware	keyboard-II-complete.jpg	image/jpeg	65688	2010-01-23 21:41:07.991956
177	\N			2010-01-23 21:41:29.902215	2010-01-23 21:41:29.902215	38	Hardware	keyboard-II.jpg	image/jpeg	98943	2010-01-23 21:41:29.149179
179	\N	Boot screen	PET 2001 8K boot screen	2010-01-23 22:54:21.380242	2010-01-23 22:54:21.380242	2	Hardware	pet2001screen.jpg	image/jpeg	9290	2010-01-23 22:54:20.942275
180	\N	Boot screen		2010-01-23 23:00:25.960956	2010-01-23 23:00:25.960956	4	Hardware	vic20screen.gif	image/gif	1710	2010-01-23 23:00:25.374277
181	\N	C128 40 Column Boot Screen		2010-01-23 23:12:34.243509	2010-01-23 23:12:34.243509	7	Hardware	c128screen.gif	image/gif	4631	2010-01-23 23:12:33.554559
182	\N	C128 80 Column Boot Screen		2010-01-23 23:16:50.555431	2010-01-23 23:16:50.555431	7	Hardware	c128screen80.gif	image/gif	8290	2010-01-23 23:16:48.879076
183	\N	Apple IIc is asking for software (Boot Screen)		2010-01-24 01:03:46.38357	2010-01-24 01:04:05.428563	9	Hardware	2cboot.gif	image/gif	2978	2010-01-24 01:03:45.745127
184	\N	Apple IIc Pro DOS 3.3 loaded		2010-01-24 01:07:10.287979	2010-01-24 01:07:10.287979	9	Hardware	a2cprodos.gif	image/gif	7842	2010-01-24 01:07:09.831071
185	\N			2010-01-26 14:20:44.081618	2010-01-26 14:20:44.081618	25	Hardware	1541c.jpg	image/jpeg	48409	2010-01-26 14:20:43.493569
186	\N			2010-01-26 14:21:07.855009	2010-01-26 14:21:07.855009	25	Hardware	1541cfront.jpg	image/jpeg	119081	2010-01-26 14:21:07.183662
187	\N			2010-01-26 14:21:29.872203	2010-01-26 14:21:29.872203	25	Hardware	1541cback.jpg	image/jpeg	104526	2010-01-26 14:21:29.197302
188	\N			2010-01-27 11:31:24.103788	2010-01-27 11:31:24.103788	45	Hardware	a1010.jpg	image/jpeg	73321	2010-01-27 11:31:23.39792
189	\N			2010-01-27 11:31:46.32973	2010-01-27 11:31:46.32973	45	Hardware	a1010front.jpg	image/jpeg	128803	2010-01-27 11:31:45.578894
190	\N			2010-01-27 11:32:08.627684	2010-01-27 11:32:08.627684	45	Hardware	a1010det.jpg	image/jpeg	90292	2010-01-27 11:32:07.915031
191	\N			2010-01-27 11:33:25.980699	2010-01-27 11:33:25.980699	39	Hardware	zx81front.jpg	image/jpeg	103113	2010-01-27 11:33:25.289245
193	\N			2010-01-27 11:34:10.90755	2010-01-27 11:34:10.90755	39	Hardware	zx81det.jpg	image/jpeg	85020	2010-01-27 11:34:10.326728
194	\N			2010-01-27 11:34:31.448227	2010-01-27 11:34:31.448227	39	Hardware	zx81.jpg	image/jpeg	74257	2010-01-27 11:34:30.810802
192	\N	ZX81 tape connectors side view		2010-01-27 11:33:48.748285	2010-01-27 11:35:25.553783	39	Hardware	zx81side.jpg	image/jpeg	116775	2010-01-27 11:33:48.091036
195	\N			2010-01-27 11:40:31.978539	2010-01-27 11:40:31.978539	46	Hardware	appleIIeuroplus.jpg	image/jpeg	87408	2010-01-27 11:40:31.224013
196	\N	Side view		2010-01-27 11:40:57.402348	2010-01-27 11:40:57.402348	46	Hardware	appleIIeuroplusside.jpg	image/jpeg	63170	2010-01-27 11:40:56.800431
197	\N	Back view		2010-01-27 11:41:25.649807	2010-01-27 11:41:25.649807	46	Hardware	appleIIeuroplusback.jpg	image/jpeg	60774	2010-01-27 11:41:25.045052
198	\N			2010-01-27 11:44:51.440871	2010-01-27 11:44:51.440871	47	Hardware	3022.jpg	image/jpeg	84016	2010-01-27 11:44:50.781573
199	\N	The back of the printer		2010-01-27 11:45:21.937466	2010-01-27 11:45:21.937466	47	Hardware	3022back.jpg	image/jpeg	88528	2010-01-27 11:45:21.267995
200	\N			2010-01-27 11:45:39.931699	2010-01-27 11:45:39.931699	47	Hardware	3022det.jpg	image/jpeg	121139	2010-01-27 11:45:39.197097
201	\N			2010-01-27 11:45:55.111605	2010-01-27 11:45:55.111605	47	Hardware	3022det1.jpg	image/jpeg	72929	2010-01-27 11:45:54.419195
202	\N			2010-01-27 11:49:01.922879	2010-01-27 11:49:01.922879	48	Hardware	disk3.5top.jpg	image/jpeg	59735	2010-01-27 11:49:01.210344
203	\N			2010-01-27 11:49:52.572071	2010-01-27 11:49:52.572071	48	Hardware	disk3.5front.jpg	image/jpeg	74656	2010-01-27 11:49:51.932027
204	\N			2010-01-27 12:28:28.842089	2010-01-27 12:28:28.842089	49	Hardware	unidisk.jpg	image/jpeg	70460	2010-01-27 12:28:28.171311
206	\N	Back view		2010-01-27 12:29:26.583185	2010-01-27 12:29:26.583185	49	Hardware	unidisk_back.jpg	image/jpeg	47870	2010-01-27 12:29:25.94769
205	\N	Front view		2010-01-27 12:28:59.633571	2010-01-27 12:29:45.948933	49	Hardware	unidisk_front.jpg	image/jpeg	89423	2010-01-27 12:28:58.89426
207	\N			2010-01-27 12:30:14.906874	2010-01-27 12:30:14.906874	49	Hardware	unidisktop.jpg	image/jpeg	54700	2010-01-27 12:30:14.083407
208	\N			2010-01-27 12:41:53.821461	2010-01-27 12:41:53.821461	51	Hardware	apple5.25drive.jpg	image/jpeg	99814	2010-01-27 12:41:53.061307
209	\N			2010-01-27 12:42:15.632038	2010-01-27 12:42:15.632038	51	Hardware	apple5.25front.jpg	image/jpeg	106501	2010-01-27 12:42:14.880933
210	\N			2010-01-27 12:42:51.901812	2010-01-27 12:42:51.901812	51	Hardware	apple5.25.jpg	image/jpeg	56291	2010-01-27 12:42:51.298696
212	\N			2010-01-31 12:32:55.313781	2010-01-31 12:32:55.313781	50	Hardware	a3drivefront.jpg	image/jpeg	92853	2010-01-31 12:32:54.630532
213	\N			2010-01-31 12:33:16.695878	2010-01-31 12:33:16.695878	50	Hardware	a3driveback.jpg	image/jpeg	99915	2010-01-31 12:33:16.043983
215	\N	Disk III in a Disk II like case		2010-01-31 12:34:29.619784	2010-01-31 12:35:20.66524	50	Hardware	a3driveIItop.jpg	image/jpeg	80017	2010-01-31 12:34:28.949253
216	\N	Model and serial number of this weird Apple III Disk drive		2010-01-31 12:34:58.197114	2010-01-31 12:36:01.177179	50	Hardware	a3driveII.jpg	image/jpeg	132512	2010-01-31 12:34:57.492874
214	\N	The disk drive after removing the case and the metal cage		2010-01-31 12:33:54.611774	2010-01-31 12:36:34.343935	50	Hardware	a3driveopen.jpg	image/jpeg	126735	2010-01-31 12:33:53.845431
217	\N			2010-01-31 12:41:15.007454	2010-01-31 12:41:15.007454	55	Hardware	c64gfront.jpg	image/jpeg	80500	2010-01-31 12:41:14.401099
218	\N			2010-01-31 12:41:36.433559	2010-01-31 12:41:36.433559	55	Hardware	c64gdet.jpg	image/jpeg	121661	2010-01-31 12:41:35.735183
219	\N			2010-01-31 12:42:01.204468	2010-01-31 12:42:01.204468	55	Hardware	c64gfront.jpg	image/jpeg	80500	2010-01-31 12:42:00.626286
220	\N			2010-01-31 12:42:23.383409	2010-01-31 12:42:23.383409	55	Hardware	c64gback.jpg	image/jpeg	111513	2010-01-31 12:42:22.722932
221	\N			2010-01-31 12:42:47.535588	2010-01-31 12:42:47.535588	55	Hardware	c64gdet1.jpg	image/jpeg	86861	2010-01-31 12:42:46.857589
222	\N			2010-01-31 13:19:11.95019	2010-01-31 13:19:11.95019	58	Hardware	zxmicro.jpg	image/jpeg	70193	2010-01-31 13:19:11.258739
223	\N			2010-01-31 13:19:32.123397	2010-01-31 13:19:32.123397	58	Hardware	zxmicro1.jpg	image/jpeg	89350	2010-01-31 13:19:31.47441
224	\N			2010-01-31 13:19:52.36609	2010-01-31 13:19:52.36609	58	Hardware	zxmicrotop.jpg	image/jpeg	63023	2010-01-31 13:19:51.5896
225	\N			2010-01-31 13:23:14.014226	2010-01-31 13:23:14.014226	59	Hardware	1531box.jpg	image/jpeg	107884	2010-01-31 13:23:13.350205
226	\N			2010-01-31 13:23:37.495023	2010-01-31 13:23:37.495023	59	Hardware	1531.jpg	image/jpeg	143383	2010-01-31 13:23:36.779198
227	\N			2010-01-31 13:25:34.744492	2010-01-31 13:25:34.744492	60	Hardware	1530box.jpg	image/jpeg	110881	2010-01-31 13:25:34.033495
228	\N			2010-01-31 13:25:57.199924	2010-01-31 13:25:57.199924	60	Hardware	1530.jpg	image/jpeg	115490	2010-01-31 13:25:56.515654
229	\N	Amiga 1200 box		2010-01-31 14:30:22.910026	2010-01-31 14:30:22.910026	36	Hardware	a1200box.jpg	image/jpeg	143958	2010-01-31 14:30:22.193476
230	\N			2010-01-31 14:38:35.394655	2010-01-31 14:38:35.394655	61	Hardware	mz711.jpg	image/jpeg	77616	2010-01-31 14:38:34.767537
231	\N	Sharp MZ711 back		2010-01-31 14:39:09.345651	2010-01-31 14:39:09.345651	61	Hardware	mz711back.jpg	image/jpeg	91195	2010-01-31 14:39:08.653623
232	\N	Video connectors detail		2010-01-31 14:40:07.720871	2010-01-31 14:40:07.720871	61	Hardware	mz711det3.jpg	image/jpeg	87916	2010-01-31 14:40:07.090332
233	\N	I/O Bus connector detail		2010-01-31 14:40:41.785825	2010-01-31 14:40:41.785825	61	Hardware	mz711det2.jpg	image/jpeg	88248	2010-01-31 14:40:41.139666
234	\N			2010-01-31 14:41:09.546241	2010-01-31 14:41:09.546241	61	Hardware	mz711det4.jpg	image/jpeg	127154	2010-01-31 14:41:08.848923
235	\N			2010-01-31 14:42:26.199914	2010-01-31 14:42:26.199914	61	Hardware	mz711det5.jpg	image/jpeg	93834	2010-01-31 14:42:25.521297
236	\N			2010-01-31 14:42:55.098051	2010-01-31 14:42:55.098051	61	Hardware	mz711manual.jpg	image/jpeg	89839	2010-01-31 14:42:54.420221
237	\N			2010-01-31 14:43:46.583553	2010-01-31 14:43:46.583553	61	Hardware	mz711box.jpg	image/jpeg	180816	2010-01-31 14:43:45.880515
238	\N			2010-01-31 15:36:39.163978	2010-01-31 15:36:39.163978	34	Hardware	a3.jpg	image/jpeg	70053	2010-01-31 15:36:38.5437
239	\N	Apple III back		2010-01-31 15:37:14.398456	2010-01-31 15:37:14.398456	34	Hardware	a3back.jpg	image/jpeg	101236	2010-01-31 15:37:13.756974
240	\N	Apple III with cover removed		2010-01-31 15:37:52.187214	2010-01-31 15:37:52.187214	34	Hardware	a3inside.jpg	image/jpeg	135586	2010-01-31 15:37:51.480592
241	\N	Apple III motherboard		2010-01-31 15:38:36.872207	2010-01-31 15:38:36.872207	34	Hardware	a3mb.jpg	image/jpeg	119218	2010-01-31 15:38:36.202233
242	\N	Back view of the motherboard		2010-01-31 15:39:17.009519	2010-01-31 15:39:17.009519	34	Hardware	a3mbdet.jpg	image/jpeg	179465	2010-01-31 15:39:16.329641
243	\N	Apple III internal PSU		2010-01-31 15:39:48.064846	2010-01-31 15:39:48.064846	34	Hardware	a3psu.jpg	image/jpeg	109752	2010-01-31 15:39:47.343319
244	\N			2010-01-31 20:48:59.82413	2010-01-31 20:48:59.82413	42	Hardware	8296.jpg	image/jpeg	111885	2010-01-31 20:48:59.156212
245	\N			2010-01-31 20:49:38.551361	2010-01-31 20:49:38.551361	42	Hardware	8296back.jpg	image/jpeg	100088	2010-01-31 20:49:37.923134
246	\N			2010-01-31 20:50:17.612351	2010-01-31 20:50:17.612351	57	Hardware	8296d.jpg	image/jpeg	115311	2010-01-31 20:50:16.885726
247	\N			2010-01-31 20:50:44.421858	2010-01-31 20:50:44.421858	57	Hardware	8296d_1.jpg	image/jpeg	75279	2010-01-31 20:50:43.782937
248	\N			2010-01-31 20:51:03.657135	2010-01-31 20:51:03.657135	57	Hardware	8296dside.jpg	image/jpeg	100243	2010-01-31 20:51:03.00124
\.


--
-- Data for Name: io_ports; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY io_ports (id, name, connector, created_at, updated_at) FROM stdin;
39	S/VIDEO	DIN 8-pin	2010-01-21 21:51:15.732036	2010-01-21 21:51:42.196203
40	Expansion Port	Zorro II	2010-01-21 23:04:07.662687	2010-01-21 23:04:07.662687
38	Serial Port	RS-232	2010-01-21 17:24:06.911085	2010-01-22 23:17:43.565673
42	Macintosh External Floppy Port	Proprietary Port	2010-01-22 23:18:27.430391	2010-01-22 23:18:27.430391
24	RF antenna	RCA	2010-01-11 21:51:22.196622	2010-01-11 21:51:22.196622
17	Serial Port	Cannon DB-25 Female	2010-01-11 10:09:47.206931	2010-01-23 20:05:00.498768
43	Serial Port	Cannon DB-25 Male	2010-01-23 20:07:03.984733	2010-01-23 20:07:03.984733
41	RGB Video	Cannon DA-15	2010-01-22 23:15:42.657281	2010-01-23 20:22:39.170581
18	Disk Drive	Cannon DB-23	2010-01-11 10:10:53.474225	2010-01-23 20:23:03.12524
30	Macintosh External Floppy Port	DB-19	2010-01-18 12:56:26.116112	2010-01-18 12:59:33.263254
29	Macintosh Serial Port	DE-9	2010-01-18 12:56:08.709913	2010-01-18 15:50:16.537118
44	Serial Port	DIN 5 pins 	2010-01-23 20:25:47.011903	2010-01-23 20:51:05.41108
45	Disk Drive	DB-19	2010-01-23 20:53:08.1745	2010-01-23 20:53:08.1745
46	Apple ADB	mini-DIN 4 pins	2010-01-23 21:43:52.119996	2010-01-23 21:43:52.119996
47	PAL/SECAM card expansion port		2010-01-27 11:39:29.068632	2010-01-27 11:39:29.068632
19	Parallel Port	Cannon DB-25 Male	2010-01-11 10:11:45.083963	2010-01-18 15:52:01.844112
21	I/O Port	IEEE 488	2010-01-11 10:46:17.809857	2010-01-31 14:16:57.726007
13	Audio OUT	RCA	2010-01-11 10:03:16.258547	2010-01-18 15:54:02.828733
8	Audio OUT	mini-jack	2010-01-08 02:56:55.756586	2010-01-18 15:54:14.232648
7	Audio IN	mini-jack	2010-01-08 02:56:55.729542	2010-01-18 15:54:19.028058
26	Cartridge Slot		2010-01-11 21:53:38.402706	2010-01-18 15:54:38.694294
10	Disk Drive	DIN 8-pin	2010-01-08 02:56:55.76419	2010-01-18 15:55:59.332917
27	Expansion Slot	Edge	2010-01-13 18:08:00.037434	2010-01-18 15:56:14.587858
48	I/O Bus	Edge	2010-01-31 14:17:15.24067	2010-01-31 14:17:15.24067
15	Keyboard	RJ11	2010-01-11 10:07:24.559126	2010-01-18 15:56:35.604054
49	Printer	Edge	2010-01-31 14:17:28.357557	2010-01-31 14:17:28.357557
11	Parallel Port	Centronics	2010-01-08 02:56:55.767822	2010-01-18 15:57:08.602391
12	Serial Port	DE-9	2010-01-08 02:56:55.771468	2010-01-18 15:57:17.38292
23	Serial Port	DIN 6-pin	2010-01-11 21:49:16.341217	2010-01-18 15:57:27.137567
28	System Bus	S-100 Edge	2010-01-17 21:46:50.011634	2010-01-18 15:57:43.434833
20	Tape Recorder		2010-01-11 10:41:00.902722	2010-01-18 15:57:55.761264
22	User Port		2010-01-11 10:46:28.629983	2010-01-18 15:58:02.64876
9	Video OUT	DIN 8-pin	2010-01-08 02:56:55.760329	2010-01-18 15:58:26.703479
16	TV Mod	DIN 8-pin	2010-01-11 10:07:56.679771	2010-01-18 15:58:41.683249
14	Video OUT	RCA	2010-01-11 10:03:28.140432	2010-01-18 15:58:50.715705
50	Joystick Port	IDC 5-pin Male	2010-01-31 14:21:09.829512	2010-01-31 14:21:49.650561
51	Disk Drive	IDC 26-pin Male	2010-01-31 16:07:50.778075	2010-01-31 16:07:50.778075
32	Expansion Port	Edge	2010-01-19 13:51:17.592076	2010-01-19 13:51:17.592076
33	RGBI	Cannon DB-9	2010-01-19 13:52:08.747	2010-01-19 13:52:22.560945
35	RGB Video	Cannon DB-23 Male	2010-01-21 11:44:51.338665	2010-01-21 11:44:51.338665
36	Parallel Port	Cannon DB-25 Female	2010-01-21 11:48:04.259788	2010-01-21 11:48:04.259788
25	Game Port	Cannon DE-9 Male	2010-01-11 21:52:57.441691	2010-01-21 11:57:48.440365
34	Mouse Port	Cannon DE-9 Male	2010-01-21 11:37:53.072478	2010-01-21 11:58:06.129076
\.


--
-- Data for Name: manufacturers; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY manufacturers (id, name, country_id, created_at, updated_at, description, logo_file_name, logo_content_type, logo_file_size, logo_update_at) FROM stdin;
8	Intel	USA	2010-01-08 02:56:53.679242	2010-01-08 02:56:53.679242	\N	intel.png	image/png	2991	\N
9	Motorola	USA	2010-01-08 02:56:53.870223	2010-01-08 02:56:53.870223	\N	motorola.png	image/png	621	\N
10	Atari	USA	2010-01-08 02:56:54.186319	2010-01-08 02:56:54.186319	\N	atari.png	image/png	1827	\N
13	Sinclair	Great Britain	2010-01-08 02:56:54.831372	2010-01-08 02:56:54.831372	\N	sinclair.png	image/png	1030	\N
15	MOS Technology	USA	2010-01-10 22:33:45.130312	2010-01-10 22:33:45.130312	MOS Technology was an early CPU manufacturing company founded by Chuck Peddle in 1974. In 1976 MOS Technology was bought by Commodore Business Machines that changed its name to Commodore Semiconductor Group (CSG).	mos-technology.jpg	image/jpeg	1629	\N
21	Ferranti	Great Britain	2010-01-23 21:50:34.966286	2010-01-23 21:59:59.916239	Ferranti is a semiconductors company  based in the UK that produced the famous ULA chip that can be found in many Sinclair home computer of the 80s. 	ferranti	image/jpeg	757	\N
16	CSG	USA	2010-01-11 00:08:21.895358	2010-01-11 00:14:22.053174	After purchasing MOS Technologies Commodore Business Machines renamed it Commodore Semiconductor Group (CSG). Chips produced were stamped with the original MOS logo until 1989.	mos-technology.jpg	image/jpeg	1629	\N
22	Digital Equipment Corporation	USA	2010-01-24 01:22:53.591041	2010-01-24 01:22:53.591041		\N	\N	\N	\N
23	Sharp	Japan	2010-01-31 14:11:23.788925	2010-01-31 14:14:09.843921	Sharp is a Japanese corporation very active in the global electronic market. Sharp was founded in 1912, in  1964 produced the first transistor only calculator and in 1974 the first LCD screen calculator. During the last 70s Sharp entered the computer market and it produced many home and personal computer throughout the 80s and 90s.	sharp.jpg	image/jpeg	2726	\N
17	NEC Corporation	Japan	2010-01-14 13:48:21.880033	2010-01-15 15:07:34.34509	NEC (Nippon Electronic Company before 1983) is a Japan IT company that was origially founded in 1898. One of its division is specialized in semiconductor (NEC Semiconductor).	256px-NEC_logo.SVG.png	image/png	2862	\N
14	ZiLOG	USA	2010-01-08 02:56:55.02953	2010-01-15 18:09:09.62171	Zilog is an embedded boards and microcontrollers manufacturer. One of the most famous product actually used in a lot of solutions is the 8BIT CPU Z80. 	zilog.png	image/png	949	\N
12	Commodore	USA	2010-01-08 02:56:54.560887	2010-01-17 15:25:19.843976	Commodore was founded in the mid 50s by Jack Tramiel in Toronto, Canada. Initially Commodore produced typewriters, later in the 70s switched to the electronic calculators market and later they started to produced microchips. In 1976 Commodore acquired MOS Technology and finished the development of the PET personal computer. During the 80s Commodore became one of the most important manufacturers of personal and home computers, but due to bad management in the early 90s was forced to declare bankruptcy.	commodore.png	image/png	1283	\N
11	Apple Computers	USA	2010-01-08 02:56:54.361474	2010-01-17 15:43:37.759105	Apple is one of the most famous and successful computer companies with more than 30 years of history. It was founded in Cupertino, California by Steve Wozniak and Steve Jobs in 1976.	apple-computers.png	image/png	1751	\N
18	MITS	USA	2010-01-17 21:34:38.800371	2010-01-17 21:40:39.229564	MITS (Micro Instrumentation and Telemetry Systems) was founded by Ed Roberts and Forrest Mims in 1969. It is well known for having been the first company to develop and produce a microcomputer system, the Altair 8800.	mits.jpg	image/jpeg	1236	\N
19	Hitachi	Japan	2010-01-19 10:39:55.489321	2010-01-19 10:39:55.489321	Hitachi is a multinational company known in the retrocomputing scene for their semiconductor and CPUs production.	hitachi.png	image/png	3304	\N
20	Synertek	USA	2010-01-22 22:23:20.876757	2010-01-22 22:23:20.876757	Synertek is a semiconductor company founded by Bob Schreiner (from fairchild) and others. Is known principally for the 6502 clone production.	synertek-name.png	image/png	5661	\N
\.


--
-- Data for Name: operative_systems; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY operative_systems (id, name, created_at, updated_at) FROM stdin;
7	AmigaDOS	2010-01-08 02:56:55.514904	2010-01-08 02:56:55.514904
9	GEOS	2010-01-08 02:56:55.522017	2010-01-08 02:56:55.522017
22	TOS	2010-01-18 15:45:05.440695	2010-01-23 20:39:26.149967
26	Apple SOS	2010-01-22 23:12:36.669692	2010-01-23 20:40:44.214635
13	System/Mac OS	2010-01-18 12:31:44.908815	2010-01-23 21:29:38.791055
12	Apple DOS 3.3	2010-01-13 18:46:14.488895	2010-01-31 16:10:12.693795
10	Digital Research GEM	2010-01-08 02:56:55.525386	2010-01-31 16:10:33.437687
8	Apple Pro-DOS	2010-01-08 02:56:55.518519	2010-01-31 16:10:52.393053
11	Digital Research CP/M	2010-01-13 11:37:48.350881	2010-01-31 16:11:16.57331
\.


--
-- Data for Name: original_prices; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY original_prices (id, currency_id, country_id, date, amount, purchaseable_id, purchaseable_type, created_at, updated_at, tainted) FROM stdin;
1	USD	USA	1985-09-01	1295.00	1	Hardware	2010-01-10 23:44:35.114267	2010-01-10 23:44:35.114267	\N
2	USD	USA	1982-08-01	595.00	3	Hardware	2010-01-11 22:04:05.620719	2010-01-11 22:04:05.620719	\N
3	USD	USA	1981-05-01	300.00	4	Hardware	2010-01-12 21:24:47.960134	2010-01-12 21:24:47.960134	\N
4	USD	USA	1983-01-01	1270.00	5	Hardware	2010-01-12 22:00:51.38566	2010-01-12 22:00:51.38566	\N
6	ITL	Italy	1984-01-01	398000.00	8	Hardware	2010-01-13 17:59:44.722499	2010-01-13 17:59:44.722499	\N
7	GBP	Great Britain	1982-04-01	125.00	8	Hardware	2010-01-13 18:11:14.59003	2010-01-13 18:11:14.59003	\N
8	GBP	Great Britain	1984-10-01	179.95	10	Hardware	2010-01-15 16:17:42.992107	2010-01-15 16:17:42.992107	\N
9	USD	USA	1975-02-01	395.00	16	Hardware	2010-01-17 21:45:01.448148	2010-01-17 21:45:01.448148	\N
10	USD	USA	1975-02-01	495.00	16	Hardware	2010-01-17 21:45:23.537376	2010-01-17 21:45:23.537376	\N
5	ITL	Italy	1985-01-01	670000.00	3	Hardware	2010-01-13 10:23:52.204807	2010-01-17 21:45:36.380824	\N
14	ITL	Italy	1984-07-01	4499350.00	18	Hardware	2010-01-18 22:12:29.317612	2010-01-18 22:12:29.317612	\N
15	ITL	Italy	1981-10-01	3308200.00	11	Hardware	2010-01-18 22:17:51.733898	2010-01-18 22:17:51.733898	\N
16	USD	USA	1981-08-01	1495.00	11	Hardware	2010-01-18 22:23:19.407169	2010-01-18 22:23:19.407169	\N
17	ITL	Italy	1986-06-01	3558100.00	1	Hardware	2010-01-18 22:29:03.599543	2010-01-18 22:29:03.599543	\N
18	ITL	Italy	1984-07-01	2399350.00	9	Hardware	2010-01-18 22:33:09.847836	2010-01-18 22:33:09.847836	\N
19	ITL	Italy	1985-12-01	650000.00	7	Hardware	2010-01-18 22:42:14.661613	2010-01-18 22:42:14.661613	\N
20	USD	USA	1984-01-01	2495.00	18	Hardware	2010-01-19 02:12:37.874782	2010-01-19 02:12:37.874782	\N
21	USD	USA	1984-09-01	3200.00	19	Hardware	2010-01-20 22:47:35.837224	2010-01-20 22:47:35.837224	\N
22	ITL	Italy	1985-01-01	5990350.00	19	Hardware	2010-01-20 22:49:41.538424	2010-01-20 22:49:41.538424	\N
23	USD	USA	1982-08-01	400.00	21	Hardware	2010-01-21 11:28:47.093474	2010-01-21 11:28:47.093474	\N
24	ITL	Italy	1986-01-01	1400000.00	24	Hardware	2010-01-21 16:22:23.822937	2010-01-21 16:22:23.822937	\N
25	USD	USA	1985-12-01	500.00	24	Hardware	2010-01-21 16:44:51.115173	2010-01-21 16:44:51.115173	\N
26	ITL	Italy	1983-10-01	1650000.00	32	Hardware	2010-01-21 17:29:45.865714	2010-01-21 17:29:45.865714	\N
27	USD	USA	1984-01-01	995.00	32	Hardware	2010-01-21 17:40:15.320492	2010-01-21 17:40:15.320492	\N
28	ITL	Italy	1986-07-01	350000.00	29	Hardware	2010-01-21 20:14:06.760191	2010-01-21 20:14:06.760191	\N
29	ITL	Italy	1985-02-01	250000.00	6	Hardware	2010-01-21 20:51:58.314419	2010-01-21 20:51:58.314419	\N
30	USD	USA	1984-10-01	99.00	6	Hardware	2010-01-21 21:00:20.070495	2010-01-21 21:00:20.070495	\N
31	ITL	Italy	1981-12-01	5432000.00	34	Hardware	2010-01-22 23:21:26.348179	2010-01-22 23:21:26.348179	\N
32	USD	USA	1980-05-01	7800.00	34	Hardware	2010-01-22 23:28:28.166442	2010-01-22 23:28:28.166442	\N
33	ITL	Italy	1981-10-01	2990000.00	44	Hardware	2010-01-24 22:48:23.274063	2010-01-24 22:48:23.274063	\N
34	USD	USA	1981-01-01	1695.00	44	Hardware	2010-01-24 22:50:02.777128	2010-01-24 22:50:02.777128	\N
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY schema_migrations (version) FROM stdin;
20091017184650
20091017195523
20091017204159
20091018101012
20091019101028
20091019210514
20091020071137
20091020102040
20091020123627
20091020210529
20091020221409
20091021084622
20091021090753
20091021164045
20091022085452
20091022134240
20091022135458
20091022142130
20091022211043
20091027155025
20091031082449
20091031102156
20091102103451
20091102163501
20091105133625
20091105140350
20091105145135
20091105151158
20091106112605
20091114093218
20091114215425
20091115115854
20091115175455
20091120100243
20091122141527
20091206184110
20091206184129
20091206192620
20091212162903
20100105180917
20100105193457
20100105195527
20100106020823
20100125183536
20100131230945
\.


--
-- Data for Name: storage_formats; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY storage_formats (name, created_at, updated_at) FROM stdin;
3"	2010-01-08 02:56:55.57522	2010-01-08 02:56:55.57522
8"	2010-01-08 02:56:55.578857	2010-01-08 02:56:55.578857
audiocassette	2010-01-11 10:36:39.651912	2010-01-11 10:36:39.651912
3.5'' Single Side	2010-01-18 13:02:33.347545	2010-01-18 13:02:33.347545
3.5" Double Side	2010-01-19 01:50:36.166443	2010-01-19 01:50:36.166443
5.25" Single Side	2010-01-19 01:50:58.691108	2010-01-19 01:50:58.691108
5.25" Double Side	2010-01-19 01:51:13.476594	2010-01-19 01:51:13.476594
HDD	2010-01-28 21:24:04.095271	2010-01-28 21:24:04.095271
SCSI	2010-01-28 21:25:12.275655	2010-01-28 21:25:12.275655
\.


--
-- Data for Name: storage_names; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY storage_names (name, created_at, updated_at) FROM stdin;
floppy disk drive	2010-01-08 02:56:55.538662	2010-01-08 02:56:55.538662
tape drive	2010-01-08 02:56:55.5551	2010-01-08 02:56:55.5551
hard disk drive	2010-01-08 02:56:55.55862	2010-01-08 02:56:55.55862
\.


--
-- Data for Name: storage_sizes; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY storage_sizes (name, created_at, updated_at) FROM stdin;
360Kb	2010-01-08 02:56:55.584709	2010-01-08 02:56:55.584709
880Kb	2010-01-08 02:56:55.591476	2010-01-08 02:56:55.591476
720Kb	2010-01-08 02:56:55.594942	2010-01-08 02:56:55.594942
180Kb	2010-01-08 02:56:55.598451	2010-01-08 02:56:55.598451
140Kb	2010-01-08 02:56:55.601942	2010-01-08 02:56:55.601942
1.2Mb	2010-01-08 02:56:55.605681	2010-01-08 02:56:55.605681
1.44Mb	2010-01-08 02:56:55.609686	2010-01-08 02:56:55.609686
5Mb	2010-01-08 02:56:55.626555	2010-01-08 02:56:55.626555
10Mb	2010-01-08 02:56:55.630037	2010-01-08 02:56:55.630037
20Mb	2010-01-08 02:56:55.640444	2010-01-08 02:56:55.640444
1Mb	2010-01-17 14:48:53.660766	2010-01-17 14:48:53.660766
400Kb	2010-01-18 13:02:15.286721	2010-01-18 13:02:15.286721
170Kb	2010-01-21 04:00:03.169266	2010-01-21 04:00:03.169266
800Kb	2010-01-21 11:23:15.06474	2010-01-21 11:23:15.06474
40Mb	2010-01-28 21:23:48.095545	2010-01-28 21:23:48.095545
1.6Mb	2010-01-28 21:32:11.842504	2010-01-28 21:32:11.842504
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: lhqgngvmkq
--

COPY users (id, email, crypted_password, password_salt, persistence_token, created_at, updated_at, last_request_at) FROM stdin;
3	andrea@wait6502.net	bc1a6d1f92538b74ee6e118a4e57175862b80391d05cdd884aff234168ffb98ed75b481b7a18b8ed581951d0a9883b6aa36e16988306f2db086c8608af54920e	pP8v8LqnYWijjzs8iIqu	964b28a8663d6bcb8b78351512081dbb1ed20dab4197772a45a79ccca270ff991e37ec2072028a0e82828939e1f291a321cf4a04ea7af48ba70edbdd256b2b9f	2010-01-10 22:14:42.230381	2010-02-02 00:18:57.489846	2010-02-02 00:18:57.488792
4	castiglioni.marco@gmail.com	785f267de0ceef1984da94016ae72215a9b85b41dbeeab0ff6f56aeca239f9faf168d75265775dad0cd2a40a0a89317126b6e4f29b28181b17759d71d08f5a8c	gYuvu32R0xqRMRadWpPr	8d02fad9c1e3e26741a01bd39dbab3de5694c8c9e023123cd0970d87810629417ea964af69ba4aa6a4179cbbb0a2e8e954b1405ff1a35345e8769eaa240ec583	2010-01-11 14:11:16.205189	2010-02-01 22:50:39.021647	2010-02-01 22:50:39.018792
\.


--
-- Name: auctions_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY auctions
    ADD CONSTRAINT auctions_pkey PRIMARY KEY (id);


--
-- Name: builtin_storages_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY builtin_storages
    ADD CONSTRAINT builtin_storages_pkey PRIMARY KEY (id);


--
-- Name: co_cpus_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY co_cpus
    ADD CONSTRAINT co_cpus_pkey PRIMARY KEY (id);


--
-- Name: cpus_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY cpus
    ADD CONSTRAINT cpus_pkey PRIMARY KEY (id);


--
-- Name: ebay_keywords_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY ebay_keywords
    ADD CONSTRAINT ebay_keywords_pkey PRIMARY KEY (id);


--
-- Name: hardware_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY hardware
    ADD CONSTRAINT hardware_pkey PRIMARY KEY (id);


--
-- Name: images_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: io_ports_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY io_ports
    ADD CONSTRAINT io_ports_pkey PRIMARY KEY (id);


--
-- Name: manufacturers_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY manufacturers
    ADD CONSTRAINT manufacturers_pkey PRIMARY KEY (id);


--
-- Name: operative_systems_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY operative_systems
    ADD CONSTRAINT operative_systems_pkey PRIMARY KEY (id);


--
-- Name: original_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY original_prices
    ADD CONSTRAINT original_prices_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: lhqgngvmkq; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

